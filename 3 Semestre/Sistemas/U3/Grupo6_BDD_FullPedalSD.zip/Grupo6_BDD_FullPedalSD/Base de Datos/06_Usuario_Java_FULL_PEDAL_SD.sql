/* ============================================================
   USUARIO TÉCNICO PARA LA CONEXIÓN DEL PROYECTO JAVA
   Ejecutar con una cuenta administradora de SQL Server.
   Requiere que SQL Server Authentication esté habilitado.
   ============================================================ */

USE master;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.server_principals
    WHERE name = N'fullpedal_app'
)
BEGIN
    CREATE LOGIN fullpedal_app
    WITH PASSWORD = 'FullPedal_2026#',
         CHECK_POLICY = ON,
         CHECK_EXPIRATION = OFF;
END;
GO

USE FULL_PEDAL_SD;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.database_principals
    WHERE name = N'fullpedal_app'
)
BEGIN
    CREATE USER fullpedal_app FOR LOGIN fullpedal_app;
END;
GO

GRANT CONNECT TO fullpedal_app;
GRANT EXECUTE ON SCHEMA::dbo TO fullpedal_app;
GRANT REFERENCES ON TYPE::dbo.TIPO_DETALLE_VENTA TO fullpedal_app;
GO

PRINT N'Usuario técnico fullpedal_app configurado.';
GO
