﻿/* ============================================================
   PROYECTO: FULL PEDAL SD
   SCRIPT 02: DATOS INICIALES
   ============================================================ */

USE FULL_PEDAL_SD;
GO

INSERT INTO dbo.TIENDA (NOMBRE, DIRECCION, TELEFONO)
VALUES (N'Full Pedal SD', N'Santo Domingo de los Tsáchilas, Ecuador', '0999999999');
GO

INSERT INTO dbo.ROL (
    NOMBRE_ROL,
    DESCRIPCION,
    PUEDE_GESTIONAR_EMPLEADOS,
    PUEDE_GESTIONAR_MARCAS,
    PUEDE_GESTIONAR_PRODUCTOS,
    PUEDE_ELIMINAR_PRODUCTO
)
VALUES
(N'ADMIN', N'Acceso completo al sistema', 1, 1, 1, 1),
(N'USUARIO', N'Acceso a ventas y consultas', 0, 0, 0, 0);
GO

DECLARE @ID_TIENDA INT =
(
    SELECT TOP (1) ID_TIENDA
    FROM dbo.TIENDA
    WHERE NOMBRE = N'Full Pedal SD'
);

INSERT INTO dbo.EMPLEADO (
    CEDULA, NOMBRES, APELLIDOS, TELEFONO,
    CORREO, CARGO, ID_TIENDA
)
VALUES
('1723456789', N'Andrea', N'Torres', '0982222222',
 N'andrea@fullpedal.com', N'Administradora', @ID_TIENDA),

('1712345678', N'Carlos', N'Mendoza', '0981111111',
 N'carlos@fullpedal.com', N'Vendedor', @ID_TIENDA);
GO

DECLARE @ID_ROL_ADMIN INT =
(
    SELECT ID_ROL FROM dbo.ROL WHERE NOMBRE_ROL = N'ADMIN'
);

DECLARE @ID_ROL_USUARIO INT =
(
    SELECT ID_ROL FROM dbo.ROL WHERE NOMBRE_ROL = N'USUARIO'
);

DECLARE @ID_EMPLEADO_ADMIN INT =
(
    SELECT ID_EMPLEADO FROM dbo.EMPLEADO WHERE CEDULA = '1723456789'
);

DECLARE @ID_EMPLEADO_USUARIO INT =
(
    SELECT ID_EMPLEADO FROM dbo.EMPLEADO WHERE CEDULA = '1712345678'
);

INSERT INTO dbo.USUARIO (
    NOMBRE_USUARIO, CLAVE_HASH, ID_ROL, ID_EMPLEADO
)
VALUES
(
    N'admin',
    HASHBYTES('SHA2_256', N'admin123'),
    @ID_ROL_ADMIN,
    @ID_EMPLEADO_ADMIN
),
(
    N'vendedor',
    HASHBYTES('SHA2_256', N'usuario123'),
    @ID_ROL_USUARIO,
    @ID_EMPLEADO_USUARIO
);
GO

INSERT INTO dbo.CLIENTE (
    CEDULA, NOMBRES, APELLIDOS, TELEFONO, CORREO, DIRECCION
)
VALUES
('2300123456', N'Luis', N'Zambrano', '0991111111',
 N'luis@gmail.com', N'Santo Domingo'),

('2300654321', N'María', N'Cedeño', '0992222222',
 N'maria@gmail.com', N'La Concordia'),

('1722233344', N'José', N'Paredes', '0983333333',
 N'jose@gmail.com', N'El Carmen');
GO

INSERT INTO dbo.MARCA (NOMBRE_MARCA, PAIS_ORIGEN)
VALUES
(N'Trek', N'Estados Unidos'),
(N'Giant', N'Taiwán'),
(N'Scott', N'Suiza'),
(N'Specialized', N'Estados Unidos');
GO

INSERT INTO dbo.TIPO_BICICLETA (NOMBRE_TIPO, DESCRIPCION)
VALUES
(N'Montaña', N'Bicicleta diseñada para terrenos irregulares'),
(N'Ruta', N'Bicicleta diseñada para carreteras y velocidad'),
(N'BMX', N'Bicicleta diseñada para acrobacias'),
(N'Urbana', N'Bicicleta destinada al desplazamiento en ciudad');
GO

DECLARE @MARCA_TREK INT =
(
    SELECT ID_MARCA FROM dbo.MARCA WHERE NOMBRE_MARCA = N'Trek'
);
DECLARE @MARCA_GIANT INT =
(
    SELECT ID_MARCA FROM dbo.MARCA WHERE NOMBRE_MARCA = N'Giant'
);
DECLARE @MARCA_SCOTT INT =
(
    SELECT ID_MARCA FROM dbo.MARCA WHERE NOMBRE_MARCA = N'Scott'
);
DECLARE @MARCA_SPECIALIZED INT =
(
    SELECT ID_MARCA FROM dbo.MARCA WHERE NOMBRE_MARCA = N'Specialized'
);

DECLARE @TIPO_MONTANA INT =
(
    SELECT ID_TIPO FROM dbo.TIPO_BICICLETA WHERE NOMBRE_TIPO = N'Montaña'
);
DECLARE @TIPO_RUTA INT =
(
    SELECT ID_TIPO FROM dbo.TIPO_BICICLETA WHERE NOMBRE_TIPO = N'Ruta'
);
DECLARE @TIPO_BMX INT =
(
    SELECT ID_TIPO FROM dbo.TIPO_BICICLETA WHERE NOMBRE_TIPO = N'BMX'
);
DECLARE @TIPO_URBANA INT =
(
    SELECT ID_TIPO FROM dbo.TIPO_BICICLETA WHERE NOMBRE_TIPO = N'Urbana'
);

INSERT INTO dbo.BICICLETA (
    CODIGO, MODELO, ID_MARCA, ID_TIPO,
    COLOR, TALLA, PRECIO_VENTA, STOCK
)
VALUES
('BIC-001', N'Marlin 5', @MARCA_TREK, @TIPO_MONTANA,
 N'Negro', N'M', 750.00, 10),

('BIC-002', N'Talon 3', @MARCA_GIANT, @TIPO_MONTANA,
 N'Azul', N'L', 680.00, 8),

('BIC-003', N'Speedster 40', @MARCA_SCOTT, @TIPO_RUTA,
 N'Rojo', N'M', 950.00, 5),

('BIC-004', N'P.3', @MARCA_SPECIALIZED, @TIPO_BMX,
 N'Gris', N'Única', 820.00, 4),

('BIC-005', N'Escape 3', @MARCA_GIANT, @TIPO_URBANA,
 N'Verde', N'M', 590.00, 7);
GO

PRINT N'Datos iniciales insertados correctamente.';
PRINT N'Usuario administrador: admin / admin123';
PRINT N'Usuario normal: vendedor / usuario123';
GO
