﻿/* ============================================================
   PROYECTO: FULL PEDAL SD
   SCRIPT 03: FUNCIONES, PROCEDIMIENTOS, VISTAS Y CONSULTAS
   ============================================================ */

USE FULL_PEDAL_SD;
GO

/* ============================================================
   FUNCIÓN PARA VALIDAR PERMISOS
   ============================================================ */
CREATE OR ALTER FUNCTION dbo.FN_USUARIO_TIENE_PERMISO
(
    @ID_USUARIO INT,
    @PERMISO NVARCHAR(30)
)
RETURNS BIT
AS
BEGIN
    DECLARE @RESULTADO BIT = 0;

    SELECT @RESULTADO =
        CASE UPPER(@PERMISO)
            WHEN N'EMPLEADOS' THEN R.PUEDE_GESTIONAR_EMPLEADOS
            WHEN N'MARCAS' THEN R.PUEDE_GESTIONAR_MARCAS
            WHEN N'PRODUCTOS' THEN R.PUEDE_GESTIONAR_PRODUCTOS
            WHEN N'ELIMINAR_PRODUCTO' THEN R.PUEDE_ELIMINAR_PRODUCTO
            ELSE 0
        END
    FROM dbo.USUARIO AS U
    INNER JOIN dbo.ROL AS R
        ON U.ID_ROL = R.ID_ROL
    WHERE U.ID_USUARIO = @ID_USUARIO
      AND U.ESTADO = 1;

    RETURN ISNULL(@RESULTADO, 0);
END;
GO

/* ============================================================
   LOGIN Y USUARIOS
   ============================================================ */
CREATE OR ALTER PROCEDURE dbo.SP_INICIAR_SESION
    @NOMBRE_USUARIO NVARCHAR(50),
    @CLAVE NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        U.ID_USUARIO,
        U.NOMBRE_USUARIO,
        R.ID_ROL,
        R.NOMBRE_ROL,
        R.PUEDE_GESTIONAR_EMPLEADOS,
        R.PUEDE_GESTIONAR_MARCAS,
        R.PUEDE_GESTIONAR_PRODUCTOS,
        R.PUEDE_ELIMINAR_PRODUCTO,
        E.ID_EMPLEADO,
        CONCAT(E.NOMBRES, N' ', E.APELLIDOS) AS NOMBRE_EMPLEADO
    FROM dbo.USUARIO AS U
    INNER JOIN dbo.ROL AS R
        ON U.ID_ROL = R.ID_ROL
    LEFT JOIN dbo.EMPLEADO AS E
        ON U.ID_EMPLEADO = E.ID_EMPLEADO
    WHERE U.NOMBRE_USUARIO = @NOMBRE_USUARIO
      AND U.CLAVE_HASH = HASHBYTES('SHA2_256', @CLAVE)
      AND U.ESTADO = 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_ROL_LISTAR
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_ROL,
        NOMBRE_ROL,
        DESCRIPCION,
        PUEDE_GESTIONAR_EMPLEADOS,
        PUEDE_GESTIONAR_MARCAS,
        PUEDE_GESTIONAR_PRODUCTOS,
        PUEDE_ELIMINAR_PRODUCTO
    FROM dbo.ROL
    ORDER BY ID_ROL;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_TIENDA_LISTAR
AS
BEGIN
    SET NOCOUNT ON;

    SELECT ID_TIENDA, NOMBRE, DIRECCION, TELEFONO
    FROM dbo.TIENDA
    WHERE ESTADO = 1
    ORDER BY NOMBRE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_TIPO_BICICLETA_LISTAR
AS
BEGIN
    SET NOCOUNT ON;

    SELECT ID_TIPO, NOMBRE_TIPO, DESCRIPCION
    FROM dbo.TIPO_BICICLETA
    WHERE ESTADO = 1
    ORDER BY NOMBRE_TIPO;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_USUARIO_LISTAR
    @ID_USUARIO_SOLICITA INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'EMPLEADOS') = 0
        THROW 50001, N'No tiene permiso para consultar usuarios.', 1;

    SELECT
        U.ID_USUARIO,
        U.NOMBRE_USUARIO,
        R.NOMBRE_ROL,
        U.ID_EMPLEADO,
        CONCAT(E.NOMBRES, N' ', E.APELLIDOS) AS EMPLEADO,
        U.ESTADO,
        U.FECHA_CREACION
    FROM dbo.USUARIO AS U
    INNER JOIN dbo.ROL AS R
        ON U.ID_ROL = R.ID_ROL
    LEFT JOIN dbo.EMPLEADO AS E
        ON U.ID_EMPLEADO = E.ID_EMPLEADO
    ORDER BY U.NOMBRE_USUARIO;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_USUARIO_INSERTAR
    @ID_USUARIO_SOLICITA INT,
    @NOMBRE_USUARIO NVARCHAR(50),
    @CLAVE NVARCHAR(100),
    @ID_ROL INT,
    @ID_EMPLEADO INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'EMPLEADOS') = 0
        THROW 50002, N'No tiene permiso para crear usuarios.', 1;

    IF NULLIF(LTRIM(RTRIM(@NOMBRE_USUARIO)), N'') IS NULL
        THROW 50003, N'El nombre de usuario es obligatorio.', 1;

    IF LEN(@CLAVE) < 6
        THROW 50004, N'La contraseña debe tener al menos 6 caracteres.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.ROL WHERE ID_ROL = @ID_ROL)
        THROW 50005, N'El rol indicado no existe.', 1;

    IF @ID_EMPLEADO IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
           FROM dbo.EMPLEADO
           WHERE ID_EMPLEADO = @ID_EMPLEADO
             AND ESTADO = 1
       )
        THROW 50006, N'El empleado indicado no existe o está inactivo.', 1;

    INSERT INTO dbo.USUARIO (
        NOMBRE_USUARIO,
        CLAVE_HASH,
        ID_ROL,
        ID_EMPLEADO
    )
    VALUES (
        LTRIM(RTRIM(@NOMBRE_USUARIO)),
        HASHBYTES('SHA2_256', @CLAVE),
        @ID_ROL,
        @ID_EMPLEADO
    );

    SELECT
        CAST(SCOPE_IDENTITY() AS INT) AS ID_USUARIO,
        N'Usuario registrado correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_USUARIO_CAMBIAR_ESTADO
    @ID_USUARIO_SOLICITA INT,
    @ID_USUARIO INT,
    @ESTADO BIT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'EMPLEADOS') = 0
        THROW 50007, N'No tiene permiso para modificar usuarios.', 1;

    IF @ID_USUARIO_SOLICITA = @ID_USUARIO AND @ESTADO = 0
        THROW 50008, N'No puede desactivar su propio usuario.', 1;

    UPDATE dbo.USUARIO
    SET ESTADO = @ESTADO
    WHERE ID_USUARIO = @ID_USUARIO;

    IF @@ROWCOUNT = 0
        THROW 50009, N'El usuario indicado no existe.', 1;

    SELECT N'Estado del usuario actualizado correctamente.' AS MENSAJE;
END;
GO

/* ============================================================
   EMPLEADOS
   ============================================================ */
CREATE OR ALTER PROCEDURE dbo.SP_EMPLEADO_LISTAR
    @SOLO_ACTIVOS BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        E.ID_EMPLEADO,
        E.CEDULA,
        E.NOMBRES,
        E.APELLIDOS,
        E.TELEFONO,
        E.CORREO,
        E.CARGO,
        E.ID_TIENDA,
        T.NOMBRE AS TIENDA,
        E.ESTADO,
        E.FECHA_REGISTRO
    FROM dbo.EMPLEADO AS E
    INNER JOIN dbo.TIENDA AS T
        ON E.ID_TIENDA = T.ID_TIENDA
    WHERE @SOLO_ACTIVOS = 0 OR E.ESTADO = 1
    ORDER BY E.APELLIDOS, E.NOMBRES;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_EMPLEADO_INSERTAR
    @ID_USUARIO_SOLICITA INT,
    @CEDULA VARCHAR(10),
    @NOMBRES NVARCHAR(70),
    @APELLIDOS NVARCHAR(70),
    @TELEFONO VARCHAR(15) = NULL,
    @CORREO NVARCHAR(100) = NULL,
    @CARGO NVARCHAR(50),
    @ID_TIENDA INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'EMPLEADOS') = 0
        THROW 50100, N'No tiene permiso para registrar empleados.', 1;

    IF LEN(@CEDULA) <> 10 OR @CEDULA LIKE '%[^0-9]%'
        THROW 50101, N'La cédula debe contener exactamente 10 dígitos.', 1;

    IF NULLIF(LTRIM(RTRIM(@NOMBRES)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@APELLIDOS)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@CARGO)), N'') IS NULL
        THROW 50102, N'Nombres, apellidos y cargo son obligatorios.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.TIENDA
        WHERE ID_TIENDA = @ID_TIENDA AND ESTADO = 1
    )
        THROW 50103, N'La tienda indicada no existe o está inactiva.', 1;

    INSERT INTO dbo.EMPLEADO (
        CEDULA, NOMBRES, APELLIDOS, TELEFONO,
        CORREO, CARGO, ID_TIENDA
    )
    VALUES (
        @CEDULA,
        LTRIM(RTRIM(@NOMBRES)),
        LTRIM(RTRIM(@APELLIDOS)),
        NULLIF(LTRIM(RTRIM(@TELEFONO)), ''),
        NULLIF(LTRIM(RTRIM(@CORREO)), N''),
        LTRIM(RTRIM(@CARGO)),
        @ID_TIENDA
    );

    SELECT
        CAST(SCOPE_IDENTITY() AS INT) AS ID_EMPLEADO,
        N'Empleado registrado correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_EMPLEADO_MODIFICAR
    @ID_USUARIO_SOLICITA INT,
    @ID_EMPLEADO INT,
    @CEDULA VARCHAR(10),
    @NOMBRES NVARCHAR(70),
    @APELLIDOS NVARCHAR(70),
    @TELEFONO VARCHAR(15) = NULL,
    @CORREO NVARCHAR(100) = NULL,
    @CARGO NVARCHAR(50),
    @ID_TIENDA INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'EMPLEADOS') = 0
        THROW 50104, N'No tiene permiso para modificar empleados.', 1;

    IF LEN(@CEDULA) <> 10 OR @CEDULA LIKE '%[^0-9]%'
        THROW 50105, N'La cédula debe contener exactamente 10 dígitos.', 1;

    UPDATE dbo.EMPLEADO
    SET
        CEDULA = @CEDULA,
        NOMBRES = LTRIM(RTRIM(@NOMBRES)),
        APELLIDOS = LTRIM(RTRIM(@APELLIDOS)),
        TELEFONO = NULLIF(LTRIM(RTRIM(@TELEFONO)), ''),
        CORREO = NULLIF(LTRIM(RTRIM(@CORREO)), N''),
        CARGO = LTRIM(RTRIM(@CARGO)),
        ID_TIENDA = @ID_TIENDA
    WHERE ID_EMPLEADO = @ID_EMPLEADO;

    IF @@ROWCOUNT = 0
        THROW 50106, N'El empleado indicado no existe.', 1;

    SELECT N'Empleado modificado correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_EMPLEADO_ELIMINAR
    @ID_USUARIO_SOLICITA INT,
    @ID_EMPLEADO INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'EMPLEADOS') = 0
        THROW 50107, N'No tiene permiso para eliminar empleados.', 1;

    IF EXISTS (
        SELECT 1
        FROM dbo.USUARIO
        WHERE ID_USUARIO = @ID_USUARIO_SOLICITA
          AND ID_EMPLEADO = @ID_EMPLEADO
    )
        THROW 50109, N'No puede eliminar el empleado asociado a su propia sesión.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE dbo.EMPLEADO
        SET ESTADO = 0
        WHERE ID_EMPLEADO = @ID_EMPLEADO
          AND ESTADO = 1;

        IF @@ROWCOUNT = 0
            THROW 50108, N'El empleado no existe o ya estaba eliminado.', 1;

        UPDATE dbo.USUARIO
        SET ESTADO = 0
        WHERE ID_EMPLEADO = @ID_EMPLEADO;

        COMMIT TRANSACTION;

        SELECT N'Empleado eliminado lógicamente y usuario asociado desactivado.' AS MENSAJE;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

/* ============================================================
   MARCAS
   ============================================================ */
CREATE OR ALTER PROCEDURE dbo.SP_MARCA_LISTAR
    @SOLO_ACTIVAS BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_MARCA,
        NOMBRE_MARCA,
        PAIS_ORIGEN,
        ESTADO,
        FECHA_REGISTRO
    FROM dbo.MARCA
    WHERE @SOLO_ACTIVAS = 0 OR ESTADO = 1
    ORDER BY NOMBRE_MARCA;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_MARCA_INSERTAR
    @ID_USUARIO_SOLICITA INT,
    @NOMBRE_MARCA NVARCHAR(70),
    @PAIS_ORIGEN NVARCHAR(70) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'MARCAS') = 0
        THROW 50200, N'No tiene permiso para registrar marcas.', 1;

    IF NULLIF(LTRIM(RTRIM(@NOMBRE_MARCA)), N'') IS NULL
        THROW 50201, N'El nombre de la marca es obligatorio.', 1;

    INSERT INTO dbo.MARCA (NOMBRE_MARCA, PAIS_ORIGEN)
    VALUES (
        LTRIM(RTRIM(@NOMBRE_MARCA)),
        NULLIF(LTRIM(RTRIM(@PAIS_ORIGEN)), N'')
    );

    SELECT
        CAST(SCOPE_IDENTITY() AS INT) AS ID_MARCA,
        N'Marca registrada correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_MARCA_MODIFICAR
    @ID_USUARIO_SOLICITA INT,
    @ID_MARCA INT,
    @NOMBRE_MARCA NVARCHAR(70),
    @PAIS_ORIGEN NVARCHAR(70) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'MARCAS') = 0
        THROW 50202, N'No tiene permiso para modificar marcas.', 1;

    UPDATE dbo.MARCA
    SET
        NOMBRE_MARCA = LTRIM(RTRIM(@NOMBRE_MARCA)),
        PAIS_ORIGEN = NULLIF(LTRIM(RTRIM(@PAIS_ORIGEN)), N'')
    WHERE ID_MARCA = @ID_MARCA;

    IF @@ROWCOUNT = 0
        THROW 50203, N'La marca indicada no existe.', 1;

    SELECT N'Marca modificada correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_MARCA_ELIMINAR
    @ID_USUARIO_SOLICITA INT,
    @ID_MARCA INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'MARCAS') = 0
        THROW 50204, N'No tiene permiso para eliminar marcas.', 1;

    IF EXISTS (
        SELECT 1
        FROM dbo.BICICLETA
        WHERE ID_MARCA = @ID_MARCA
          AND ESTADO = 1
    )
        THROW 50206, N'No se puede eliminar la marca porque tiene bicicletas activas.', 1;

    UPDATE dbo.MARCA
    SET ESTADO = 0
    WHERE ID_MARCA = @ID_MARCA
      AND ESTADO = 1;

    IF @@ROWCOUNT = 0
        THROW 50205, N'La marca no existe o ya estaba eliminada.', 1;

    SELECT N'Marca eliminada lógicamente.' AS MENSAJE;
END;
GO

/* ============================================================
   CLIENTES
   ============================================================ */
CREATE OR ALTER PROCEDURE dbo.SP_CLIENTE_LISTAR
    @SOLO_ACTIVOS BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_CLIENTE,
        CEDULA,
        NOMBRES,
        APELLIDOS,
        TELEFONO,
        CORREO,
        DIRECCION,
        ESTADO,
        FECHA_REGISTRO
    FROM dbo.CLIENTE
    WHERE @SOLO_ACTIVOS = 0 OR ESTADO = 1
    ORDER BY APELLIDOS, NOMBRES;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_CLIENTE_INSERTAR
    @CEDULA VARCHAR(10),
    @NOMBRES NVARCHAR(70),
    @APELLIDOS NVARCHAR(70),
    @TELEFONO VARCHAR(15) = NULL,
    @CORREO NVARCHAR(100) = NULL,
    @DIRECCION NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF LEN(@CEDULA) <> 10 OR @CEDULA LIKE '%[^0-9]%'
        THROW 50300, N'La cédula debe contener exactamente 10 dígitos.', 1;

    INSERT INTO dbo.CLIENTE (
        CEDULA, NOMBRES, APELLIDOS,
        TELEFONO, CORREO, DIRECCION
    )
    VALUES (
        @CEDULA,
        LTRIM(RTRIM(@NOMBRES)),
        LTRIM(RTRIM(@APELLIDOS)),
        NULLIF(LTRIM(RTRIM(@TELEFONO)), ''),
        NULLIF(LTRIM(RTRIM(@CORREO)), N''),
        NULLIF(LTRIM(RTRIM(@DIRECCION)), N'')
    );

    SELECT
        CAST(SCOPE_IDENTITY() AS INT) AS ID_CLIENTE,
        N'Cliente registrado correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_CLIENTE_MODIFICAR
    @ID_CLIENTE INT,
    @CEDULA VARCHAR(10),
    @NOMBRES NVARCHAR(70),
    @APELLIDOS NVARCHAR(70),
    @TELEFONO VARCHAR(15) = NULL,
    @CORREO NVARCHAR(100) = NULL,
    @DIRECCION NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.CLIENTE
    SET
        CEDULA = @CEDULA,
        NOMBRES = LTRIM(RTRIM(@NOMBRES)),
        APELLIDOS = LTRIM(RTRIM(@APELLIDOS)),
        TELEFONO = NULLIF(LTRIM(RTRIM(@TELEFONO)), ''),
        CORREO = NULLIF(LTRIM(RTRIM(@CORREO)), N''),
        DIRECCION = NULLIF(LTRIM(RTRIM(@DIRECCION)), N'')
    WHERE ID_CLIENTE = @ID_CLIENTE;

    IF @@ROWCOUNT = 0
        THROW 50301, N'El cliente indicado no existe.', 1;

    SELECT N'Cliente modificado correctamente.' AS MENSAJE;
END;
GO

/* ============================================================
   BICICLETAS
   ============================================================ */
CREATE OR ALTER PROCEDURE dbo.SP_BICICLETA_LISTAR
    @SOLO_ACTIVAS BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        B.ID_BICICLETA,
        B.CODIGO,
        B.MODELO,
        B.ID_MARCA,
        M.NOMBRE_MARCA,
        B.ID_TIPO,
        T.NOMBRE_TIPO,
        B.COLOR,
        B.TALLA,
        B.PRECIO_VENTA,
        B.STOCK,
        B.ESTADO,
        B.FECHA_REGISTRO
    FROM dbo.BICICLETA AS B
    INNER JOIN dbo.MARCA AS M
        ON B.ID_MARCA = M.ID_MARCA
    INNER JOIN dbo.TIPO_BICICLETA AS T
        ON B.ID_TIPO = T.ID_TIPO
    WHERE @SOLO_ACTIVAS = 0 OR B.ESTADO = 1
    ORDER BY M.NOMBRE_MARCA, B.MODELO;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_BICICLETA_INSERTAR
    @ID_USUARIO_SOLICITA INT,
    @CODIGO VARCHAR(20),
    @MODELO NVARCHAR(100),
    @ID_MARCA INT,
    @ID_TIPO INT,
    @COLOR NVARCHAR(40) = NULL,
    @TALLA NVARCHAR(20) = NULL,
    @PRECIO_VENTA DECIMAL(12,2),
    @STOCK INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'PRODUCTOS') = 0
        THROW 50400, N'No tiene permiso para registrar bicicletas.', 1;

    IF @PRECIO_VENTA <= 0
        THROW 50401, N'El precio debe ser mayor que cero.', 1;

    IF @STOCK < 0
        THROW 50402, N'El stock no puede ser negativo.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.MARCA
        WHERE ID_MARCA = @ID_MARCA AND ESTADO = 1
    )
        THROW 50403, N'La marca indicada no existe o está inactiva.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.TIPO_BICICLETA
        WHERE ID_TIPO = @ID_TIPO AND ESTADO = 1
    )
        THROW 50404, N'El tipo de bicicleta no existe o está inactivo.', 1;

    INSERT INTO dbo.BICICLETA (
        CODIGO, MODELO, ID_MARCA, ID_TIPO,
        COLOR, TALLA, PRECIO_VENTA, STOCK
    )
    VALUES (
        UPPER(LTRIM(RTRIM(@CODIGO))),
        LTRIM(RTRIM(@MODELO)),
        @ID_MARCA,
        @ID_TIPO,
        NULLIF(LTRIM(RTRIM(@COLOR)), N''),
        NULLIF(LTRIM(RTRIM(@TALLA)), N''),
        @PRECIO_VENTA,
        @STOCK
    );

    SELECT
        CAST(SCOPE_IDENTITY() AS INT) AS ID_BICICLETA,
        N'Bicicleta registrada correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_BICICLETA_MODIFICAR
    @ID_USUARIO_SOLICITA INT,
    @ID_BICICLETA INT,
    @CODIGO VARCHAR(20),
    @MODELO NVARCHAR(100),
    @ID_MARCA INT,
    @ID_TIPO INT,
    @COLOR NVARCHAR(40) = NULL,
    @TALLA NVARCHAR(20) = NULL,
    @PRECIO_VENTA DECIMAL(12,2),
    @STOCK INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'PRODUCTOS') = 0
        THROW 50405, N'No tiene permiso para modificar bicicletas.', 1;

    IF @PRECIO_VENTA <= 0 OR @STOCK < 0
        THROW 50406, N'Precio o stock inválido.', 1;

    UPDATE dbo.BICICLETA
    SET
        CODIGO = UPPER(LTRIM(RTRIM(@CODIGO))),
        MODELO = LTRIM(RTRIM(@MODELO)),
        ID_MARCA = @ID_MARCA,
        ID_TIPO = @ID_TIPO,
        COLOR = NULLIF(LTRIM(RTRIM(@COLOR)), N''),
        TALLA = NULLIF(LTRIM(RTRIM(@TALLA)), N''),
        PRECIO_VENTA = @PRECIO_VENTA,
        STOCK = @STOCK
    WHERE ID_BICICLETA = @ID_BICICLETA;

    IF @@ROWCOUNT = 0
        THROW 50407, N'La bicicleta indicada no existe.', 1;

    SELECT N'Bicicleta modificada correctamente.' AS MENSAJE;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_BICICLETA_ELIMINAR
    @ID_USUARIO_SOLICITA INT,
    @ID_BICICLETA INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'ELIMINAR_PRODUCTO') = 0
        THROW 50408, N'El usuario no tiene permiso para eliminar productos.', 1;

    UPDATE dbo.BICICLETA
    SET ESTADO = 0
    WHERE ID_BICICLETA = @ID_BICICLETA
      AND ESTADO = 1;

    IF @@ROWCOUNT = 0
        THROW 50409, N'La bicicleta no existe o ya estaba eliminada.', 1;

    SELECT N'Bicicleta eliminada lógicamente.' AS MENSAJE;
END;
GO

/* ============================================================
   TIPO DE TABLA PARA ENVIAR VARIOS PRODUCTOS DESDE JAVA
   ============================================================ */
IF TYPE_ID(N'dbo.TIPO_DETALLE_VENTA') IS NULL
BEGIN
    EXEC(N'
        CREATE TYPE dbo.TIPO_DETALLE_VENTA AS TABLE
        (
            ID_BICICLETA INT NOT NULL PRIMARY KEY,
            CANTIDAD INT NOT NULL CHECK (CANTIDAD > 0)
        );
    ');
END;
GO

/* ============================================================
   REGISTRAR VENTA COMPLETA CON TRANSACCIÓN
   ============================================================ */
CREATE OR ALTER PROCEDURE dbo.SP_VENTA_REGISTRAR
    @ID_CLIENTE INT,
    @ID_EMPLEADO INT,
    @ID_USUARIO INT,
    @DETALLES dbo.TIPO_DETALLE_VENTA READONLY,
    @OBSERVACION NVARCHAR(250) = NULL,
    @ID_VENTA_GENERADA INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @TOTAL DECIMAL(12,2);

    IF NOT EXISTS (
        SELECT 1 FROM dbo.CLIENTE
        WHERE ID_CLIENTE = @ID_CLIENTE AND ESTADO = 1
    )
        THROW 50500, N'El cliente no existe o está inactivo.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.EMPLEADO
        WHERE ID_EMPLEADO = @ID_EMPLEADO AND ESTADO = 1
    )
        THROW 50501, N'El empleado no existe o está inactivo.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.USUARIO
        WHERE ID_USUARIO = @ID_USUARIO AND ESTADO = 1
    )
        THROW 50502, N'El usuario no existe o está inactivo.', 1;

    IF NOT EXISTS (SELECT 1 FROM @DETALLES)
        THROW 50503, N'La venta debe contener al menos una bicicleta.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF EXISTS (
            SELECT 1
            FROM @DETALLES AS D
            LEFT JOIN dbo.BICICLETA AS B WITH (UPDLOCK, HOLDLOCK)
                ON D.ID_BICICLETA = B.ID_BICICLETA
            WHERE B.ID_BICICLETA IS NULL
               OR B.ESTADO = 0
        )
            THROW 50504, N'Una de las bicicletas no existe o está inactiva.', 1;

        IF EXISTS (
            SELECT 1
            FROM @DETALLES AS D
            INNER JOIN dbo.BICICLETA AS B WITH (UPDLOCK, HOLDLOCK)
                ON D.ID_BICICLETA = B.ID_BICICLETA
            WHERE B.STOCK < D.CANTIDAD
        )
            THROW 50505, N'No existe stock suficiente para una de las bicicletas.', 1;

        SELECT @TOTAL =
            SUM(CONVERT(DECIMAL(12,2), D.CANTIDAD * B.PRECIO_VENTA))
        FROM @DETALLES AS D
        INNER JOIN dbo.BICICLETA AS B
            ON D.ID_BICICLETA = B.ID_BICICLETA;

        INSERT INTO dbo.VENTA (
            ID_CLIENTE,
            ID_EMPLEADO,
            ID_USUARIO,
            TOTAL,
            OBSERVACION
        )
        VALUES (
            @ID_CLIENTE,
            @ID_EMPLEADO,
            @ID_USUARIO,
            @TOTAL,
            NULLIF(LTRIM(RTRIM(@OBSERVACION)), N'')
        );

        SET @ID_VENTA_GENERADA = CAST(SCOPE_IDENTITY() AS INT);

        INSERT INTO dbo.DETALLE_VENTA (
            ID_VENTA,
            ID_BICICLETA,
            CANTIDAD,
            PRECIO_UNITARIO
        )
        SELECT
            @ID_VENTA_GENERADA,
            D.ID_BICICLETA,
            D.CANTIDAD,
            B.PRECIO_VENTA
        FROM @DETALLES AS D
        INNER JOIN dbo.BICICLETA AS B
            ON D.ID_BICICLETA = B.ID_BICICLETA;

        UPDATE B
        SET B.STOCK = B.STOCK - D.CANTIDAD
        FROM dbo.BICICLETA AS B
        INNER JOIN @DETALLES AS D
            ON B.ID_BICICLETA = D.ID_BICICLETA;

        COMMIT TRANSACTION;

        SELECT
            V.ID_VENTA,
            V.NUMERO_VENTA,
            V.FECHA_VENTA,
            V.TOTAL,
            V.ESTADO,
            N'Venta registrada correctamente.' AS MENSAJE
        FROM dbo.VENTA AS V
        WHERE V.ID_VENTA = @ID_VENTA_GENERADA;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_VENTA_ANULAR
    @ID_USUARIO_SOLICITA INT,
    @ID_VENTA INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.FN_USUARIO_TIENE_PERMISO(@ID_USUARIO_SOLICITA, N'PRODUCTOS') = 0
        THROW 50506, N'No tiene permiso para anular ventas.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS (
            SELECT 1
            FROM dbo.VENTA WITH (UPDLOCK, HOLDLOCK)
            WHERE ID_VENTA = @ID_VENTA
              AND ESTADO = N'COMPLETADA'
        )
            THROW 50507, N'La venta no existe o ya está anulada.', 1;

        UPDATE B
        SET B.STOCK = B.STOCK + D.CANTIDAD
        FROM dbo.BICICLETA AS B
        INNER JOIN dbo.DETALLE_VENTA AS D
            ON B.ID_BICICLETA = D.ID_BICICLETA
        WHERE D.ID_VENTA = @ID_VENTA;

        UPDATE dbo.VENTA
        SET ESTADO = N'ANULADA'
        WHERE ID_VENTA = @ID_VENTA;

        COMMIT TRANSACTION;

        SELECT N'Venta anulada y stock restaurado correctamente.' AS MENSAJE;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_VENTA_LISTAR
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        V.ID_VENTA,
        V.NUMERO_VENTA,
        V.FECHA_VENTA,
        CONCAT(C.NOMBRES, N' ', C.APELLIDOS) AS CLIENTE,
        CONCAT(E.NOMBRES, N' ', E.APELLIDOS) AS EMPLEADO,
        U.NOMBRE_USUARIO,
        V.TOTAL,
        V.ESTADO,
        V.OBSERVACION
    FROM dbo.VENTA AS V
    INNER JOIN dbo.CLIENTE AS C
        ON V.ID_CLIENTE = C.ID_CLIENTE
    INNER JOIN dbo.EMPLEADO AS E
        ON V.ID_EMPLEADO = E.ID_EMPLEADO
    INNER JOIN dbo.USUARIO AS U
        ON V.ID_USUARIO = U.ID_USUARIO
    ORDER BY V.FECHA_VENTA DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.SP_VENTA_DETALLE
    @ID_VENTA INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        V.NUMERO_VENTA,
        B.CODIGO,
        B.MODELO,
        M.NOMBRE_MARCA,
        D.CANTIDAD,
        D.PRECIO_UNITARIO,
        D.SUBTOTAL
    FROM dbo.DETALLE_VENTA AS D
    INNER JOIN dbo.VENTA AS V
        ON D.ID_VENTA = V.ID_VENTA
    INNER JOIN dbo.BICICLETA AS B
        ON D.ID_BICICLETA = B.ID_BICICLETA
    INNER JOIN dbo.MARCA AS M
        ON B.ID_MARCA = M.ID_MARCA
    WHERE D.ID_VENTA = @ID_VENTA
    ORDER BY D.ID_DETALLE;
END;
GO

/* ============================================================
   VISTAS PARA REPORTES Y FORMULARIOS
   ============================================================ */
CREATE OR ALTER VIEW dbo.VW_CLIENTES_COMPRADORES
AS
    SELECT
        C.ID_CLIENTE,
        C.CEDULA,
        C.NOMBRES,
        C.APELLIDOS,
        C.TELEFONO,
        C.CORREO,
        COUNT(DISTINCT V.ID_VENTA) AS CANTIDAD_COMPRAS,
        SUM(V.TOTAL) AS TOTAL_COMPRADO,
        MAX(V.FECHA_VENTA) AS ULTIMA_COMPRA
    FROM dbo.CLIENTE AS C
    INNER JOIN dbo.VENTA AS V
        ON C.ID_CLIENTE = V.ID_CLIENTE
    WHERE V.ESTADO = N'COMPLETADA'
    GROUP BY
        C.ID_CLIENTE,
        C.CEDULA,
        C.NOMBRES,
        C.APELLIDOS,
        C.TELEFONO,
        C.CORREO;
GO

CREATE OR ALTER VIEW dbo.VW_INVENTARIO_BICICLETAS
AS
    SELECT
        B.ID_BICICLETA,
        B.CODIGO,
        B.MODELO,
        M.NOMBRE_MARCA,
        T.NOMBRE_TIPO,
        B.COLOR,
        B.TALLA,
        B.PRECIO_VENTA,
        B.STOCK,
        B.ESTADO
    FROM dbo.BICICLETA AS B
    INNER JOIN dbo.MARCA AS M
        ON B.ID_MARCA = M.ID_MARCA
    INNER JOIN dbo.TIPO_BICICLETA AS T
        ON B.ID_TIPO = T.ID_TIPO;
GO

CREATE OR ALTER VIEW dbo.VW_VENTAS_DETALLADAS
AS
    SELECT
        V.ID_VENTA,
        V.NUMERO_VENTA,
        V.FECHA_VENTA,
        C.CEDULA AS CEDULA_CLIENTE,
        CONCAT(C.NOMBRES, N' ', C.APELLIDOS) AS CLIENTE,
        CONCAT(E.NOMBRES, N' ', E.APELLIDOS) AS EMPLEADO,
        B.CODIGO,
        B.MODELO,
        M.NOMBRE_MARCA,
        D.CANTIDAD,
        D.PRECIO_UNITARIO,
        D.SUBTOTAL,
        V.TOTAL,
        V.ESTADO
    FROM dbo.VENTA AS V
    INNER JOIN dbo.CLIENTE AS C
        ON V.ID_CLIENTE = C.ID_CLIENTE
    INNER JOIN dbo.EMPLEADO AS E
        ON V.ID_EMPLEADO = E.ID_EMPLEADO
    INNER JOIN dbo.DETALLE_VENTA AS D
        ON V.ID_VENTA = D.ID_VENTA
    INNER JOIN dbo.BICICLETA AS B
        ON D.ID_BICICLETA = B.ID_BICICLETA
    INNER JOIN dbo.MARCA AS M
        ON B.ID_MARCA = M.ID_MARCA;
GO

/* Procedimiento directo para el botón "Consultar compradores" */
CREATE OR ALTER PROCEDURE dbo.SP_CLIENTES_QUE_COMPRARON
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_CLIENTE,
        CEDULA,
        NOMBRES,
        APELLIDOS,
        TELEFONO,
        CORREO,
        CANTIDAD_COMPRAS,
        TOTAL_COMPRADO,
        ULTIMA_COMPRA
    FROM dbo.VW_CLIENTES_COMPRADORES
    ORDER BY ULTIMA_COMPRA DESC;
END;
GO

PRINT N'Procedimientos, funciones y vistas creados correctamente.';
GO
