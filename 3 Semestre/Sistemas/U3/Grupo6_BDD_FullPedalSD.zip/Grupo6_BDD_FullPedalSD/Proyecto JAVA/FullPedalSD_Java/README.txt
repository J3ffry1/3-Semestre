FULL PEDAL SD - PROYECTO JAVA MAVEN PARA NETBEANS

REQUISITOS
1. JDK 17 o superior.
2. Apache NetBeans con soporte Maven.
3. SQL Server funcionando.
4. Haber ejecutado los scripts SQL 01, 02 y 03.
5. Ejecutar también 06_Usuario_Java_FULL_PEDAL_SD.sql, o configurar otra
   cuenta SQL desde el botón "Configurar conexión" de la pantalla de login.

APERTURA EN NETBEANS
1. Archivo > Abrir proyecto.
2. Seleccionar la carpeta FullPedalSD_Java.
3. Esperar que Maven descargue mssql-jdbc.
4. Ejecutar ec.edu.espe.fullpedalsd.App.

USUARIOS DEL APLICATIVO
Administrador:
  usuario: admin
  contraseña: admin123

Usuario normal:
  usuario: vendedor
  contraseña: usuario123

IMPORTANTE
- conexion.properties contiene la cuenta técnica de conexión a SQL Server.
- Los usuarios admin y vendedor pertenecen al aplicativo, no a SQL Server.
- El usuario normal puede vender y consultar, pero no administrar ni eliminar
  productos.
- La venta se registra mediante SP_VENTA_REGISTRAR y una transacción SQL.
