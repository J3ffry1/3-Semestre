package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.VentaDAO;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class CompradoresPanel extends JPanel {

    private final VentaDAO dao = new VentaDAO();
    private final JTable table = new JTable();

    public CompradoresPanel() {
        super(new BorderLayout(8, 8));

        JButton btnConsultar = new JButton(
                "Consultar clientes que realizaron compras");
        btnConsultar.addActionListener(event -> refresh());

        table.setAutoCreateRowSorter(true);

        add(btnConsultar, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void refresh() {
        try {
            table.setModel(dao.compradores());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}
