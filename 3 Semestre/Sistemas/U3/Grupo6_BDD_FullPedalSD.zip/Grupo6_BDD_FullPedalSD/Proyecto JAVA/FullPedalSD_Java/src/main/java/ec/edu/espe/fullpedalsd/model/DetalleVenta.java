package ec.edu.espe.fullpedalsd.model;

import java.math.BigDecimal;

public record DetalleVenta(
        int idBicicleta,
        String codigo,
        String descripcion,
        int cantidad,
        BigDecimal precioUnitario
) {

    public BigDecimal subtotal() {
        return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
    }
}
