package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.AutenticacionDAO;
import ec.edu.espe.fullpedalsd.model.SesionUsuario;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFrame extends JFrame {

    private final JTextField txtUsuario = new JTextField(18);
    private final JPasswordField txtClave = new JPasswordField(18);
    private final AutenticacionDAO autenticacionDAO = new AutenticacionDAO();

    public LoginFrame() {
        super("Full Pedal SD - Inicio de sesión");
        buildUi();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JLabel title = new JLabel("FULL PEDAL SD", JLabel.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 24f));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        form.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;
        form.add(txtClave, gbc);

        JButton btnLogin = new JButton("Ingresar");
        JButton btnConfig = new JButton("Configurar conexión");

        btnLogin.addActionListener(event -> login());
        btnConfig.addActionListener(event -> new ConfigDialog(this).setVisible(true));
        txtClave.addActionListener(event -> login());

        JPanel buttons = new JPanel();
        buttons.add(btnLogin);
        buttons.add(btnConfig);

        add(title, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        getRootPane().setDefaultButton(btnLogin);
    }

    private void login() {
        String usuario = txtUsuario.getText().trim();
        char[] clave = txtClave.getPassword();

        if (usuario.isBlank() || clave.length == 0) {
            Ui.info(this, "Ingrese usuario y contraseña.");
            return;
        }

        try {
            SesionUsuario sesion = autenticacionDAO.iniciarSesion(usuario, clave);

            if (sesion == null) {
                Ui.info(this, "Usuario o contraseña incorrectos.");
                return;
            }

            dispose();
            new MainFrame(sesion).setVisible(true);
        } catch (Exception ex) {
            Ui.error(this, ex);
        } finally {
            Arrays.fill(clave, '\0');
            txtClave.setText("");
        }
    }
}
