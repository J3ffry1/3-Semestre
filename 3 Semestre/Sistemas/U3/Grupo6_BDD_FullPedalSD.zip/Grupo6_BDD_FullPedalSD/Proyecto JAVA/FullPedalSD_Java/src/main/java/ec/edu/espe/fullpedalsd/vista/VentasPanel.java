package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.VentaDAO;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VentasPanel extends JPanel {

    private final VentaDAO dao = new VentaDAO();
    private final JTable table = new JTable();

    public VentasPanel() {
        super(new BorderLayout(8, 8));

        JButton btnActualizar = new JButton("Actualizar ventas");
        btnActualizar.addActionListener(event -> refresh());

        table.setAutoCreateRowSorter(true);

        add(btnActualizar, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        refresh();
    }

    private void refresh() {
        try {
            table.setModel(dao.listar());
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }
}
