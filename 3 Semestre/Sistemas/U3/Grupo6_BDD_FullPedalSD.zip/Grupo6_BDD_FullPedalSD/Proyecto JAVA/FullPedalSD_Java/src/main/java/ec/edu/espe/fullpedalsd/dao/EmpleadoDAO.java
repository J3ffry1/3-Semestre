package ec.edu.espe.fullpedalsd.dao;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.util.DbTableModel;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class EmpleadoDAO {

    public DefaultTableModel listar(boolean soloActivos) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_EMPLEADO_LISTAR(?)}")) {

            statement.setBoolean(1, soloActivos);

            try (ResultSet resultSet = statement.executeQuery()) {
                return DbTableModel.from(resultSet);
            }
        }
    }

    public void insertar(
            int idUsuario,
            String cedula,
            String nombres,
            String apellidos,
            String telefono,
            String correo,
            String cargo,
            int idTienda
    ) throws SQLException {
        String sql = "{call dbo.SP_EMPLEADO_INSERTAR(?, ?, ?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, idUsuario);
            statement.setString(2, cedula);
            statement.setString(3, nombres);
            statement.setString(4, apellidos);
            statement.setString(5, telefono);
            statement.setString(6, correo);
            statement.setString(7, cargo);
            statement.setInt(8, idTienda);
            statement.execute();
        }
    }

    public void modificar(
            int idUsuario,
            int idEmpleado,
            String cedula,
            String nombres,
            String apellidos,
            String telefono,
            String correo,
            String cargo,
            int idTienda
    ) throws SQLException {
        String sql = "{call dbo.SP_EMPLEADO_MODIFICAR(?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, idUsuario);
            statement.setInt(2, idEmpleado);
            statement.setString(3, cedula);
            statement.setString(4, nombres);
            statement.setString(5, apellidos);
            statement.setString(6, telefono);
            statement.setString(7, correo);
            statement.setString(8, cargo);
            statement.setInt(9, idTienda);
            statement.execute();
        }
    }

    public void eliminar(int idUsuario, int idEmpleado) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_EMPLEADO_ELIMINAR(?, ?)}")) {

            statement.setInt(1, idUsuario);
            statement.setInt(2, idEmpleado);
            statement.execute();
        }
    }
}
