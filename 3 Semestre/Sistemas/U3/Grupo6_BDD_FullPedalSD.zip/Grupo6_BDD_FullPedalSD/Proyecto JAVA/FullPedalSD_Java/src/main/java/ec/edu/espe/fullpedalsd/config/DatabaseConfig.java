package ec.edu.espe.fullpedalsd.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class DatabaseConfig {

    private static final Path EXTERNAL_FILE = Path.of("conexion.properties");
    private static final String INTERNAL_FILE = "/conexion.properties";

    private final Properties properties = new Properties();

    public DatabaseConfig() {
        load();
    }

    public void load() {
        properties.clear();

        if (Files.exists(EXTERNAL_FILE)) {
            try (InputStream input = Files.newInputStream(EXTERNAL_FILE)) {
                properties.load(input);
                applyDefaults();
                return;
            } catch (IOException ex) {
                throw new IllegalStateException(
                        "No se pudo leer conexion.properties: " + ex.getMessage(), ex);
            }
        }

        try (InputStream input = DatabaseConfig.class.getResourceAsStream(INTERNAL_FILE)) {
            if (input != null) {
                properties.load(input);
            }
        } catch (IOException ex) {
            throw new IllegalStateException(
                    "No se pudo leer la configuración incluida: " + ex.getMessage(), ex);
        }

        applyDefaults();
    }

    private void applyDefaults() {
        properties.putIfAbsent("db.server", "localhost");
        properties.putIfAbsent("db.port", "1433");
        properties.putIfAbsent("db.instance", "");
        properties.putIfAbsent("db.database", "FULL_PEDAL_SD");
        properties.putIfAbsent("db.user", "fullpedal_app");
        properties.putIfAbsent("db.password", "FullPedal_2026#");
        properties.putIfAbsent("db.encrypt", "true");
        properties.putIfAbsent("db.trustServerCertificate", "true");
    }

    public void save() throws IOException {
        try (OutputStream output = Files.newOutputStream(EXTERNAL_FILE)) {
            properties.store(output, "Configuración de SQL Server - Full Pedal SD");
        }
    }

    public String getServer() {
        return properties.getProperty("db.server", "localhost").trim();
    }

    public void setServer(String value) {
        properties.setProperty("db.server", value.trim());
    }

    public String getPort() {
        return properties.getProperty("db.port", "1433").trim();
    }

    public void setPort(String value) {
        properties.setProperty("db.port", value.trim());
    }

    public String getInstance() {
        return properties.getProperty("db.instance", "").trim();
    }

    public void setInstance(String value) {
        properties.setProperty("db.instance", value.trim());
    }

    public String getDatabase() {
        return properties.getProperty("db.database", "FULL_PEDAL_SD").trim();
    }

    public void setDatabase(String value) {
        properties.setProperty("db.database", value.trim());
    }

    public String getUser() {
        return properties.getProperty("db.user", "").trim();
    }

    public void setUser(String value) {
        properties.setProperty("db.user", value.trim());
    }

    public String getPassword() {
        return properties.getProperty("db.password", "");
    }

    public void setPassword(String value) {
        properties.setProperty("db.password", value);
    }

    public boolean isEncrypt() {
        return Boolean.parseBoolean(properties.getProperty("db.encrypt", "true"));
    }

    public void setEncrypt(boolean value) {
        properties.setProperty("db.encrypt", Boolean.toString(value));
    }

    public boolean isTrustServerCertificate() {
        return Boolean.parseBoolean(
                properties.getProperty("db.trustServerCertificate", "true"));
    }

    public void setTrustServerCertificate(boolean value) {
        properties.setProperty("db.trustServerCertificate", Boolean.toString(value));
    }

    public String buildUrl() {
        StringBuilder url = new StringBuilder("jdbc:sqlserver://")
                .append(getServer());

        if (!getPort().isBlank()) {
            url.append(":").append(getPort());
        }

        url.append(";databaseName=").append(getDatabase());

        if (!getInstance().isBlank()) {
            url.append(";instanceName=").append(getInstance());
        }

        url.append(";encrypt=").append(isEncrypt());
        url.append(";trustServerCertificate=").append(isTrustServerCertificate());
        url.append(";loginTimeout=8;");

        return url.toString();
    }
}
