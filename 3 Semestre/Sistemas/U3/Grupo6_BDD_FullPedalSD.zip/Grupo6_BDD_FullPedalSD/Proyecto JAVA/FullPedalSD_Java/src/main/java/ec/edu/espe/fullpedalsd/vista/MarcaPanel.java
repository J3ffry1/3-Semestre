package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.MarcaDAO;
import ec.edu.espe.fullpedalsd.model.SesionUsuario;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class MarcaPanel extends JPanel {

    private final SesionUsuario sesion;
    private final MarcaDAO dao = new MarcaDAO();

    private final JTextField txtNombre = new JTextField(18);
    private final JTextField txtPais = new JTextField(18);
    private final JTable table = new JTable();
    private Integer selectedId;

    public MarcaPanel(SesionUsuario sesion) {
        super(new BorderLayout(8, 8));
        this.sesion = sesion;
        buildUi();
        refresh();
    }

    private void buildUi() {
        JPanel fields = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fields.add(new JLabel("Marca:"));
        fields.add(txtNombre);
        fields.add(new JLabel("País de origen:"));
        fields.add(txtPais);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnActualizar = new JButton("Actualizar");

        btnGuardar.addActionListener(event -> save());
        btnModificar.addActionListener(event -> update());
        btnEliminar.addActionListener(event -> delete());
        btnLimpiar.addActionListener(event -> clear());
        btnActualizar.addActionListener(event -> refresh());

        JPanel buttons = new JPanel();
        buttons.add(btnGuardar);
        buttons.add(btnModificar);
        buttons.add(btnEliminar);
        buttons.add(btnLimpiar);
        buttons.add(btnActualizar);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                loadSelectedRow();
            }
        });

        JPanel top = new JPanel(new BorderLayout());
        top.add(fields, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void refresh() {
        try {
            table.setModel(dao.listar(false));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void save() {
        try {
            dao.insertar(
                    sesion.idUsuario(),
                    txtNombre.getText().trim(),
                    txtPais.getText().trim()
            );
            Ui.info(this, "Marca registrada correctamente.");
            clear();
            refresh();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void update() {
        try {
            requireSelection();
            dao.modificar(
                    sesion.idUsuario(),
                    selectedId,
                    txtNombre.getText().trim(),
                    txtPais.getText().trim()
            );
            Ui.info(this, "Marca modificada correctamente.");
            clear();
            refresh();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void delete() {
        try {
            requireSelection();
            if (!Ui.confirmar(this,
                    "¿Eliminar la marca? No debe tener bicicletas activas asociadas.")) {
                return;
            }

            dao.eliminar(sesion.idUsuario(), selectedId);
            Ui.info(this, "Marca eliminada correctamente.");
            clear();
            refresh();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }

        int modelRow = table.convertRowIndexToModel(row);
        selectedId = ((Number) table.getModel().getValueAt(modelRow, 0)).intValue();
        txtNombre.setText(value(modelRow, 1));
        txtPais.setText(value(modelRow, 2));
    }

    private String value(int row, int column) {
        Object value = table.getModel().getValueAt(row, column);
        return value == null ? "" : String.valueOf(value);
    }

    private void clear() {
        selectedId = null;
        txtNombre.setText("");
        txtPais.setText("");
        table.clearSelection();
    }

    private void requireSelection() {
        if (selectedId == null) {
            throw new IllegalStateException("Seleccione una marca.");
        }
    }
}
