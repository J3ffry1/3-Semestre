package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.model.SesionUsuario;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class MainFrame extends JFrame {

    public MainFrame(SesionUsuario sesion) {
        super("Full Pedal SD");
        buildUi(sesion);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1180, 720);
        setLocationRelativeTo(null);
    }

    private void buildUi(SesionUsuario sesion) {
        JLabel header = new JLabel(
                "Usuario: " + sesion.nombreUsuario()
                        + " | Rol: " + sesion.nombreRol()
                        + " | Empleado: "
                        + (sesion.nombreEmpleado() == null
                                ? "No asociado"
                                : sesion.nombreEmpleado()),
                SwingConstants.LEFT
        );
        header.setFont(header.getFont().deriveFont(Font.BOLD, 14f));
        header.setBorder(new EmptyBorder(10, 12, 10, 12));

        JTabbedPane tabs = new JTabbedPane();

        if (sesion.puedeGestionarEmpleados()) {
            tabs.addTab("Empleados", new EmpleadoPanel(sesion));
        }

        if (sesion.puedeGestionarMarcas()) {
            tabs.addTab("Marcas", new MarcaPanel(sesion));
        }

        tabs.addTab("Bicicletas", new BicicletaPanel(sesion));
        tabs.addTab("Clientes", new ClientePanel());
        tabs.addTab("Realizar venta", new VentaPanel(sesion));
        tabs.addTab("Clientes compradores", new CompradoresPanel());
        tabs.addTab("Ventas", new VentasPanel());

        JPanel container = new JPanel(new BorderLayout());
        container.add(header, BorderLayout.NORTH);
        container.add(tabs, BorderLayout.CENTER);

        add(container);
    }
}
