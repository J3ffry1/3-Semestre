package ec.edu.espe.fullpedalsd.dao;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.util.DbTableModel;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class ClienteDAO {

    public DefaultTableModel listar(boolean soloActivos) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_CLIENTE_LISTAR(?)}")) {

            statement.setBoolean(1, soloActivos);

            try (ResultSet resultSet = statement.executeQuery()) {
                return DbTableModel.from(resultSet);
            }
        }
    }

    public void insertar(
            String cedula,
            String nombres,
            String apellidos,
            String telefono,
            String correo,
            String direccion
    ) throws SQLException {
        String sql = "{call dbo.SP_CLIENTE_INSERTAR(?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setString(1, cedula);
            statement.setString(2, nombres);
            statement.setString(3, apellidos);
            statement.setString(4, telefono);
            statement.setString(5, correo);
            statement.setString(6, direccion);
            statement.execute();
        }
    }

    public void modificar(
            int idCliente,
            String cedula,
            String nombres,
            String apellidos,
            String telefono,
            String correo,
            String direccion
    ) throws SQLException {
        String sql = "{call dbo.SP_CLIENTE_MODIFICAR(?, ?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, idCliente);
            statement.setString(2, cedula);
            statement.setString(3, nombres);
            statement.setString(4, apellidos);
            statement.setString(5, telefono);
            statement.setString(6, correo);
            statement.setString(7, direccion);
            statement.execute();
        }
    }
}
