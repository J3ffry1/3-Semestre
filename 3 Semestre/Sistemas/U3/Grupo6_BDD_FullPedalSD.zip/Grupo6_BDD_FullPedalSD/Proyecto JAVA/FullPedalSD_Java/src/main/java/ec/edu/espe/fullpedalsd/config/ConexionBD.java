package ec.edu.espe.fullpedalsd.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConexionBD {

    private static DatabaseConfig config = new DatabaseConfig();

    private ConexionBD() {
    }

    public static synchronized void reload() {
        config = new DatabaseConfig();
    }

    public static DatabaseConfig getConfig() {
        return config;
    }

    public static Connection obtenerConexion() throws SQLException {
        return DriverManager.getConnection(
                config.buildUrl(),
                config.getUser(),
                config.getPassword()
        );
    }

    public static void probarConexion() throws SQLException {
        try (Connection connection = obtenerConexion()) {
            if (!connection.isValid(5)) {
                throw new SQLException("SQL Server no confirmó una conexión válida.");
            }
        }
    }
}
