package ec.edu.espe.fullpedalsd.util;

import java.awt.Component;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public final class Ui {

    private Ui() {
    }

    public static void info(Component parent, String message) {
        JOptionPane.showMessageDialog(
                parent, message, "Full Pedal SD", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component parent, Throwable throwable) {
        JOptionPane.showMessageDialog(
                parent,
                friendlyMessage(throwable),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    public static boolean confirmar(Component parent, String message) {
        return JOptionPane.showConfirmDialog(
                parent,
                message,
                "Confirmar",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        ) == JOptionPane.YES_OPTION;
    }

    public static int selectedId(JTable table, int modelColumn) {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            throw new IllegalStateException("Seleccione una fila de la tabla.");
        }

        int modelRow = table.convertRowIndexToModel(viewRow);
        Object value = table.getModel().getValueAt(modelRow, modelColumn);

        if (value instanceof Number number) {
            return number.intValue();
        }

        return Integer.parseInt(String.valueOf(value));
    }

    public static String friendlyMessage(Throwable throwable) {
        Throwable current = throwable;

        while (current != null) {
            if (current instanceof SQLException sqlException) {
                String message = sqlException.getMessage();
                if (message != null && !message.isBlank()) {
                    return message;
                }
            }
            current = current.getCause();
        }

        String message = throwable.getMessage();
        return message == null || message.isBlank()
                ? throwable.getClass().getSimpleName()
                : message;
    }
}
