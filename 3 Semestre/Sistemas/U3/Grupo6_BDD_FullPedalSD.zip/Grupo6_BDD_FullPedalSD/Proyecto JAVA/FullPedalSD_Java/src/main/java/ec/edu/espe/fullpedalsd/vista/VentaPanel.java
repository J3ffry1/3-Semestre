package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.BicicletaDAO;
import ec.edu.espe.fullpedalsd.dao.CatalogoDAO;
import ec.edu.espe.fullpedalsd.dao.VentaDAO;
import ec.edu.espe.fullpedalsd.model.BicicletaVentaInfo;
import ec.edu.espe.fullpedalsd.model.ComboItem;
import ec.edu.espe.fullpedalsd.model.DetalleVenta;
import ec.edu.espe.fullpedalsd.model.SesionUsuario;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

public class VentaPanel extends JPanel {

    private final SesionUsuario sesion;
    private final CatalogoDAO catalogoDAO = new CatalogoDAO();
    private final BicicletaDAO bicicletaDAO = new BicicletaDAO();
    private final VentaDAO ventaDAO = new VentaDAO();

    private final JComboBox<ComboItem> cmbCliente = new JComboBox<>();
    private final JComboBox<ComboItem> cmbBicicleta = new JComboBox<>();
    private final JSpinner spnCantidad =
            new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
    private final JTextField txtObservacion = new JTextField(22);
    private final JLabel lblTotal = new JLabel("Total: $0.00");
    private final JTable table = new JTable();

    private final List<DetalleVenta> detalles = new ArrayList<>();

    public VentaPanel(SesionUsuario sesion) {
        super(new BorderLayout(8, 8));
        this.sesion = sesion;
        buildUi();
        loadCatalogs();
        refreshDetailTable();
    }

    private void buildUi() {
        JPanel saleHeader = new JPanel(new FlowLayout(FlowLayout.LEFT));
        saleHeader.add(new JLabel("Cliente:"));
        cmbCliente.setPrototypeDisplayValue(
                new ComboItem(0, "2300000000 - Nombre completo del cliente"));
        saleHeader.add(cmbCliente);
        saleHeader.add(new JLabel("Observación:"));
        saleHeader.add(txtObservacion);

        JPanel productBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        productBar.add(new JLabel("Bicicleta:"));
        cmbBicicleta.setPrototypeDisplayValue(
                new ComboItem(0, "BIC-000 - Marca Modelo | Stock: 000"));
        productBar.add(cmbBicicleta);
        productBar.add(new JLabel("Cantidad:"));
        productBar.add(spnCantidad);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnQuitar = new JButton("Quitar seleccionado");
        JButton btnActualizar = new JButton("Actualizar catálogos");

        btnAgregar.addActionListener(event -> addProduct());
        btnQuitar.addActionListener(event -> removeSelected());
        btnActualizar.addActionListener(event -> loadCatalogs());

        productBar.add(btnAgregar);
        productBar.add(btnQuitar);
        productBar.add(btnActualizar);

        JButton btnRegistrar = new JButton("REGISTRAR VENTA");
        JButton btnCancelar = new JButton("Limpiar venta");

        btnRegistrar.addActionListener(event -> registerSale());
        btnCancelar.addActionListener(event -> clearSale());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(lblTotal);
        bottom.add(btnCancelar);
        bottom.add(btnRegistrar);

        JPanel top = new JPanel(new BorderLayout());
        top.add(saleHeader, BorderLayout.NORTH);
        top.add(productBar, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
    }

    private void loadCatalogs() {
        try {
            cmbCliente.removeAllItems();
            for (ComboItem item : catalogoDAO.listarClientes()) {
                cmbCliente.addItem(item);
            }

            cmbBicicleta.removeAllItems();
            for (ComboItem item : catalogoDAO.listarBicicletasConStock()) {
                cmbBicicleta.addItem(item);
            }
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void addProduct() {
        try {
            ComboItem selected = (ComboItem) cmbBicicleta.getSelectedItem();
            if (selected == null) {
                throw new IllegalStateException("No hay bicicletas disponibles.");
            }

            int quantity = (Integer) spnCantidad.getValue();

            if (detalles.stream().anyMatch(
                    item -> item.idBicicleta() == selected.id())) {
                throw new IllegalStateException(
                        "La bicicleta ya está agregada. Quítela y vuelva a agregarla.");
            }

            BicicletaVentaInfo info = bicicletaDAO.obtenerInfoVenta(selected.id());

            detalles.add(new DetalleVenta(
                    info.idBicicleta(),
                    info.codigo(),
                    info.descripcion(),
                    quantity,
                    info.precio()
            ));

            refreshDetailTable();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void removeSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Ui.info(this, "Seleccione un detalle.");
            return;
        }

        int modelRow = table.convertRowIndexToModel(row);
        detalles.remove(modelRow);
        refreshDetailTable();
    }

    private void refreshDetailTable() {
        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"ID", "Código", "Bicicleta", "Cantidad",
                    "Precio unitario", "Subtotal"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        BigDecimal total = BigDecimal.ZERO;

        for (DetalleVenta detail : detalles) {
            model.addRow(new Object[]{
                detail.idBicicleta(),
                detail.codigo(),
                detail.descripcion(),
                detail.cantidad(),
                detail.precioUnitario(),
                detail.subtotal()
            });
            total = total.add(detail.subtotal());
        }

        table.setModel(model);
        lblTotal.setText("Total: $" + total);
    }

    private void registerSale() {
        try {
            if (sesion.idEmpleado() == null) {
                throw new IllegalStateException(
                        "El usuario no está asociado a un empleado.");
            }

            ComboItem client = (ComboItem) cmbCliente.getSelectedItem();
            if (client == null) {
                throw new IllegalStateException("Seleccione un cliente.");
            }

            if (detalles.isEmpty()) {
                throw new IllegalStateException("Agregue al menos una bicicleta.");
            }

            int saleId = ventaDAO.registrar(
                    client.id(),
                    sesion.idEmpleado(),
                    sesion.idUsuario(),
                    List.copyOf(detalles),
                    txtObservacion.getText().trim()
            );

            Ui.info(this, "Venta registrada correctamente. ID: " + saleId);
            clearSale();
            loadCatalogs();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void clearSale() {
        detalles.clear();
        txtObservacion.setText("");
        spnCantidad.setValue(1);
        refreshDetailTable();
    }
}
