package ec.edu.espe.fullpedalsd.dao;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.model.ComboItem;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CatalogoDAO {

    public List<ComboItem> listarTiendas() throws SQLException {
        return ejecutarCombo(
                "{call dbo.SP_TIENDA_LISTAR}",
                "ID_TIENDA",
                "NOMBRE"
        );
    }

    public List<ComboItem> listarMarcas() throws SQLException {
        List<ComboItem> items = new ArrayList<>();

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(
                     "{call dbo.SP_MARCA_LISTAR(?)}")) {

            statement.setBoolean(1, true);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    items.add(new ComboItem(
                            resultSet.getInt("ID_MARCA"),
                            resultSet.getString("NOMBRE_MARCA")
                    ));
                }
            }
        }

        return items;
    }

    public List<ComboItem> listarTipos() throws SQLException {
        return ejecutarCombo(
                "{call dbo.SP_TIPO_BICICLETA_LISTAR}",
                "ID_TIPO",
                "NOMBRE_TIPO"
        );
    }

    public List<ComboItem> listarClientes() throws SQLException {
        String sql = "{call dbo.SP_CLIENTE_LISTAR(?)}";
        List<ComboItem> items = new ArrayList<>();

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setBoolean(1, true);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    items.add(new ComboItem(
                            resultSet.getInt("ID_CLIENTE"),
                            resultSet.getString("CEDULA") + " - "
                                    + resultSet.getString("NOMBRES") + " "
                                    + resultSet.getString("APELLIDOS")
                    ));
                }
            }
        }

        return items;
    }

    public List<ComboItem> listarBicicletasConStock() throws SQLException {
        String sql = "{call dbo.SP_BICICLETA_LISTAR(?)}";
        List<ComboItem> items = new ArrayList<>();

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setBoolean(1, true);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int stock = resultSet.getInt("STOCK");
                    if (stock > 0) {
                        items.add(new ComboItem(
                                resultSet.getInt("ID_BICICLETA"),
                                resultSet.getString("CODIGO") + " - "
                                        + resultSet.getString("NOMBRE_MARCA") + " "
                                        + resultSet.getString("MODELO")
                                        + " | Stock: " + stock
                        ));
                    }
                }
            }
        }

        return items;
    }

    private List<ComboItem> ejecutarCombo(
            String sql,
            String idColumn,
            String textColumn
    ) throws SQLException {
        List<ComboItem> items = new ArrayList<>();

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                items.add(new ComboItem(
                        resultSet.getInt(idColumn),
                        resultSet.getString(textColumn)
                ));
            }
        }

        return items;
    }
}
