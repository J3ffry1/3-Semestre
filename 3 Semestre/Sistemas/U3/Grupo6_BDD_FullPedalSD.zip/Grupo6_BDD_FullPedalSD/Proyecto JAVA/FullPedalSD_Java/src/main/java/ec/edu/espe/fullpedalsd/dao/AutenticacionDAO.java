package ec.edu.espe.fullpedalsd.dao;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.model.SesionUsuario;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AutenticacionDAO {

    public SesionUsuario iniciarSesion(String usuario, char[] clave) throws SQLException {
        String sql = "{call dbo.SP_INICIAR_SESION(?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setString(1, usuario.trim());
            statement.setString(2, new String(clave));

            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return null;
                }

                int empleado = resultSet.getInt("ID_EMPLEADO");
                Integer idEmpleado = resultSet.wasNull() ? null : empleado;

                return new SesionUsuario(
                        resultSet.getInt("ID_USUARIO"),
                        resultSet.getString("NOMBRE_USUARIO"),
                        resultSet.getInt("ID_ROL"),
                        resultSet.getString("NOMBRE_ROL"),
                        resultSet.getBoolean("PUEDE_GESTIONAR_EMPLEADOS"),
                        resultSet.getBoolean("PUEDE_GESTIONAR_MARCAS"),
                        resultSet.getBoolean("PUEDE_GESTIONAR_PRODUCTOS"),
                        resultSet.getBoolean("PUEDE_ELIMINAR_PRODUCTO"),
                        idEmpleado,
                        resultSet.getString("NOMBRE_EMPLEADO")
                );
            }
        }
    }
}
