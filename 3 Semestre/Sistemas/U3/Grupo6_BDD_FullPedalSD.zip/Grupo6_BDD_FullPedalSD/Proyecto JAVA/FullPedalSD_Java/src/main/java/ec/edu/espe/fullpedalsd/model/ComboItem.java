package ec.edu.espe.fullpedalsd.model;

public record ComboItem(int id, String texto) {

    @Override
    public String toString() {
        return texto;
    }
}
