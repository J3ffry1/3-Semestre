package ec.edu.espe.fullpedalsd.dao;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.util.DbTableModel;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class MarcaDAO {

    public DefaultTableModel listar(boolean soloActivas) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_MARCA_LISTAR(?)}")) {

            statement.setBoolean(1, soloActivas);

            try (ResultSet resultSet = statement.executeQuery()) {
                return DbTableModel.from(resultSet);
            }
        }
    }

    public void insertar(int idUsuario, String nombre, String pais) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_MARCA_INSERTAR(?, ?, ?)}")) {

            statement.setInt(1, idUsuario);
            statement.setString(2, nombre);
            statement.setString(3, pais);
            statement.execute();
        }
    }

    public void modificar(
            int idUsuario,
            int idMarca,
            String nombre,
            String pais
    ) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_MARCA_MODIFICAR(?, ?, ?, ?)}")) {

            statement.setInt(1, idUsuario);
            statement.setInt(2, idMarca);
            statement.setString(3, nombre);
            statement.setString(4, pais);
            statement.execute();
        }
    }

    public void eliminar(int idUsuario, int idMarca) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_MARCA_ELIMINAR(?, ?)}")) {

            statement.setInt(1, idUsuario);
            statement.setInt(2, idMarca);
            statement.execute();
        }
    }
}
