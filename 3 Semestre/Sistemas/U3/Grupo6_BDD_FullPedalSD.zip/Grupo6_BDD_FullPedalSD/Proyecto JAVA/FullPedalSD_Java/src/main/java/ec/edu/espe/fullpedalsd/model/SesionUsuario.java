package ec.edu.espe.fullpedalsd.model;

public record SesionUsuario(
        int idUsuario,
        String nombreUsuario,
        int idRol,
        String nombreRol,
        boolean puedeGestionarEmpleados,
        boolean puedeGestionarMarcas,
        boolean puedeGestionarProductos,
        boolean puedeEliminarProducto,
        Integer idEmpleado,
        String nombreEmpleado
) {

    public boolean esAdministrador() {
        return "ADMIN".equalsIgnoreCase(nombreRol);
    }
}
