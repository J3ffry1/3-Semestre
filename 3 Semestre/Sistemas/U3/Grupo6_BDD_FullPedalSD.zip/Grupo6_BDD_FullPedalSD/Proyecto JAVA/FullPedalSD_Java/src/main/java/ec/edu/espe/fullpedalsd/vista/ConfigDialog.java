package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.config.DatabaseConfig;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ConfigDialog extends JDialog {

    private final JTextField txtServer = new JTextField(18);
    private final JTextField txtPort = new JTextField(8);
    private final JTextField txtInstance = new JTextField(12);
    private final JTextField txtDatabase = new JTextField(18);
    private final JTextField txtUser = new JTextField(18);
    private final JPasswordField txtPassword = new JPasswordField(18);
    private final JCheckBox chkEncrypt = new JCheckBox("Cifrar conexión");
    private final JCheckBox chkTrust = new JCheckBox("Confiar en certificado local");

    public ConfigDialog(Component parent) {
        super(javax.swing.SwingUtilities.getWindowAncestor(parent),
                "Configurar conexión", ModalityType.APPLICATION_MODAL);
        buildUi();
        loadValues();
        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    private void buildUi() {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 7, 5, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addRow(form, gbc, 0, "Servidor:", txtServer);
        addRow(form, gbc, 1, "Puerto:", txtPort);
        addRow(form, gbc, 2, "Instancia opcional:", txtInstance);
        addRow(form, gbc, 3, "Base de datos:", txtDatabase);
        addRow(form, gbc, 4, "Usuario SQL:", txtUser);
        addRow(form, gbc, 5, "Contraseña SQL:", txtPassword);

        gbc.gridx = 1;
        gbc.gridy = 6;
        form.add(chkEncrypt, gbc);
        gbc.gridy = 7;
        form.add(chkTrust, gbc);

        JButton btnTest = new JButton("Probar");
        JButton btnSave = new JButton("Guardar");
        JButton btnCancel = new JButton("Cancelar");

        btnTest.addActionListener(event -> testConnection());
        btnSave.addActionListener(event -> save());
        btnCancel.addActionListener(event -> dispose());

        JPanel buttons = new JPanel();
        buttons.add(btnTest);
        buttons.add(btnSave);
        buttons.add(btnCancel);

        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
    }

    private void addRow(
            JPanel panel,
            GridBagConstraints gbc,
            int row,
            String label,
            Component field
    ) {
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private void loadValues() {
        DatabaseConfig config = ConexionBD.getConfig();
        txtServer.setText(config.getServer());
        txtPort.setText(config.getPort());
        txtInstance.setText(config.getInstance());
        txtDatabase.setText(config.getDatabase());
        txtUser.setText(config.getUser());
        txtPassword.setText(config.getPassword());
        chkEncrypt.setSelected(config.isEncrypt());
        chkTrust.setSelected(config.isTrustServerCertificate());
    }

    private void applyValues(DatabaseConfig config) {
        config.setServer(txtServer.getText());
        config.setPort(txtPort.getText());
        config.setInstance(txtInstance.getText());
        config.setDatabase(txtDatabase.getText());
        config.setUser(txtUser.getText());
        config.setPassword(new String(txtPassword.getPassword()));
        config.setEncrypt(chkEncrypt.isSelected());
        config.setTrustServerCertificate(chkTrust.isSelected());
    }

    private void testConnection() {
        try {
            applyValues(ConexionBD.getConfig());
            ConexionBD.probarConexion();
            Ui.info(this, "Conexión realizada correctamente.");
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void save() {
        try {
            DatabaseConfig config = ConexionBD.getConfig();
            applyValues(config);
            config.save();
            ConexionBD.reload();
            Ui.info(this, "Configuración guardada.");
            dispose();
        } catch (IOException ex) {
            Ui.error(this, ex);
        }
    }
}
