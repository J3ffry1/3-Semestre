package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.ClienteDAO;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class ClientePanel extends JPanel {

    private final ClienteDAO dao = new ClienteDAO();

    private final JTextField txtCedula = new JTextField(12);
    private final JTextField txtNombres = new JTextField(15);
    private final JTextField txtApellidos = new JTextField(15);
    private final JTextField txtTelefono = new JTextField(12);
    private final JTextField txtCorreo = new JTextField(18);
    private final JTextField txtDireccion = new JTextField(20);
    private final JTable table = new JTable();
    private Integer selectedId;

    public ClientePanel() {
        super(new BorderLayout(8, 8));
        buildUi();
        refresh();
    }

    private void buildUi() {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 5, 4, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addField(form, gbc, 0, 0, "Cédula:", txtCedula);
        addField(form, gbc, 0, 2, "Nombres:", txtNombres);
        addField(form, gbc, 1, 0, "Apellidos:", txtApellidos);
        addField(form, gbc, 1, 2, "Teléfono:", txtTelefono);
        addField(form, gbc, 2, 0, "Correo:", txtCorreo);
        addField(form, gbc, 2, 2, "Dirección:", txtDireccion);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnActualizar = new JButton("Actualizar");

        btnGuardar.addActionListener(event -> save());
        btnModificar.addActionListener(event -> update());
        btnLimpiar.addActionListener(event -> clear());
        btnActualizar.addActionListener(event -> refresh());

        JPanel buttons = new JPanel();
        buttons.add(btnGuardar);
        buttons.add(btnModificar);
        buttons.add(btnLimpiar);
        buttons.add(btnActualizar);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                loadSelectedRow();
            }
        });

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void addField(
            JPanel panel,
            GridBagConstraints gbc,
            int row,
            int column,
            String label,
            java.awt.Component field
    ) {
        gbc.gridx = column;
        gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = column + 1;
        panel.add(field, gbc);
    }

    private void refresh() {
        try {
            table.setModel(dao.listar(false));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void save() {
        try {
            dao.insertar(
                    txtCedula.getText().trim(),
                    txtNombres.getText().trim(),
                    txtApellidos.getText().trim(),
                    txtTelefono.getText().trim(),
                    txtCorreo.getText().trim(),
                    txtDireccion.getText().trim()
            );
            Ui.info(this, "Cliente registrado correctamente.");
            clear();
            refresh();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void update() {
        try {
            requireSelection();
            dao.modificar(
                    selectedId,
                    txtCedula.getText().trim(),
                    txtNombres.getText().trim(),
                    txtApellidos.getText().trim(),
                    txtTelefono.getText().trim(),
                    txtCorreo.getText().trim(),
                    txtDireccion.getText().trim()
            );
            Ui.info(this, "Cliente modificado correctamente.");
            clear();
            refresh();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }

        int modelRow = table.convertRowIndexToModel(row);
        selectedId = ((Number) table.getModel().getValueAt(modelRow, 0)).intValue();
        txtCedula.setText(value(modelRow, 1));
        txtNombres.setText(value(modelRow, 2));
        txtApellidos.setText(value(modelRow, 3));
        txtTelefono.setText(value(modelRow, 4));
        txtCorreo.setText(value(modelRow, 5));
        txtDireccion.setText(value(modelRow, 6));
    }

    private String value(int row, int column) {
        Object value = table.getModel().getValueAt(row, column);
        return value == null ? "" : String.valueOf(value);
    }

    private void clear() {
        selectedId = null;
        txtCedula.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
        table.clearSelection();
    }

    private void requireSelection() {
        if (selectedId == null) {
            throw new IllegalStateException("Seleccione un cliente.");
        }
    }
}
