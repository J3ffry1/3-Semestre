package ec.edu.espe.fullpedalsd.model;

import java.math.BigDecimal;

public record BicicletaVentaInfo(
        int idBicicleta,
        String codigo,
        String descripcion,
        BigDecimal precio
) {
}
