package ec.edu.espe.fullpedalsd.vista;

import ec.edu.espe.fullpedalsd.dao.BicicletaDAO;
import ec.edu.espe.fullpedalsd.dao.CatalogoDAO;
import ec.edu.espe.fullpedalsd.model.ComboItem;
import ec.edu.espe.fullpedalsd.model.SesionUsuario;
import ec.edu.espe.fullpedalsd.util.Ui;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;

public class BicicletaPanel extends JPanel {

    private final SesionUsuario sesion;
    private final BicicletaDAO dao = new BicicletaDAO();
    private final CatalogoDAO catalogoDAO = new CatalogoDAO();

    private final JTextField txtCodigo = new JTextField(10);
    private final JTextField txtModelo = new JTextField(16);
    private final JComboBox<ComboItem> cmbMarca = new JComboBox<>();
    private final JComboBox<ComboItem> cmbTipo = new JComboBox<>();
    private final JTextField txtColor = new JTextField(10);
    private final JTextField txtTalla = new JTextField(8);
    private final JTextField txtPrecio = new JTextField(10);
    private final JSpinner spnStock = new JSpinner(new SpinnerNumberModel(0, 0, 100000, 1));
    private final JTable table = new JTable();

    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnModificar = new JButton("Modificar");
    private final JButton btnEliminar = new JButton("Eliminar");
    private Integer selectedId;

    public BicicletaPanel(SesionUsuario sesion) {
        super(new BorderLayout(8, 8));
        this.sesion = sesion;
        buildUi();
        applyPermissions();
        loadCatalogs();
        refresh();
    }

    private void buildUi() {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 5, 4, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addField(form, gbc, 0, 0, "Código:", txtCodigo);
        addField(form, gbc, 0, 2, "Modelo:", txtModelo);
        addField(form, gbc, 0, 4, "Marca:", cmbMarca);
        addField(form, gbc, 1, 0, "Tipo:", cmbTipo);
        addField(form, gbc, 1, 2, "Color:", txtColor);
        addField(form, gbc, 1, 4, "Talla:", txtTalla);
        addField(form, gbc, 2, 0, "Precio:", txtPrecio);
        addField(form, gbc, 2, 2, "Stock:", spnStock);

        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnActualizar = new JButton("Actualizar");

        btnGuardar.addActionListener(event -> save());
        btnModificar.addActionListener(event -> update());
        btnEliminar.addActionListener(event -> delete());
        btnLimpiar.addActionListener(event -> clear());
        btnActualizar.addActionListener(event -> {
            loadCatalogs();
            refresh();
        });

        JPanel buttons = new JPanel();
        buttons.add(btnGuardar);
        buttons.add(btnModificar);
        buttons.add(btnEliminar);
        buttons.add(btnLimpiar);
        buttons.add(btnActualizar);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                loadSelectedRow();
            }
        });

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void addField(
            JPanel panel,
            GridBagConstraints gbc,
            int row,
            int column,
            String label,
            java.awt.Component field
    ) {
        gbc.gridx = column;
        gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = column + 1;
        panel.add(field, gbc);
    }

    private void applyPermissions() {
        boolean manage = sesion.puedeGestionarProductos();
        btnGuardar.setEnabled(manage);
        btnModificar.setEnabled(manage);
        btnEliminar.setEnabled(sesion.puedeEliminarProducto());

        txtCodigo.setEditable(manage);
        txtModelo.setEditable(manage);
        cmbMarca.setEnabled(manage);
        cmbTipo.setEnabled(manage);
        txtColor.setEditable(manage);
        txtTalla.setEditable(manage);
        txtPrecio.setEditable(manage);
        spnStock.setEnabled(manage);
    }

    private void loadCatalogs() {
        try {
            cmbMarca.removeAllItems();
            for (ComboItem item : catalogoDAO.listarMarcas()) {
                cmbMarca.addItem(item);
            }

            cmbTipo.removeAllItems();
            for (ComboItem item : catalogoDAO.listarTipos()) {
                cmbTipo.addItem(item);
            }
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void refresh() {
        try {
            table.setModel(dao.listar(false));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void save() {
        try {
            ComboItem marca = requireCombo(cmbMarca, "Seleccione una marca.");
            ComboItem tipo = requireCombo(cmbTipo, "Seleccione un tipo.");

            dao.insertar(
                    sesion.idUsuario(),
                    txtCodigo.getText().trim(),
                    txtModelo.getText().trim(),
                    marca.id(),
                    tipo.id(),
                    txtColor.getText().trim(),
                    txtTalla.getText().trim(),
                    new BigDecimal(txtPrecio.getText().trim()),
                    (Integer) spnStock.getValue()
            );

            Ui.info(this, "Bicicleta registrada correctamente.");
            clear();
            refresh();
        } catch (NumberFormatException ex) {
            Ui.error(this, new IllegalArgumentException("Ingrese un precio válido."));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void update() {
        try {
            requireSelection();
            ComboItem marca = requireCombo(cmbMarca, "Seleccione una marca.");
            ComboItem tipo = requireCombo(cmbTipo, "Seleccione un tipo.");

            dao.modificar(
                    sesion.idUsuario(),
                    selectedId,
                    txtCodigo.getText().trim(),
                    txtModelo.getText().trim(),
                    marca.id(),
                    tipo.id(),
                    txtColor.getText().trim(),
                    txtTalla.getText().trim(),
                    new BigDecimal(txtPrecio.getText().trim()),
                    (Integer) spnStock.getValue()
            );

            Ui.info(this, "Bicicleta modificada correctamente.");
            clear();
            refresh();
        } catch (NumberFormatException ex) {
            Ui.error(this, new IllegalArgumentException("Ingrese un precio válido."));
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void delete() {
        try {
            requireSelection();
            if (!Ui.confirmar(this, "¿Eliminar lógicamente la bicicleta?")) {
                return;
            }

            dao.eliminar(sesion.idUsuario(), selectedId);
            Ui.info(this, "Bicicleta eliminada correctamente.");
            clear();
            refresh();
        } catch (Exception ex) {
            Ui.error(this, ex);
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }

        int modelRow = table.convertRowIndexToModel(row);
        selectedId = intValue(modelRow, 0);
        txtCodigo.setText(value(modelRow, 1));
        txtModelo.setText(value(modelRow, 2));
        selectCombo(cmbMarca, intValue(modelRow, 3));
        selectCombo(cmbTipo, intValue(modelRow, 5));
        txtColor.setText(value(modelRow, 7));
        txtTalla.setText(value(modelRow, 8));
        txtPrecio.setText(value(modelRow, 9));
        spnStock.setValue(intValue(modelRow, 10));
    }

    private int intValue(int row, int column) {
        return ((Number) table.getModel().getValueAt(row, column)).intValue();
    }

    private String value(int row, int column) {
        Object value = table.getModel().getValueAt(row, column);
        return value == null ? "" : String.valueOf(value);
    }

    private void clear() {
        selectedId = null;
        txtCodigo.setText("");
        txtModelo.setText("");
        txtColor.setText("");
        txtTalla.setText("");
        txtPrecio.setText("");
        spnStock.setValue(0);
        table.clearSelection();
    }

    private void requireSelection() {
        if (selectedId == null) {
            throw new IllegalStateException("Seleccione una bicicleta.");
        }
    }

    private ComboItem requireCombo(JComboBox<ComboItem> combo, String message) {
        ComboItem item = (ComboItem) combo.getSelectedItem();
        if (item == null) {
            throw new IllegalStateException(message);
        }
        return item;
    }

    private void selectCombo(JComboBox<ComboItem> combo, int id) {
        for (int index = 0; index < combo.getItemCount(); index++) {
            if (combo.getItemAt(index).id() == id) {
                combo.setSelectedIndex(index);
                break;
            }
        }
    }
}
