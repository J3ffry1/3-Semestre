package ec.edu.espe.fullpedalsd;

import ec.edu.espe.fullpedalsd.vista.LoginFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public final class App {

    private App() {
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // Se conserva el aspecto predeterminado de Swing.
            }

            new LoginFrame().setVisible(true);
        });
    }
}
