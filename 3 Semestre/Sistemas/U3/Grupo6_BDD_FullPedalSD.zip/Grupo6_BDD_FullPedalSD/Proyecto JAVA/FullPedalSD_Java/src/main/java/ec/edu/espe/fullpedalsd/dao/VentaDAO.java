package ec.edu.espe.fullpedalsd.dao;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.model.DetalleVenta;
import ec.edu.espe.fullpedalsd.util.DbTableModel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class VentaDAO {

    public int registrar(
            int idCliente,
            int idEmpleado,
            int idUsuario,
            List<DetalleVenta> detalles,
            String observacion
    ) throws SQLException {
        SQLServerDataTable table = new SQLServerDataTable();
        table.addColumnMetadata("ID_BICICLETA", Types.INTEGER);
        table.addColumnMetadata("CANTIDAD", Types.INTEGER);

        for (DetalleVenta detalle : detalles) {
            table.addRow(detalle.idBicicleta(), detalle.cantidad());
        }

        String sql = "{call dbo.SP_VENTA_REGISTRAR(?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             SQLServerCallableStatement statement =
                     (SQLServerCallableStatement) connection.prepareCall(sql)) {

            statement.setInt(1, idCliente);
            statement.setInt(2, idEmpleado);
            statement.setInt(3, idUsuario);
            statement.setStructured(4, "dbo.TIPO_DETALLE_VENTA", table);
            statement.setString(5, observacion);
            statement.registerOutParameter(6, Types.INTEGER);
            statement.execute();

            return statement.getInt(6);
        }
    }

    public DefaultTableModel listar() throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             SQLServerCallableStatement statement =
                     (SQLServerCallableStatement) connection.prepareCall(
                             "{call dbo.SP_VENTA_LISTAR}");
             ResultSet resultSet = statement.executeQuery()) {

            return DbTableModel.from(resultSet);
        }
    }

    public DefaultTableModel compradores() throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             SQLServerCallableStatement statement =
                     (SQLServerCallableStatement) connection.prepareCall(
                             "{call dbo.SP_CLIENTES_QUE_COMPRARON}");
             ResultSet resultSet = statement.executeQuery()) {

            return DbTableModel.from(resultSet);
        }
    }
}
