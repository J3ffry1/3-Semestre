package ec.edu.espe.fullpedalsd.dao;

import ec.edu.espe.fullpedalsd.config.ConexionBD;
import ec.edu.espe.fullpedalsd.model.BicicletaVentaInfo;
import ec.edu.espe.fullpedalsd.util.DbTableModel;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class BicicletaDAO {

    public DefaultTableModel listar(boolean soloActivas) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_BICICLETA_LISTAR(?)}")) {

            statement.setBoolean(1, soloActivas);

            try (ResultSet resultSet = statement.executeQuery()) {
                return DbTableModel.from(resultSet);
            }
        }
    }

    public void insertar(
            int idUsuario,
            String codigo,
            String modelo,
            int idMarca,
            int idTipo,
            String color,
            String talla,
            BigDecimal precio,
            int stock
    ) throws SQLException {
        String sql = "{call dbo.SP_BICICLETA_INSERTAR(?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, idUsuario);
            statement.setString(2, codigo);
            statement.setString(3, modelo);
            statement.setInt(4, idMarca);
            statement.setInt(5, idTipo);
            statement.setString(6, color);
            statement.setString(7, talla);
            statement.setBigDecimal(8, precio);
            statement.setInt(9, stock);
            statement.execute();
        }
    }

    public void modificar(
            int idUsuario,
            int idBicicleta,
            String codigo,
            String modelo,
            int idMarca,
            int idTipo,
            String color,
            String talla,
            BigDecimal precio,
            int stock
    ) throws SQLException {
        String sql = "{call dbo.SP_BICICLETA_MODIFICAR(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setInt(1, idUsuario);
            statement.setInt(2, idBicicleta);
            statement.setString(3, codigo);
            statement.setString(4, modelo);
            statement.setInt(5, idMarca);
            statement.setInt(6, idTipo);
            statement.setString(7, color);
            statement.setString(8, talla);
            statement.setBigDecimal(9, precio);
            statement.setInt(10, stock);
            statement.execute();
        }
    }

    public void eliminar(int idUsuario, int idBicicleta) throws SQLException {
        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement =
                     connection.prepareCall("{call dbo.SP_BICICLETA_ELIMINAR(?, ?)}")) {

            statement.setInt(1, idUsuario);
            statement.setInt(2, idBicicleta);
            statement.execute();
        }
    }

    public BicicletaVentaInfo obtenerInfoVenta(int idBicicleta) throws SQLException {
        String sql = "{call dbo.SP_BICICLETA_LISTAR(?)}";

        try (Connection connection = ConexionBD.obtenerConexion();
             CallableStatement statement = connection.prepareCall(sql)) {

            statement.setBoolean(1, true);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    if (resultSet.getInt("ID_BICICLETA") == idBicicleta) {
                        return new BicicletaVentaInfo(
                                idBicicleta,
                                resultSet.getString("CODIGO"),
                                resultSet.getString("NOMBRE_MARCA") + " "
                                        + resultSet.getString("MODELO"),
                                resultSet.getBigDecimal("PRECIO_VENTA")
                        );
                    }
                }
            }
        }

        throw new SQLException("No se encontró la bicicleta seleccionada.");
    }
}
