package com.fastbite.model;

import com.fastbite.ds.DeliveryGraph;
import com.fastbite.ds.DijkstraResult;

import java.util.ArrayList;
import java.util.List;

public class OrderState {
    private final List<OrderItem> items = new ArrayList<>();
    private LocationNode selectedLocationNode;
    private DijkstraResult currentDijkstraResult;

    public void addItem(MenuItem menuItem) {
        for (OrderItem item : items) {
            if (item.getMenuItem().getId().equals(menuItem.getId())) {
                item.setQuantity(item.getQuantity() + 1);
                return;
            }
        }
        items.add(new OrderItem(menuItem, 1));
    }

    public void updateQuantity(String menuItemId, int newQuantity) {
        if (newQuantity <= 0) {
            items.removeIf(item -> item.getMenuItem().getId().equals(menuItemId));
        } else {
            for (OrderItem item : items) {
                if (item.getMenuItem().getId().equals(menuItemId)) {
                    item.setQuantity(newQuantity);
                    break;
                }
            }
        }
    }

    public void clearCart() {
        items.clear();
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public LocationNode getSelectedLocationNode() {
        return selectedLocationNode;
    }

    public void setSelectedLocationNode(LocationNode node, DeliveryGraph graph) {
        this.selectedLocationNode = node;
        if (node != null) {
            this.currentDijkstraResult = graph.findShortestPath(node.getId());
        } else {
            this.currentDijkstraResult = null;
        }
    }

    public DijkstraResult getCurrentDijkstraResult() {
        return currentDijkstraResult;
    }

    public double getFoodSubtotal() {
        double subtotal = 0.0;
        for (OrderItem item : items) {
            subtotal += item.getSubtotal();
        }
        return subtotal;
    }

    public double getDeliveryFee(DeliveryGraph graph) {
        if (currentDijkstraResult == null || !currentDijkstraResult.hasPath()) {
            return 0.0;
        }
        return graph.calculateDeliveryFee(currentDijkstraResult.getTotalDistanceMeters());
    }

    public double getTotalPrice(DeliveryGraph graph) {
        return getFoodSubtotal() + getDeliveryFee(graph);
    }
}
