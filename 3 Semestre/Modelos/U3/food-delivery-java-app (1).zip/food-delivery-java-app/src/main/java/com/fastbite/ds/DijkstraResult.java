package com.fastbite.ds;

import com.fastbite.model.LocationNode;

import java.util.List;

public class DijkstraResult {
    private List<LocationNode> path;
    private double totalDistanceMeters;

    public DijkstraResult(List<LocationNode> path, double totalDistanceMeters) {
        this.path = path;
        this.totalDistanceMeters = totalDistanceMeters;
    }

    public List<LocationNode> getPath() { return path; }
    public double getTotalDistanceMeters() { return totalDistanceMeters; }

    public boolean hasPath() {
        return path != null && !path.isEmpty();
    }
}
