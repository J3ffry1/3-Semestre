package com.fastbite.ui;

import com.fastbite.ds.CategoryTree;
import com.fastbite.ds.DeliveryGraph;
import com.fastbite.model.LocationNode;
import com.fastbite.model.MenuItem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import javax.swing.Box;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.UUID;

/**
 * Panel de Administración Rediseñado (Alto Contraste, Formularios Amplios y Edición de Grafo)
 */
public class AdminPanel extends JPanel {

    private final CategoryTree menuTree;
    private final DeliveryGraph graph;
    private final Runnable onDataChanged;

    // Formulario Platillo
    private final JTextField nameField;
    private final JComboBox<String> categoryBox;
    private final JTextField priceField;
    private final JTextField descField;
    private final JComboBox<String> emojiBox;

    // Configuración Tarifas
    private final JTextField baseFeeField;
    private final JTextField meterRateField;

    // Formulario Nodos Grafo
    private final JTextField nodeNameField;
    private final JTextField nodeXField;
    private final JTextField nodeYField;

    // Formulario Aristas Grafo
    private final JComboBox<LocationNode> fromNodeBox;
    private final JComboBox<LocationNode> toNodeBox;
    private final JTextField distanceField;

    // Tabla
    private final JTable menuTable;
    private final DefaultTableModel tableModel;

    public AdminPanel(CategoryTree menuTree, DeliveryGraph graph, Runnable onDataChanged) {
        this.menuTree = menuTree;
        this.graph = graph;
        this.onDataChanged = onDataChanged;

        setLayout(new BorderLayout(16, 16));
        setBackground(new Color(15, 23, 42));
        setBorder(new EmptyBorder(16, 20, 16, 20));

        JTabbedPane adminTabs = new JTabbedPane();
        adminTabs.setFont(new Font("SansSerif", Font.BOLD, 14));

        // --- PESTAÑA 1: GESTIÓN DE MENÚ Y PLATILLOS ---
        JPanel menuMgmtPanel = new JPanel(new BorderLayout(16, 16));
        menuMgmtPanel.setBackground(new Color(15, 23, 42));

        // Formulario Izquierdo
        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(new Color(30, 41, 59));
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(16, 185, 129), 2),
                        " ➕ Agregar Nuevo Platillo al Menú ",
                        0, 0, new Font("SansSerif", Font.BOLD, 15), new Color(16, 185, 129)
                ),
                new EmptyBorder(16, 16, 16, 16)
        ));
        formCard.setPreferredSize(new Dimension(440, 500));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.weightx = 1.0;

        addFormRow(formCard, gbc, 0, "Nombre del Platillo:", nameField = createStyledTextField("Ej: Hamburguesa Triple Queso"));
        addFormRow(formCard, gbc, 1, "Categoría:", categoryBox = new JComboBox<>(new String[]{"Hamburguesas", "Pizzas", "Entradas", "Bebidas", "Postres"}));
        addFormRow(formCard, gbc, 2, "Precio ($):", priceField = createStyledTextField("Ej: 7.50"));
        addFormRow(formCard, gbc, 3, "Descripción:", descField = createStyledTextField("Ej: Deliciosa carne gourmet con tocineta"));
        addFormRow(formCard, gbc, 4, "Ícono Representativo:", emojiBox = new JComboBox<>(new String[]{
                "🍔 Hamburguesa", "🍕 Pizza", "🍗 Alitas", "🍟 Papas", "🥤 Bebida", "🍦 Helado", "🍰 Pastel", "🌮 Tacos", "🍣 Sushi", "🥩 Asado"
        }));

        JButton addFoodBtn = new JButton("✨ PUBLICAR PLATILLO AL MENÚ");
        addFoodBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        addFoodBtn.setBackground(new Color(16, 185, 129));
        addFoodBtn.setForeground(Color.WHITE);
        addFoodBtn.setPreferredSize(new Dimension(300, 44));
        addFoodBtn.setFocusPainted(false);
        addFoodBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addFoodBtn.addActionListener(e -> addMenuItem());

        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        formCard.add(Box.createVerticalStrut(10), gbc);
        gbc.gridy = 6;
        formCard.add(addFoodBtn, gbc);

        // Tabla Derecha
        String[] columns = {"ID", "Ícono", "Nombre", "Categoría", "Precio ($)"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        menuTable = new JTable(tableModel);
        menuTable.setRowHeight(36);
        menuTable.setFont(new Font("SansSerif", Font.PLAIN, 13));
        menuTable.setBackground(new Color(30, 41, 59));
        menuTable.setForeground(Color.WHITE);

        JScrollPane tableScroll = new JScrollPane(menuTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(71, 85, 105), 1),
                " 📋 Catálogo de Productos Registrados (Árbol BST) ",
                0, 0, new Font("SansSerif", Font.BOLD, 15), Color.WHITE
        ));

        JButton deleteFoodBtn = new JButton("🗑️ ELIMINAR PLATILLO SELECCIONADO");
        deleteFoodBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        deleteFoodBtn.setBackground(new Color(239, 68, 68));
        deleteFoodBtn.setForeground(Color.WHITE);
        deleteFoodBtn.setPreferredSize(new Dimension(300, 40));
        deleteFoodBtn.setFocusPainted(false);
        deleteFoodBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        deleteFoodBtn.addActionListener(e -> deleteSelectedMenuItem());

        JPanel rightTableContainer = new JPanel(new BorderLayout(0, 10));
        rightTableContainer.setOpaque(false);
        rightTableContainer.add(tableScroll, BorderLayout.CENTER);
        rightTableContainer.add(deleteFoodBtn, BorderLayout.SOUTH);

        menuMgmtPanel.add(formCard, BorderLayout.WEST);
        menuMgmtPanel.add(rightTableContainer, BorderLayout.CENTER);

        // --- PESTAÑA 2: GESTIÓN DE MAPA Y GRAFO DE CIUDAD ---
        JPanel graphMgmtPanel = new JPanel(new GridLayout(1, 2, 16, 16));
        graphMgmtPanel.setBackground(new Color(15, 23, 42));

        // Sub-panel Tarifas y Nodos
        JPanel nodeFormCard = new JPanel(new GridBagLayout());
        nodeFormCard.setBackground(new Color(30, 41, 59));
        nodeFormCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(56, 189, 248), 2),
                        " 🌐 Red de Ciudad & Tarifas de Envío ",
                        0, 0, new Font("SansSerif", Font.BOLD, 15), new Color(56, 189, 248)
                ),
                new EmptyBorder(16, 16, 16, 16)
        ));

        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.fill = GridBagConstraints.HORIZONTAL;
        gbc2.insets = new Insets(6, 6, 6, 6);
        gbc2.weightx = 1.0;

        addFormRow(nodeFormCard, gbc2, 0, "Tarifa Base de Envío ($):", baseFeeField = createStyledTextField(String.valueOf(graph.getBaseDeliveryFee())));
        addFormRow(nodeFormCard, gbc2, 1, "Costo por Metro ($/m):", meterRateField = createStyledTextField(String.valueOf(graph.getCostPerMeter())));

        JButton saveRatesBtn = new JButton("💾 GUARDAR TARIFAS DE ENVÍO");
        saveRatesBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        saveRatesBtn.setBackground(new Color(14, 165, 233));
        saveRatesBtn.setForeground(Color.WHITE);
        saveRatesBtn.setFocusPainted(false);
        saveRatesBtn.addActionListener(e -> updateRates());

        gbc2.gridx = 0; gbc2.gridy = 2; gbc2.gridwidth = 2;
        nodeFormCard.add(saveRatesBtn, gbc2);

        gbc2.gridy = 3;
        nodeFormCard.add(new JSeparator(SwingConstants.HORIZONTAL), gbc2);

        addFormRow(nodeFormCard, gbc2, 4, "Nombre del Sector / Zona:", nodeNameField = createStyledTextField("Ej: Sector Parque Juventud"));
        addFormRow(nodeFormCard, gbc2, 5, "Coordenada X (Pixel):", nodeXField = createStyledTextField("Ej: 520"));
        addFormRow(nodeFormCard, gbc2, 6, "Coordenada Y (Pixel):", nodeYField = createStyledTextField("Ej: 340"));

        JButton addNodeBtn = new JButton("🗺️ AGREGAR NUEVO SECTOR AL MAPA");
        addNodeBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        addNodeBtn.setBackground(new Color(139, 92, 246));
        addNodeBtn.setForeground(Color.WHITE);
        addNodeBtn.setFocusPainted(false);
        addNodeBtn.addActionListener(e -> addMapNode());

        gbc2.gridy = 7;
        nodeFormCard.add(addNodeBtn, gbc2);

        // Sub-panel Aristas / Conexión de Calles
        JPanel edgeFormCard = new JPanel(new GridBagLayout());
        edgeFormCard.setBackground(new Color(30, 41, 59));
        edgeFormCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(245, 158, 11), 2),
                        " 🛣️ Conectar Calles / Aristas del Grafo ",
                        0, 0, new Font("SansSerif", Font.BOLD, 15), new Color(245, 158, 11)
                ),
                new EmptyBorder(16, 16, 16, 16)
        ));

        fromNodeBox = new JComboBox<>();
        toNodeBox = new JComboBox<>();
        refreshNodeComboBoxes();

        GridBagConstraints gbc3 = new GridBagConstraints();
        gbc3.fill = GridBagConstraints.HORIZONTAL;
        gbc3.insets = new Insets(8, 8, 8, 8);
        gbc3.weightx = 1.0;

        addFormRow(edgeFormCard, gbc3, 0, "Sector Origen:", fromNodeBox);
        addFormRow(edgeFormCard, gbc3, 1, "Sector Destino:", toNodeBox);
        addFormRow(edgeFormCard, gbc3, 2, "Distancia (Metros):", distanceField = createStyledTextField("Ej: 1200"));

        JButton addEdgeBtn = new JButton("🔗 CONECTAR NUEVA CALLE");
        addEdgeBtn.setFont(new Font("SansSerif", Font.BOLD, 14));
        addEdgeBtn.setBackground(new Color(245, 158, 11));
        addEdgeBtn.setForeground(Color.WHITE);
        addEdgeBtn.setPreferredSize(new Dimension(300, 44));
        addEdgeBtn.setFocusPainted(false);
        addEdgeBtn.addActionListener(e -> addRoadEdge());

        gbc3.gridx = 0; gbc3.gridy = 3; gbc3.gridwidth = 2;
        edgeFormCard.add(Box.createVerticalStrut(10), gbc3);
        gbc3.gridy = 4;
        edgeFormCard.add(addEdgeBtn, gbc3);

        graphMgmtPanel.add(nodeFormCard);
        graphMgmtPanel.add(edgeFormCard);

        adminTabs.addTab("🍔 Gestión del Menú de Comidas", menuMgmtPanel);
        adminTabs.addTab("🗺️ Edición del Grafo y Mapa de Ciudad", graphMgmtPanel);

        add(adminTabs, BorderLayout.CENTER);

        refreshTable();
    }

    private JTextField createStyledTextField(String placeholder) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("SansSerif", Font.PLAIN, 14));
        tf.setPreferredSize(new Dimension(200, 36));
        tf.setBackground(new Color(15, 23, 42));
        tf.setForeground(Color.WHITE);
        tf.setCaretColor(Color.WHITE);
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(71, 85, 105), 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
        return tf;
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, int row, String labelText, Component comp) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        lbl.setForeground(Color.WHITE);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        panel.add(comp, gbc);
    }

    private void refreshNodeComboBoxes() {
        fromNodeBox.removeAllItems();
        toNodeBox.removeAllItems();
        for (LocationNode node : graph.getAllNodes()) {
            fromNodeBox.addItem(node);
            toNodeBox.addItem(node);
        }
    }

    private void updateRates() {
        try {
            double baseFee = Double.parseDouble(baseFeeField.getText().trim());
            double meterRate = Double.parseDouble(meterRateField.getText().trim());

            graph.setBaseDeliveryFee(baseFee);
            graph.setCostPerMeter(meterRate);

            JOptionPane.showMessageDialog(this, "Tarifas actualizadas correctamente:\n" +
                    "• Base: $" + baseFee + "\n" +
                    "• Por Metro: $" + meterRate, "Éxito", JOptionPane.INFORMATION_MESSAGE);

            if (onDataChanged != null) onDataChanged.run();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa montos numéricos válidos.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addMenuItem() {
        try {
            String name = nameField.getText().trim();
            String cat = (String) categoryBox.getSelectedItem();
            double price = Double.parseDouble(priceField.getText().trim());
            String desc = descField.getText().trim();
            String emojiCombo = (String) emojiBox.getSelectedItem();
            String emoji = emojiCombo != null ? emojiCombo.split(" ")[0] : "🍔";

            if (name.isEmpty() || desc.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Completa todos los campos obligatorios.", "Campos Faltantes", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String id = UUID.randomUUID().toString().substring(0, 5);
            MenuItem newItem = new MenuItem(id, name, cat, price, desc, emoji, "#3B82F6");

            menuTree.insert(newItem);
            refreshTable();

            nameField.setText("");
            priceField.setText("");
            descField.setText("");

            JOptionPane.showMessageDialog(this, "¡Platillo publicando en el menú del cliente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            if (onDataChanged != null) onDataChanged.run();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa un precio válido (ej: 5.50).", "Error de Precio", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedMenuItem() {
        int selectedRow = menuTable.getSelectedRow();
        if (selectedRow >= 0) {
            String id = (String) tableModel.getValueAt(selectedRow, 0);
            menuTree.deleteItem(id);
            refreshTable();
            if (onDataChanged != null) onDataChanged.run();
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un platillo de la tabla para eliminar.", "Selección Requerida", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void addMapNode() {
        try {
            String name = nodeNameField.getText().trim();
            int x = Integer.parseInt(nodeXField.getText().trim());
            int y = Integer.parseInt(nodeYField.getText().trim());

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresa el nombre del nuevo sector.", "Nombre Requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String id = "NODE_" + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
            LocationNode newNode = new LocationNode(id, name, x, y, false, "Sector Creado por Admin");

            graph.addNode(newNode);
            refreshNodeComboBoxes();

            nodeNameField.setText("");
            nodeXField.setText("");
            nodeYField.setText("");

            JOptionPane.showMessageDialog(this, "¡Nuevo sector agregado al mapa de la ciudad!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            if (onDataChanged != null) onDataChanged.run();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa valores numéricos válidos para las coordenadas X e Y (ej: 500, 300).", "Error de Coordenadas", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addRoadEdge() {
        try {
            LocationNode from = (LocationNode) fromNodeBox.getSelectedItem();
            LocationNode to = (LocationNode) toNodeBox.getSelectedItem();
            double dist = Double.parseDouble(distanceField.getText().trim());

            if (from == null || to == null || from.getId().equals(to.getId())) {
                JOptionPane.showMessageDialog(this, "Selecciona dos sectores distintos para conectar.", "Selección Inválida", JOptionPane.WARNING_MESSAGE);
                return;
            }

            graph.addEdge(from.getId(), to.getId(), dist);
            distanceField.setText("");

            JOptionPane.showMessageDialog(this, "¡Nueva calle/arista conectada en el grafo!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            if (onDataChanged != null) onDataChanged.run();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa una distancia válida en metros.", "Error de Distancia", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (MenuItem item : menuTree.getInOrderItems()) {
            tableModel.addRow(new Object[]{
                    item.getId(),
                    item.getEmojiIcon(),
                    item.getName(),
                    item.getCategory(),
                    String.format("$%.2f", item.getPrice())
            });
        }
    }
}
