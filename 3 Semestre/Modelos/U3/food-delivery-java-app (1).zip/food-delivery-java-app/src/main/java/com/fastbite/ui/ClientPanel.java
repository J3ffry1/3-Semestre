package com.fastbite.ui;

import com.fastbite.ds.*;
import com.fastbite.model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;

/**
 * Vista Principal del Cliente (Catálogo Fullscreen + Mapa Interactivo + Carrito Desplegable)
 */
public class ClientPanel extends JPanel {

    private final CategoryTree menuTree;
    private final DeliveryGraph graph;
    private final OrderState orderState;

    private final JPanel foodGridPanel;
    private final InteractiveMapPanel mapPanel;
    private final Runnable onCartToggleRequested;
    private String selectedCategory = "Todos";

    public ClientPanel(CategoryTree menuTree, DeliveryGraph graph, OrderState orderState, Runnable onCartToggleRequested) {
        this.menuTree = menuTree;
        this.graph = graph;
        this.orderState = orderState;
        this.onCartToggleRequested = onCartToggleRequested;

        setLayout(new BorderLayout());
        setBackground(new Color(15, 23, 42));

        JTabbedPane mainTabs = new JTabbedPane();
        mainTabs.setFont(new Font("SansSerif", Font.BOLD, 14));

        // 1. Pestaña de Menú de Comidas
        JPanel menuTab = new JPanel(new BorderLayout());
        menuTab.setBackground(new Color(15, 23, 42));

        JPanel filterPanel = createCategoryFilterPanel();
        menuTab.add(filterPanel, BorderLayout.NORTH);

        foodGridPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 20));
        foodGridPanel.setBackground(new Color(15, 23, 42));

        JScrollPane menuScroll = new JScrollPane(foodGridPanel);
        menuScroll.setOpaque(false);
        menuScroll.getViewport().setOpaque(false);
        menuScroll.setBorder(null);
        menuScroll.getVerticalScrollBar().setUnitIncrement(18);

        menuTab.add(menuScroll, BorderLayout.CENTER);

        // 2. Pestaña de Mapa de Entrega estilo Google Maps
        mapPanel = new InteractiveMapPanel(graph);
        mapPanel.setOnNodeSelectedListener(node -> {
            orderState.setSelectedLocationNode(node, graph);
            if (onCartToggleRequested != null) {
                // Notificar cambio
            }
        });

        mainTabs.addTab("🍔 Menú & Comidas", menuTab);
        mainTabs.addTab("🗺️ Ubicación de Entrega (Mapa Interactivo)", mapPanel);

        add(mainTabs, BorderLayout.CENTER);

        refreshFoodCatalog();
    }

    private JPanel createCategoryFilterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        panel.setBackground(new Color(30, 41, 59));
        panel.setBorder(new EmptyBorder(8, 16, 8, 16));

        JLabel titleLbl = new JLabel("Categorías: ");
        titleLbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        titleLbl.setForeground(Color.WHITE);
        panel.add(titleLbl);

        String[] categories = {"Todos", "Hamburguesas", "Pizzas", "Entradas", "Bebidas", "Postres"};
        for (String cat : categories) {
            JButton catBtn = new JButton(cat);
            catBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
            catBtn.setBackground(new Color(51, 65, 85));
            catBtn.setForeground(Color.WHITE);
            catBtn.setFocusPainted(false);
            catBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            catBtn.addActionListener(e -> {
                selectedCategory = cat;
                refreshFoodCatalog();
            });
            panel.add(catBtn);
        }
        return panel;
    }

    public void refreshFoodCatalog() {
        foodGridPanel.removeAll();
        java.util.List<MenuItem> items = menuTree.getItemsByCategory(selectedCategory);

        for (MenuItem item : items) {
            FoodCardPanel card = new FoodCardPanel(item, menuItem -> {
                orderState.addItem(menuItem);
                if (onCartToggleRequested != null) {
                    onCartToggleRequested.run();
                }
            });
            foodGridPanel.add(card);
        }

        foodGridPanel.revalidate();
        foodGridPanel.repaint();
    }

    public void refreshView() {
        refreshFoodCatalog();
        mapPanel.repaint();
    }
}
