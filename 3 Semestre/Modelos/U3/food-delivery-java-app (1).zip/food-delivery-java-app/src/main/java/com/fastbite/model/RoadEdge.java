package com.fastbite.model;

public class RoadEdge {
    private LocationNode target;
    private double distanceMeters;

    public RoadEdge(LocationNode target, double distanceMeters) {
        this.target = target;
        this.distanceMeters = distanceMeters;
    }

    public LocationNode getTarget() { return target; }
    public double getDistanceMeters() { return distanceMeters; }
}
