package com.fastbite.ui;

import com.fastbite.ds.*;
import com.fastbite.model.*;

import javax.swing.*;
import java.awt.*;

/**
 * Ventana Modal / Drawer Desplegable del Carrito de Compras
 */
public class CartDialog extends JDialog {

    private final CartPanel cartPanel;

    public CartDialog(Frame owner, OrderState orderState, DeliveryGraph graph, Runnable onCartUpdated) {
        super(owner, "🛒 Tu Carrito de Compras - FastBite Express", true);
        setSize(420, 680);
        setLocationRelativeTo(owner);
        setResizable(false);

        cartPanel = new CartPanel(orderState, graph, () -> {
            if (onCartUpdated != null) onCartUpdated.run();
        });

        setContentPane(cartPanel);
    }

    public void refreshCartUI() {
        cartPanel.updateCartUI();
    }
}
