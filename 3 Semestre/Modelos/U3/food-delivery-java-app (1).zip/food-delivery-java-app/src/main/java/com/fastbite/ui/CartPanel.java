package com.fastbite.ui;

import com.fastbite.ds.DeliveryGraph;
import com.fastbite.model.LocationNode;
import com.fastbite.model.OrderItem;
import com.fastbite.model.OrderState;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

/**
 * Panel lateral del Carrito de Compras
 */
public class CartPanel extends JPanel {

    private final OrderState orderState;
    private final DeliveryGraph graph;
    private final Runnable onCartUpdated;

    private final JPanel itemsContainer;
    private final JLabel locationLabel;
    private final JLabel distanceLabel;
    private final JLabel foodSubtotalLabel;
    private final JLabel deliveryFeeLabel;
    private final JLabel totalLabel;

    public CartPanel(OrderState orderState, DeliveryGraph graph, Runnable onCartUpdated) {
        this.orderState = orderState;
        this.graph = graph;
        this.onCartUpdated = onCartUpdated;

        setLayout(new BorderLayout());
        setBackground(new Color(24, 28, 36));
        setBorder(new EmptyBorder(16, 16, 16, 16));

        // Header Carrito
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("🛒 Tu Carrito de Compras");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        JButton clearBtn = new JButton("Vaciar");
        clearBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
        clearBtn.setForeground(new Color(239, 68, 68));
        clearBtn.setContentAreaFilled(false);
        clearBtn.setBorderPainted(false);
        clearBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clearBtn.addActionListener(e -> {
            orderState.clearCart();
            updateCartUI();
            if (onCartUpdated != null) onCartUpdated.run();
        });
        headerPanel.add(clearBtn, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Contenedor de Items (Scrollable)
        itemsContainer = new JPanel();
        itemsContainer.setLayout(new BoxLayout(itemsContainer, BoxLayout.Y_AXIS));
        itemsContainer.setOpaque(false);

        JScrollPane scrollPane = new JScrollPane(itemsContainer);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);

        add(scrollPane, BorderLayout.CENTER);

        // Footer / Resumen de Totales y Ubicación
        JPanel footerPanel = new JPanel();
        footerPanel.setLayout(new BoxLayout(footerPanel, BoxLayout.Y_AXIS));
        footerPanel.setOpaque(false);
        footerPanel.setBorder(new EmptyBorder(12, 0, 0, 0));

        JPanel deliveryInfoPanel = new JPanel(new GridLayout(2, 1, 4, 4));
        deliveryInfoPanel.setBackground(new Color(30, 41, 59));
        deliveryInfoPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(71, 85, 105), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        locationLabel = new JLabel("📍 Ubicación: Selecciona en el mapa");
        locationLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        locationLabel.setForeground(new Color(56, 189, 248));

        distanceLabel = new JLabel("📏 Ruta Dijkstra: 0m");
        distanceLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        distanceLabel.setForeground(new Color(148, 163, 184));

        deliveryInfoPanel.add(locationLabel);
        deliveryInfoPanel.add(distanceLabel);

        footerPanel.add(deliveryInfoPanel);
        footerPanel.add(Box.createVerticalStrut(12));

        // Desglose Financiero
        JPanel priceBreakdown = new JPanel(new GridLayout(3, 2, 8, 6));
        priceBreakdown.setOpaque(false);

        JLabel lbl1 = new JLabel("Subtotal Comida:");
        lbl1.setForeground(new Color(148, 163, 184));
        foodSubtotalLabel = new JLabel("$0.00", SwingConstants.RIGHT);
        foodSubtotalLabel.setForeground(Color.WHITE);
        foodSubtotalLabel.setFont(new Font("SansSerif", Font.BOLD, 12));

        JLabel lbl2 = new JLabel("Costo de Envío (Grafo):");
        lbl2.setForeground(new Color(148, 163, 184));
        deliveryFeeLabel = new JLabel("$0.00", SwingConstants.RIGHT);
        deliveryFeeLabel.setForeground(new Color(56, 189, 248));
        deliveryFeeLabel.setFont(new Font("SansSerif", Font.BOLD, 12));

        JLabel lbl3 = new JLabel("TOTAL FINAL:");
        lbl3.setFont(new Font("SansSerif", Font.BOLD, 14));
        lbl3.setForeground(Color.WHITE);
        totalLabel = new JLabel("$0.00", SwingConstants.RIGHT);
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        totalLabel.setForeground(new Color(0, 255, 170));

        priceBreakdown.add(lbl1);
        priceBreakdown.add(foodSubtotalLabel);
        priceBreakdown.add(lbl2);
        priceBreakdown.add(deliveryFeeLabel);
        priceBreakdown.add(lbl3);
        priceBreakdown.add(totalLabel);

        footerPanel.add(priceBreakdown);
        footerPanel.add(Box.createVerticalStrut(16));

        JButton checkoutButton = new JButton("🚀 CONFIRMAR Y PEDIR");
        checkoutButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        checkoutButton.setBackground(new Color(14, 165, 233));
        checkoutButton.setForeground(Color.WHITE);
        checkoutButton.setFocusPainted(false);
        checkoutButton.setPreferredSize(new Dimension(300, 45));
        checkoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        checkoutButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        checkoutButton.addActionListener(e -> processCheckout());

        footerPanel.add(checkoutButton);

        add(footerPanel, BorderLayout.SOUTH);

        updateCartUI();
    }

    public void updateCartUI() {
        itemsContainer.removeAll();

        if (orderState.getItems().isEmpty()) {
            JLabel emptyLabel = new JLabel("<html><center>Tu carrito está vacío.<br>Agrega deliciosas hamburguesas y pizzas.</center></html>", SwingConstants.CENTER);
            emptyLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            emptyLabel.setForeground(new Color(100, 116, 139));
            emptyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            itemsContainer.add(Box.createVerticalStrut(40));
            itemsContainer.add(emptyLabel);
        } else {
            for (OrderItem item : orderState.getItems()) {
                itemsContainer.add(createItemRow(item));
                itemsContainer.add(Box.createVerticalStrut(8));
            }
        }

        LocationNode node = orderState.getSelectedLocationNode();
        if (node != null) {
            locationLabel.setText("📍 Ubicación: " + node.getName());
            if (orderState.getCurrentDijkstraResult() != null) {
                distanceLabel.setText(String.format("📏 Ruta Dijkstra: %.0f metros", orderState.getCurrentDijkstraResult().getTotalDistanceMeters()));
            }
        } else {
            locationLabel.setText("📍 Ubicación: ¡Selecciona en el mapa!");
            distanceLabel.setText("📏 Ruta Dijkstra: 0m");
        }

        foodSubtotalLabel.setText(String.format("$%.2f", orderState.getFoodSubtotal()));
        deliveryFeeLabel.setText(String.format("$%.2f", orderState.getDeliveryFee(graph)));
        totalLabel.setText(String.format("$%.2f", orderState.getTotalPrice(graph)));

        itemsContainer.revalidate();
        itemsContainer.repaint();
    }

    private JPanel createItemRow(OrderItem item) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(new Color(30, 41, 59));
        row.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(51, 65, 85), 1, true),
                new EmptyBorder(8, 8, 8, 8)
        ));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel titleLabel = new JLabel(item.getMenuItem().getEmojiIcon() + " " + item.getMenuItem().getName());
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        titleLabel.setForeground(Color.WHITE);

        JLabel priceLabel = new JLabel(String.format("$%.2f", item.getSubtotal()));
        priceLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        priceLabel.setForeground(new Color(0, 255, 170));

        JPanel leftPanel = new JPanel(new GridLayout(2, 1));
        leftPanel.setOpaque(false);
        leftPanel.add(titleLabel);
        leftPanel.add(priceLabel);

        JPanel qtyPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        qtyPanel.setOpaque(false);

        JButton minusBtn = new JButton("-");
        minusBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        minusBtn.setFocusPainted(false);
        minusBtn.addActionListener(e -> {
            orderState.updateQuantity(item.getMenuItem().getId(), item.getQuantity() - 1);
            updateCartUI();
            if (onCartUpdated != null) onCartUpdated.run();
        });

        JLabel qtyLabel = new JLabel(String.valueOf(item.getQuantity()));
        qtyLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        qtyLabel.setForeground(Color.WHITE);
        qtyLabel.setBorder(new EmptyBorder(0, 4, 0, 4));

        JButton plusBtn = new JButton("+");
        plusBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        plusBtn.setFocusPainted(false);
        plusBtn.addActionListener(e -> {
            orderState.updateQuantity(item.getMenuItem().getId(), item.getQuantity() + 1);
            updateCartUI();
            if (onCartUpdated != null) onCartUpdated.run();
        });

        qtyPanel.add(minusBtn);
        qtyPanel.add(qtyLabel);
        qtyPanel.add(plusBtn);

        row.add(leftPanel, BorderLayout.CENTER);
        row.add(qtyPanel, BorderLayout.EAST);

        return row;
    }

    private void processCheckout() {
        if (orderState.getItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tu carrito está vacío. Agrega ítems antes de pedir.", "Carrito Vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (orderState.getSelectedLocationNode() == null) {
            JOptionPane.showMessageDialog(this, "Por favor haz clic en un punto del mapa para elegir tu dirección de entrega.", "Ubicación Requerida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String summary = String.format(
                "🎉 ¡PEDIDO CONFIRMADO EXITOSAMENTE! 🎉\n\n" +
                "📍 Destino de Entrega: %s\n" +
                "📏 Distancia (Ruta Óptima Dijkstra): %.0f metros\n\n" +
                "💵 Subtotal Comida: $%.2f\n" +
                "🚚 Tarifa de Envío: $%.2f\n" +
                "-----------------------------------------\n" +
                "💰 TOTAL A PAGAR: $%.2f\n\n" +
                "¡Tu pedido ya fue enviado a la cocina!",
                orderState.getSelectedLocationNode().getName(),
                orderState.getCurrentDijkstraResult().getTotalDistanceMeters(),
                orderState.getFoodSubtotal(),
                orderState.getDeliveryFee(graph),
                orderState.getTotalPrice(graph)
        );

        JOptionPane.showMessageDialog(this, summary, "Orden en Camino 🛵💨", JOptionPane.INFORMATION_MESSAGE);
        orderState.clearCart();
        updateCartUI();
        if (onCartUpdated != null) onCartUpdated.run();
    }
}
