package com.fastbite.ui;

import com.fastbite.ds.*;
import com.fastbite.model.*;

import javax.swing.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Panel de Mapa Interactivo HD (Google Maps Style) con visualización de la red expandida
 */
public class InteractiveMapPanel extends JPanel {

    private final DeliveryGraph graph;
    private LocationNode selectedDestinationNode;
    private DijkstraResult activeResult;
    private LocationNode hoveredNode;
    private Consumer<LocationNode> onNodeSelectedListener;

    public InteractiveMapPanel(DeliveryGraph graph) {
        this.graph = graph;
        setBackground(new Color(15, 23, 42)); // Dark map background
        setPreferredSize(new Dimension(960, 640));

        MouseAdapter mouseHandler = new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                LocationNode prevHovered = hoveredNode;
                hoveredNode = findNodeAt(e.getPoint());
                if (prevHovered != hoveredNode) {
                    setCursor(hoveredNode != null ? Cursor.getPredefinedCursor(Cursor.HAND_CURSOR) : Cursor.getDefaultCursor());
                    repaint();
                }
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                LocationNode clickedNode = findNodeAt(e.getPoint());
                if (clickedNode != null) {
                    setSelectedDestinationNode(clickedNode);
                    if (onNodeSelectedListener != null) {
                        onNodeSelectedListener.accept(clickedNode);
                    }
                }
            }
        };

        addMouseMotionListener(mouseHandler);
        addMouseListener(mouseHandler);
    }

    public void setOnNodeSelectedListener(Consumer<LocationNode> listener) {
        this.onNodeSelectedListener = listener;
    }

    public void setSelectedDestinationNode(LocationNode node) {
        this.selectedDestinationNode = node;
        if (node != null) {
            this.activeResult = graph.findShortestPath(node.getId());
        } else {
            this.activeResult = null;
        }
        repaint();
    }

    private LocationNode findNodeAt(Point p) {
        for (LocationNode node : graph.getAllNodes()) {
            double dist = p.distance(node.getX(), node.getY());
            if (dist <= 26) {
                return node;
            }
        }
        return null;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        drawMapBackgroundGrid(g2);
        drawRoads(g2);
        drawShortestPath(g2);
        drawNodes(g2);
        drawHeaderBanner(g2);
    }

    private void drawMapBackgroundGrid(Graphics2D g2) {
        g2.setColor(new Color(30, 41, 59, 120));
        int spacing = 50;
        for (int x = 0; x < getWidth(); x += spacing) {
            g2.drawLine(x, 0, x, getHeight());
        }
        for (int y = 0; y < getHeight(); y += spacing) {
            g2.drawLine(0, y, getWidth(), y);
        }
    }

    private void drawRoads(Graphics2D g2) {
        g2.setStroke(new BasicStroke(4.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        Set<String> drawnEdges = new HashSet<>();

        for (LocationNode u : graph.getAllNodes()) {
            List<RoadEdge> edges = graph.getAdjList().getOrDefault(u.getId(), List.of());
            for (RoadEdge edge : edges) {
                LocationNode v = edge.getTarget();
                String edgeKey = u.getId().compareTo(v.getId()) < 0 ? u.getId() + "_" + v.getId() : v.getId() + "_" + u.getId();

                if (!drawnEdges.contains(edgeKey)) {
                    drawnEdges.add(edgeKey);

                    // Calle base
                    g2.setColor(new Color(51, 65, 85));
                    g2.draw(new Line2D.Float(u.getX(), u.getY(), v.getX(), v.getY()));

                    // Distancia en metros
                    int midX = (u.getX() + v.getX()) / 2;
                    int midY = (u.getY() + v.getY()) / 2;
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
                    g2.setColor(new Color(148, 163, 184));
                    g2.drawString((int) edge.getDistanceMeters() + "m", midX - 10, midY - 4);
                }
            }
        }
    }

    private void drawShortestPath(Graphics2D g2) {
        if (activeResult == null || !activeResult.hasPath()) return;

        List<LocationNode> path = activeResult.getPath();
        if (path.size() < 2) return;

        // Glow brillante neón
        g2.setStroke(new BasicStroke(12.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.setColor(new Color(0, 230, 153, 90));
        for (int i = 0; i < path.size() - 1; i++) {
            LocationNode u = path.get(i);
            LocationNode v = path.get(i + 1);
            g2.draw(new Line2D.Float(u.getX(), u.getY(), v.getX(), v.getY()));
        }

        g2.setStroke(new BasicStroke(5.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.setColor(new Color(0, 255, 170));
        for (int i = 0; i < path.size() - 1; i++) {
            LocationNode u = path.get(i);
            LocationNode v = path.get(i + 1);
            g2.draw(new Line2D.Float(u.getX(), u.getY(), v.getX(), v.getY()));
        }
    }

    private void drawNodes(Graphics2D g2) {
        for (LocationNode node : graph.getAllNodes()) {
            boolean isSelected = selectedDestinationNode != null && selectedDestinationNode.getId().equals(node.getId());
            boolean isHovered = hoveredNode != null && hoveredNode.getId().equals(node.getId());
            boolean isInPath = activeResult != null && activeResult.getPath().contains(node);

            int x = node.getX();
            int y = node.getY();
            int radius = isHovered || isSelected ? 18 : 13;

            if (node.isRestaurant()) {
                g2.setColor(new Color(239, 68, 68));
                g2.fill(new Ellipse2D.Float(x - radius - 3, y - radius - 3, (radius + 3) * 2, (radius + 3) * 2));
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
                g2.drawString("🍔", x - 9, y + 5);

                g2.setFont(new Font("SansSerif", Font.BOLD, 12));
                g2.setColor(new Color(248, 113, 113));
                g2.drawString(node.getName(), x - 40, y + radius + 18);
            } else if (isSelected) {
                g2.setColor(new Color(56, 189, 248));
                g2.fill(new Ellipse2D.Float(x - radius - 3, y - radius - 3, (radius + 3) * 2, (radius + 3) * 2));
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
                g2.drawString("📍", x - 9, y + 5);

                g2.setFont(new Font("SansSerif", Font.BOLD, 12));
                g2.setColor(new Color(56, 189, 248));
                g2.drawString(node.getName() + " (Destino Elegido)", x - 50, y + radius + 18);
            } else {
                if (isInPath) {
                    g2.setColor(new Color(0, 255, 170));
                } else if (isHovered) {
                    g2.setColor(new Color(147, 197, 253));
                } else {
                    g2.setColor(new Color(100, 116, 139));
                }

                g2.fill(new Ellipse2D.Float(x - radius, y - radius, radius * 2, radius * 2));

                g2.setFont(new Font("SansSerif", Font.BOLD, 11));
                g2.setColor(isHovered || isInPath ? Color.WHITE : new Color(226, 232, 240));
                g2.drawString(node.getName(), x - 25, y + radius + 15);
            }
        }
    }

    private void drawHeaderBanner(Graphics2D g2) {
        g2.setColor(new Color(15, 23, 42, 230));
        g2.fillRoundRect(20, 20, 520, 50, 12, 12);
        g2.setColor(new Color(51, 65, 85));
        g2.drawRoundRect(20, 20, 520, 50, 12, 12);

        g2.setFont(new Font("SansSerif", Font.BOLD, 13));
        g2.setColor(Color.WHITE);
        g2.drawString("🗺️ Google Maps Urbano (20+ Zonas - Algoritmo de Dijkstra)", 35, 40);

        g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g2.setColor(new Color(148, 163, 184));
        g2.drawString("Haz clic en cualquier punto para fijar tu ubicación de entrega y ver el camino más corto.", 35, 58);

        if (selectedDestinationNode != null && activeResult != null && activeResult.hasPath()) {
            int panelW = 400;
            int panelH = 55;
            int panelX = getWidth() - panelW - 20;
            int panelY = getHeight() - panelH - 20;

            g2.setColor(new Color(15, 23, 42, 240));
            g2.fillRoundRect(panelX, panelY, panelW, panelH, 12, 12);
            g2.setColor(new Color(0, 255, 170));
            g2.drawRoundRect(panelX, panelY, panelW, panelH, 12, 12);

            g2.setFont(new Font("SansSerif", Font.BOLD, 12));
            g2.setColor(new Color(0, 255, 170));
            g2.drawString("✨ Ruta Óptima Calculada por Dijkstra", panelX + 15, panelY + 22);

            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g2.setColor(Color.WHITE);
            String infoStr = String.format("Distancia: %.0f metros | Costo Envío: $%.2f",
                    activeResult.getTotalDistanceMeters(),
                    graph.calculateDeliveryFee(activeResult.getTotalDistanceMeters()));
            g2.drawString(infoStr, panelX + 15, panelY + 42);
        }
    }
}
