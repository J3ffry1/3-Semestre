package com.fastbite.ds;

import com.fastbite.model.LocationNode;
import com.fastbite.model.RoadEdge;

import java.util.*;

/**
 * Estructura de Datos de Grafo Ponderado para la red de entregas.
 * Red expandida con 20+ sectores de la ciudad y soporte para agregar nodos/calles dinámicamente.
 */
public class DeliveryGraph {
    private final Map<String, LocationNode> nodes = new LinkedHashMap<>();
    private final Map<String, List<RoadEdge>> adjList = new HashMap<>();
    private String restaurantNodeId = "NODE_REST";
    private double costPerMeter = 0.003; // $3 por cada 1000m (1km)
    private double baseDeliveryFee = 1.50; // Tarifa base fija

    public DeliveryGraph() {
        initializeSampleNetwork();
    }

    public synchronized void addNode(LocationNode node) {
        nodes.put(node.getId(), node);
        adjList.putIfAbsent(node.getId(), new ArrayList<>());
    }

    public synchronized void addEdge(String fromId, String toId, double distanceMeters) {
        LocationNode fromNode = nodes.get(fromId);
        LocationNode toNode = nodes.get(toId);

        if (fromNode != null && toNode != null) {
            // Evitar duplicados
            adjList.putIfAbsent(fromId, new ArrayList<>());
            adjList.putIfAbsent(toId, new ArrayList<>());

            adjList.get(fromId).removeIf(e -> e.getTarget().getId().equals(toId));
            adjList.get(toId).removeIf(e -> e.getTarget().getId().equals(fromId));

            adjList.get(fromId).add(new RoadEdge(toNode, distanceMeters));
            adjList.get(toId).add(new RoadEdge(fromNode, distanceMeters));
        }
    }

    public LocationNode getNode(String id) {
        return nodes.get(id);
    }

    public Collection<LocationNode> getAllNodes() {
        return nodes.values();
    }

    public Map<String, List<RoadEdge>> getAdjList() {
        return adjList;
    }

    public String getRestaurantNodeId() {
        return restaurantNodeId;
    }

    public LocationNode getRestaurantNode() {
        return nodes.get(restaurantNodeId);
    }

    public double getCostPerMeter() {
        return costPerMeter;
    }

    public void setCostPerMeter(double costPerMeter) {
        this.costPerMeter = costPerMeter;
    }

    public double getBaseDeliveryFee() {
        return baseDeliveryFee;
    }

    public void setBaseDeliveryFee(double baseDeliveryFee) {
        this.baseDeliveryFee = baseDeliveryFee;
    }

    public double calculateDeliveryFee(double distanceMeters) {
        if (distanceMeters <= 0) return 0.0;
        return baseDeliveryFee + (distanceMeters * costPerMeter);
    }

    /**
     * Algoritmo de Dijkstra con Min-Heap (PriorityQueue) para la ruta más corta
     */
    public DijkstraResult findShortestPath(String destinationNodeId) {
        if (!nodes.containsKey(restaurantNodeId) || !nodes.containsKey(destinationNodeId)) {
            return new DijkstraResult(Collections.emptyList(), 0.0);
        }

        Map<String, Double> distances = new HashMap<>();
        Map<String, String> previousNodes = new HashMap<>();
        PriorityQueue<NodeDistance> pq = new PriorityQueue<>(Comparator.comparingDouble(nd -> nd.distance));

        for (String nodeId : nodes.keySet()) {
            distances.put(nodeId, Double.POSITIVE_INFINITY);
        }

        distances.put(restaurantNodeId, 0.0);
        pq.add(new NodeDistance(restaurantNodeId, 0.0));

        while (!pq.isEmpty()) {
            NodeDistance current = pq.poll();
            String currentId = current.nodeId;

            if (current.distance > distances.get(currentId)) continue;
            if (currentId.equals(destinationNodeId)) break;

            List<RoadEdge> neighbors = adjList.getOrDefault(currentId, Collections.emptyList());
            for (RoadEdge edge : neighbors) {
                String neighborId = edge.getTarget().getId();
                double newDist = distances.get(currentId) + edge.getDistanceMeters();

                if (newDist < distances.get(neighborId)) {
                    distances.put(neighborId, newDist);
                    previousNodes.put(neighborId, currentId);
                    pq.add(new NodeDistance(neighborId, newDist));
                }
            }
        }

        double totalDist = distances.getOrDefault(destinationNodeId, Double.POSITIVE_INFINITY);
        if (Double.isInfinite(totalDist)) {
            return new DijkstraResult(Collections.emptyList(), 0.0);
        }

        LinkedList<LocationNode> path = new LinkedList<>();
        String step = destinationNodeId;
        while (step != null) {
            path.addFirst(nodes.get(step));
            step = previousNodes.get(step);
        }

        return new DijkstraResult(path, totalDist);
    }

    private static class NodeDistance {
        String nodeId;
        double distance;

        NodeDistance(String nodeId, double distance) {
            this.nodeId = nodeId;
            this.distance = distance;
        }
    }

    /**
     * Red Gigante de Mapa (20 Nodos con conexiones viales detalladas)
     */
    private void initializeSampleNetwork() {
        // Restaurante Central (Centro de distribución)
        addNode(new LocationNode("NODE_REST", "FastBite Central", 480, 320, true, "Restaurante Principal - Centro"));

        // Nodos del mapa urbano (Sectores y Puntos estratégicos)
        addNode(new LocationNode("SD_NORTE", "Santo Domingo Norte", 450, 90, false, "Sector Norte - Av. Principal"));
        addNode(new LocationNode("AV_QUITO", "Av. Quito & Río Toachi", 320, 160, false, "Eje Comercial Av. Quito"));
        addNode(new LocationNode("MUNICIPIO", "Palacio Municipal", 480, 210, false, "Centro Cívico y Municipio"));
        addNode(new LocationNode("PARQUE_Z", "Parque Zaracay", 360, 280, false, "Plaza Central Zaracay"));
        addNode(new LocationNode("TERMINAL", "Terminal Terrestre", 720, 140, false, "Terminal Terrestre Principal"));
        addNode(new LocationNode("LOS_ROSALES", "Urb. Los Rosales", 220, 100, false, "Zona Residencial Los Rosales"));
        addNode(new LocationNode("PLAZA_SHOPPING", "Shopping Center", 680, 290, false, "Centro Comercial Mall"));
        addNode(new LocationNode("PARQUE_JUVENTUD", "Parque de la Juventud", 600, 200, false, "Zona Recreativa Este"));
        addNode(new LocationNode("ZONA_U", "Ciudad Universitaria", 780, 230, false, "Campus Universitario UTE/PUCE"));
        addNode(new LocationNode("TSACHILA", "Monumento Tsáchila", 260, 380, false, "Redondel del Indio Tsáchila"));
        addNode(new LocationNode("ASISTENCIA_SOC", "Asistencia Social", 140, 240, false, "Sector Asistencia Social"));
        addNode(new LocationNode("BOMBOLI", "Cerro Bombolí Mirador", 180, 480, false, "Zona Alta / Mirador Bombolí"));
        addNode(new LocationNode("AV_CHONE", "Av. Chone Km 1", 340, 460, false, "Vía a Chone - Sector Comercial"));
        addNode(new LocationNode("ZONA_INDUSTRIAL", "Zona Industrial", 650, 480, false, "Vía Quevedo Km 2"));
        addNode(new LocationNode("BOSQUE_REAL", "Urb. Bosque Real", 110, 360, false, "Residencial Bosque Real"));
        addNode(new LocationNode("VILLA_VERDE", "Villa Verde", 860, 360, false, "Urbanización Este Villa Verde"));
        addNode(new LocationNode("HOSPITAL_CENTRAL", "Hospital Santo Domingo", 480, 440, false, "Zona Hospitalaria Sur"));
        addNode(new LocationNode("ESTADIO", "Estadio Olímpico", 580, 390, false, "Estadio Tsáchila"));
        addNode(new LocationNode("MERCADO_CENTRAL", "Mercado Central", 400, 230, false, "Mercado de Abastos"));

        // Aristas con distancias reales aproximadas en metros
        addEdge("NODE_REST", "MUNICIPIO", 900);
        addEdge("NODE_REST", "PARQUE_Z", 1100);
        addEdge("NODE_REST", "ESTADIO", 950);
        addEdge("NODE_REST", "HOSPITAL_CENTRAL", 1200);
        addEdge("NODE_REST", "PLAZA_SHOPPING", 1600);

        addEdge("SD_NORTE", "AV_QUITO", 1200);
        addEdge("SD_NORTE", "MUNICIPIO", 1400);
        addEdge("SD_NORTE", "TERMINAL", 1800);
        addEdge("SD_NORTE", "LOS_ROSALES", 1150);

        addEdge("LOS_ROSALES", "AV_QUITO", 900);
        addEdge("LOS_ROSALES", "ASISTENCIA_SOC", 1300);

        addEdge("AV_QUITO", "MUNICIPIO", 850);
        addEdge("AV_QUITO", "MERCADO_CENTRAL", 750);
        addEdge("AV_QUITO", "ASISTENCIA_SOC", 1100);

        addEdge("MUNICIPIO", "PARQUE_Z", 650);
        addEdge("MUNICIPIO", "MERCADO_CENTRAL", 500);
        addEdge("MUNICIPIO", "PARQUE_JUVENTUD", 1350);

        addEdge("PARQUE_Z", "TSACHILA", 1250);
        addEdge("PARQUE_Z", "AV_CHONE", 1450);

        addEdge("ASISTENCIA_SOC", "BOSQUE_REAL", 950);
        addEdge("BOSQUE_REAL", "TSACHILA", 1050);
        addEdge("BOSQUE_REAL", "BOMBOLI", 1400);

        addEdge("TSACHILA", "AV_CHONE", 800);
        addEdge("TSACHILA", "BOMBOLI", 1100);

        addEdge("AV_CHONE", "HOSPITAL_CENTRAL", 1000);
        addEdge("HOSPITAL_CENTRAL", "ZONA_INDUSTRIAL", 1300);
        addEdge("HOSPITAL_CENTRAL", "ESTADIO", 800);

        addEdge("ESTADIO", "ZONA_INDUSTRIAL", 1100);
        addEdge("ESTADIO", "PLAZA_SHOPPING", 1250);

        addEdge("TERMINAL", "PARQUE_JUVENTUD", 900);
        addEdge("TERMINAL", "ZONA_U", 1150);

        addEdge("PARQUE_JUVENTUD", "PLAZA_SHOPPING", 750);
        addEdge("PARQUE_JUVENTUD", "ZONA_U", 850);

        addEdge("PLAZA_SHOPPING", "VILLA_VERDE", 1300);
        addEdge("PLAZA_SHOPPING", "ZONA_INDUSTRIAL", 1500);

        addEdge("ZONA_U", "VILLA_VERDE", 1050);
    }
}
