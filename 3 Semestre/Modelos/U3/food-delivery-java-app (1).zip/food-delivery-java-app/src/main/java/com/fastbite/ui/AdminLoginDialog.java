package com.fastbite.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Diálogo Modal de Autenticación para el Panel de Administración (Usuario y Contraseña)
 */
public class AdminLoginDialog extends JDialog {

    private boolean authenticated = false;
    private final JTextField usernameField;
    private final JPasswordField passwordField;

    public AdminLoginDialog(Frame owner) {
        super(owner, "🔐 Acceso Administrador - FastBite", true);
        setSize(380, 260);
        setLocationRelativeTo(owner);
        setResizable(false);

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(new Color(15, 23, 42));
        contentPane.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Header
        JLabel titleLabel = new JLabel("🔑 Iniciar Sesión de Admin", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        titleLabel.setForeground(new Color(56, 189, 248));
        titleLabel.setBorder(new EmptyBorder(0, 0, 16, 0));
        contentPane.add(titleLabel, BorderLayout.NORTH);

        // Form Fields
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 14));
        formPanel.setOpaque(false);

        JLabel userLbl = new JLabel("Usuario:");
        userLbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        userLbl.setForeground(Color.WHITE);
        usernameField = new JTextField("admin");
        usernameField.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JLabel passLbl = new JLabel("Contraseña:");
        passLbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        passLbl.setForeground(Color.WHITE);
        passwordField = new JPasswordField("1234");
        passwordField.setFont(new Font("SansSerif", Font.PLAIN, 14));

        formPanel.add(userLbl);
        formPanel.add(usernameField);
        formPanel.add(passLbl);
        formPanel.add(passwordField);

        contentPane.add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnPanel.setOpaque(false);

        JButton cancelBtn = new JButton("Cancelar");
        cancelBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        cancelBtn.addActionListener(e -> {
            authenticated = false;
            dispose();
        });

        JButton loginBtn = new JButton("🚀 Iniciar Sesión");
        loginBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        loginBtn.setBackground(new Color(14, 165, 233));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.addActionListener(e -> attemptLogin());

        btnPanel.add(cancelBtn);
        btnPanel.add(loginBtn);

        contentPane.add(btnPanel, BorderLayout.SOUTH);

        setContentPane(contentPane);
    }

    private void attemptLogin() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword());

        if ("admin".equalsIgnoreCase(user) && "1234".equals(pass)) {
            authenticated = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas.\nPrueba con Usuario: admin / Clave: 1234", "Acceso Denegado", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isAuthenticated() {
        return authenticated;
    }
}
