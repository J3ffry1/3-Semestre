package com.fastbite.ui;

import com.fastbite.model.MenuItem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.function.Consumer;

/**
 * Tarjeta visual moderna para cada platillo del menú
 */
public class FoodCardPanel extends JPanel {

    public FoodCardPanel(MenuItem item, Consumer<MenuItem> onAddToCart) {
        setLayout(new BorderLayout());
        setBackground(new Color(30, 41, 59));
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(51, 65, 85), 1, true),
                new EmptyBorder(14, 14, 14, 14)
        ));
        setPreferredSize(new Dimension(250, 270));

        // Header / Emoji Ícono
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel catLabel = new JLabel(item.getCategory().toUpperCase());
        catLabel.setFont(new Font("SansSerif", Font.BOLD, 10));
        catLabel.setForeground(new Color(56, 189, 248));
        catLabel.setBorder(new EmptyBorder(0, 0, 4, 0));
        headerPanel.add(catLabel, BorderLayout.NORTH);

        JLabel emojiLabel = new JLabel(item.getEmojiIcon(), SwingConstants.CENTER);
        emojiLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 58));
        emojiLabel.setPreferredSize(new Dimension(80, 80));
        headerPanel.add(emojiLabel, BorderLayout.CENTER);

        add(headerPanel, BorderLayout.NORTH);

        // Información de platillo
        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 4, 4));
        infoPanel.setOpaque(false);
        infoPanel.setBorder(new EmptyBorder(8, 0, 8, 0));

        JLabel nameLabel = new JLabel(item.getName());
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        nameLabel.setForeground(Color.WHITE);

        JLabel descLabel = new JLabel("<html><body style='width: 190px; color: #94A3B8;'>" + item.getDescription() + "</body></html>");
        descLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));

        JLabel priceLabel = new JLabel(String.format("$%.2f", item.getPrice()));
        priceLabel.setFont(new Font("SansSerif", Font.BOLD, 17));
        priceLabel.setForeground(new Color(0, 255, 170));

        infoPanel.add(nameLabel);
        infoPanel.add(descLabel);
        infoPanel.add(priceLabel);

        add(infoPanel, BorderLayout.CENTER);

        // Botón de Agregar
        JButton addButton = new JButton("➕ Agregar a la Orden");
        addButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        addButton.setBackground(new Color(16, 185, 129));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addButton.addActionListener(e -> onAddToCart.accept(item));

        add(addButton, BorderLayout.SOUTH);
    }
}
