package com.fastbite.ds;

import com.fastbite.model.MenuItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Estructura de Árbol Binario de Búsqueda (BST) para el Menú de Comidas
 */
public class CategoryTree {

    public static class TreeNode {
        public MenuItem item;
        public TreeNode left;
        public TreeNode right;

        public TreeNode(MenuItem item) {
            this.item = item;
        }
    }

    private TreeNode root;
    private final List<MenuItem> allMenuItems = new ArrayList<>();

    public CategoryTree() {
        loadDefaultMenu();
    }

    public void insert(MenuItem item) {
        allMenuItems.add(item);
        root = insertRecursive(root, item);
    }

    private TreeNode insertRecursive(TreeNode current, MenuItem item) {
        if (current == null) {
            return new TreeNode(item);
        }

        int comp = item.getCategory().compareTo(current.item.getCategory());
        if (comp == 0) {
            comp = item.getName().compareTo(current.item.getName());
        }

        if (comp < 0) {
            current.left = insertRecursive(current.left, item);
        } else {
            current.right = insertRecursive(current.right, item);
        }

        return current;
    }

    public List<MenuItem> getInOrderItems() {
        List<MenuItem> result = new ArrayList<>();
        inOrderTraversal(root, result);
        return result;
    }

    private void inOrderTraversal(TreeNode node, List<MenuItem> result) {
        if (node != null) {
            inOrderTraversal(node.left, result);
            result.add(node.item);
            inOrderTraversal(node.right, result);
        }
    }

    public List<MenuItem> getItemsByCategory(String category) {
        if (category == null || category.equalsIgnoreCase("Todos")) {
            return getInOrderItems();
        }
        List<MenuItem> filtered = new ArrayList<>();
        for (MenuItem item : getInOrderItems()) {
            if (item.getCategory().equalsIgnoreCase(category)) {
                filtered.add(item);
            }
        }
        return filtered;
    }

    public List<MenuItem> getAllMenuItems() {
        return allMenuItems;
    }

    public void deleteItem(String id) {
        allMenuItems.removeIf(i -> i.getId().equals(id));
        root = null;
        for (MenuItem item : allMenuItems) {
            root = insertRecursive(root, item);
        }
    }

    private void loadDefaultMenu() {
        insert(new MenuItem("1", "Burger Suprema Doble", "Hamburguesas", 6.50, "Carne 100% cheddar doble, tocineta crocante y salsa secreta FastBite", "🍔", "#FF6B6B"));
        insert(new MenuItem("2", "Burger Crispy Chicken", "Hamburguesas", 5.75, "Pechuga crocante empanizada, lechuga fresca y mayo ranch", "🍗", "#FFA07A"));
        insert(new MenuItem("3", "Burger BBQ Bacon", "Hamburguesas", 6.99, "Carne a la parrilla, aros de cebolla, queso cheddar y salsa BBQ", "🍔", "#FF4757"));

        insert(new MenuItem("4", "Pizza Pepperoni Deluxe", "Pizzas", 8.99, "Masa artesanal con extra pepperoni y queso mozzarella fundido", "🍕", "#FFA502"));
        insert(new MenuItem("5", "Pizza 4 Quesos", "Pizzas", 9.50, "Mozzarella, Gorgonzola, Parmesano y Provolone en masa crujiente", "🧀", "#ECCC68"));

        insert(new MenuItem("6", "Papa Fritas Trufadas", "Entradas", 3.50, "Papas rústicas con aceite de trufa, parmesano y perejil", "🍟", "#2ED573"));
        insert(new MenuItem("7", "Alitas BBQ (8 pcs)", "Entradas", 5.25, "Alitas bañadas en salsa BBQ ahumada con aderezo azul", "🍗", "#FF7F50"));

        insert(new MenuItem("8", "Coca Cola Zero 500ml", "Bebidas", 1.50, "Refresco helado sin azúcar", "🥤", "#70A1FF"));
        insert(new MenuItem("9", "Jugo Natural de Maracuyá", "Bebidas", 2.00, "Refrescante fruta natural helada", "🍹", "#1E90FF"));

        insert(new MenuItem("10", "Milkshake de Oreo", "Postres", 3.75, "Batido cremoso con trozos de Oreo y crema batida", "🍦", "#5352ED"));
        insert(new MenuItem("11", "Cheesecake de Frutilla", "Postres", 4.00, "Porción cremosa de queso con mermelada artesanal", "🍰", "#FF6B81"));
    }
}
