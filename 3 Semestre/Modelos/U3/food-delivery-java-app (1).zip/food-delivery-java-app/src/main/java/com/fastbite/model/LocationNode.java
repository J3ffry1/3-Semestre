package com.fastbite.model;

public class LocationNode {
    private String id;
    private String name;
    private int x;
    private int y;
    private boolean isRestaurant;
    private String description;

    public LocationNode(String id, String name, int x, int y, boolean isRestaurant, String description) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
        this.isRestaurant = isRestaurant;
        this.description = description;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getX() { return x; }
    public int getY() { return y; }
    public boolean isRestaurant() { return isRestaurant; }
    public String getDescription() { return description; }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }

    @Override
    public String toString() {
        return name + (isRestaurant ? " 🏪 (Restaurante)" : "");
    }
}
