package com.fastbite.ui;

import com.fastbite.ds.*;
import com.fastbite.model.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Ventana Principal de la Aplicación (FastBite Express v2.0 ÉPICA)
 */
public class MainFrame extends JFrame {

    private final CategoryTree menuTree;
    private final DeliveryGraph graph;
    private final OrderState orderState;

    private final CardLayout cardLayout;
    private final JPanel contentPanel;
    private final ClientPanel clientPanel;
    private final AdminPanel adminPanel;

    private final JButton cartBtn;
    private final JButton clientViewBtn;
    private final JButton adminViewBtn;
    private final JButton logoutAdminBtn;

    private boolean isAdminLoggedIn = false;
    private CartDialog cartDialog;

    public MainFrame() {
        setTitle("FastBite Express v2.0 - Sistema de Delivery con Grafos, Árboles y Mapa Urbano");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1320, 840);
        setMinimumSize(new Dimension(1080, 750));
        setLocationRelativeTo(null);

        // Inicializar Estado
        menuTree = new CategoryTree();
        graph = new DeliveryGraph();
        orderState = new OrderState();

        // 1. Barra de Navegación Superior (Top Navbar)
        JPanel topNavbar = new JPanel(new BorderLayout());
        topNavbar.setBackground(new Color(15, 23, 42));
        topNavbar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(51, 65, 85)),
                new EmptyBorder(12, 20, 12, 20)
        ));

        // Brand Logo
        JLabel logoLabel = new JLabel("🛵 FastBite Express");
        logoLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        logoLabel.setForeground(new Color(0, 255, 170));

        JLabel subtitleLabel = new JLabel("  |  Red de Ciudad & Ruta Óptima Dijkstra");
        subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(148, 163, 184));

        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        brandPanel.setOpaque(false);
        brandPanel.add(logoLabel);
        brandPanel.add(subtitleLabel);

        // Botones de Navegación
        JPanel navButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        navButtons.setOpaque(false);

        // Botón Flotante del Carrito
        cartBtn = new JButton("🛒 Mi Carrito ($0.00)");
        cartBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        cartBtn.setBackground(new Color(16, 185, 129));
        cartBtn.setForeground(Color.WHITE);
        cartBtn.setFocusPainted(false);
        cartBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cartBtn.addActionListener(e -> openCartDialog());

        clientViewBtn = new JButton("🍔 Menú Cliente");
        clientViewBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        clientViewBtn.setBackground(new Color(14, 165, 233));
        clientViewBtn.setForeground(Color.WHITE);
        clientViewBtn.setFocusPainted(false);
        clientViewBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clientViewBtn.addActionListener(e -> showView("CLIENT"));

        adminViewBtn = new JButton("🔐 Panel Admin");
        adminViewBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        adminViewBtn.setBackground(new Color(51, 65, 85));
        adminViewBtn.setForeground(new Color(203, 213, 225));
        adminViewBtn.setFocusPainted(false);
        adminViewBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        adminViewBtn.addActionListener(e -> handleAdminAccess());

        logoutAdminBtn = new JButton("🚪 Salir Admin");
        logoutAdminBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        logoutAdminBtn.setBackground(new Color(239, 68, 68));
        logoutAdminBtn.setForeground(Color.WHITE);
        logoutAdminBtn.setFocusPainted(false);
        logoutAdminBtn.setVisible(false);
        logoutAdminBtn.addActionListener(e -> {
            isAdminLoggedIn = false;
            logoutAdminBtn.setVisible(false);
            showView("CLIENT");
        });

        navButtons.add(cartBtn);
        navButtons.add(clientViewBtn);
        navButtons.add(adminViewBtn);
        navButtons.add(logoutAdminBtn);

        topNavbar.add(brandPanel, BorderLayout.WEST);
        topNavbar.add(navButtons, BorderLayout.EAST);

        // 2. Contenedor Principal (CardLayout)
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        clientPanel = new ClientPanel(menuTree, graph, orderState, this::updateCartButtonLabel);
        adminPanel = new AdminPanel(menuTree, graph, () -> clientPanel.refreshView());

        contentPanel.add(clientPanel, "CLIENT");
        contentPanel.add(adminPanel, "ADMIN");

        add(topNavbar, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        showView("CLIENT");
        updateCartButtonLabel();
    }

    private void openCartDialog() {
        if (cartDialog == null || !cartDialog.isDisplayable()) {
            cartDialog = new CartDialog(this, orderState, graph, this::updateCartButtonLabel);
        }
        cartDialog.refreshCartUI();
        cartDialog.setVisible(true);
    }

    private void updateCartButtonLabel() {
        double total = orderState.getTotalPrice(graph);
        int itemsCount = orderState.getItems().stream().mapToInt(item -> item.getQuantity()).sum();
        cartBtn.setText(String.format("🛒 Mi Carrito (%d) | $%.2f", itemsCount, total));
    }

    private void handleAdminAccess() {
        if (isAdminLoggedIn) {
            showView("ADMIN");
        } else {
            AdminLoginDialog loginDlg = new AdminLoginDialog(this);
            loginDlg.setVisible(true);
            if (loginDlg.isAuthenticated()) {
                isAdminLoggedIn = true;
                logoutAdminBtn.setVisible(true);
                showView("ADMIN");
            }
        }
    }

    private void showView(String viewName) {
        cardLayout.show(contentPanel, viewName);
        if ("CLIENT".equals(viewName)) {
            clientViewBtn.setBackground(new Color(14, 165, 233));
            clientViewBtn.setForeground(Color.WHITE);
            adminViewBtn.setBackground(new Color(51, 65, 85));
            adminViewBtn.setForeground(new Color(203, 213, 225));
            clientPanel.refreshView();
        } else {
            adminViewBtn.setBackground(new Color(14, 165, 233));
            adminViewBtn.setForeground(Color.WHITE);
            clientViewBtn.setBackground(new Color(51, 65, 85));
            clientViewBtn.setForeground(new Color(203, 213, 225));
        }
        updateCartButtonLabel();
    }
}
