package com.fastbite;

import com.fastbite.ui.MainFrame;

import javax.swing.*;

/**
 * Punto de entrada principal de la aplicación FastBite Express v2.0
 */
public class Main {
    public static void main(String[] args) {
        try {
            Class<?> flatLafClass = Class.forName("com.formdev.flatlaf.FlatDarkLaf");
            flatLafClass.getMethod("setup").invoke(null);
            UIManager.put("Button.arc", 12);
            UIManager.put("Component.arc", 12);
            UIManager.put("TextComponent.arc", 12);
            UIManager.put("ProgressBar.arc", 12);
        } catch (Throwable ex) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
        }

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
