@echo off
title FastBite Express - System Launcher
echo ========================================================
echo         FastBite Express - Delivery System
echo ========================================================
echo Compilando codigo Java...

if not exist bin mkdir bin

"C:\Program Files\Java\jdk-24\bin\javac.exe" -d bin src\main\java\com\fastbite\model\*.java src\main\java\com\fastbite\ds\*.java src\main\java\com\fastbite\ui\*.java src\main\java\com\fastbite\*.java

if %ERRORLEVEL% EQU 0 (
    echo Compilacion exitosa. Iniciando la Aplicacion...
    "C:\Program Files\Java\jdk-24\bin\java.exe" -cp bin com.fastbite.Main
) else (
    echo Error durante la compilacion.
    pause
)
