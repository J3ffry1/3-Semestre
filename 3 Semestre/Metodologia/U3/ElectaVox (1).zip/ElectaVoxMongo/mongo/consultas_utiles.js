// Ejecutar en mongosh o usar como referencia para filtros en MongoDB Compass.
use("electavox");

// Usuarios y padrón.
db.users.find({}, { email: 1, cedula: 1, fullName: 1, role: 1, active: 1, _id: 0 });
db.students.find({}, { studentId: 1, cedula: 1, fullName: 1, course: 1, gender: 1, _id: 0 });

// Candidatos ordenados por número de lista.
db.candidates.find({}, { listNumber: 1, fullName: 1, career: 1, proposal: 1, photoData: 1, _id: 0 }).sort({ listNumber: 1 });

// Resultado por candidato.
db.votes.aggregate([
  { $group: { _id: "$candidateId", votos: { $sum: 1 } } },
  { $sort: { votos: -1 } }
]);

// Participación por curso.
db.votes.aggregate([
  { $group: { _id: "$studentCourse", votos: { $sum: 1 } } },
  { $sort: { votos: -1 } }
]);

// Participación por género.
db.votes.aggregate([
  { $group: { _id: "$studentGender", votos: { $sum: 1 } } },
  { $sort: { votos: -1 } }
]);
