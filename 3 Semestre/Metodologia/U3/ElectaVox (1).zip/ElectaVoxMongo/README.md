# ElectaVox MongoDB

Sistema de votación estudiantil desarrollado en Java Swing para Apache NetBeans, con persistencia en MongoDB. Se conserva la interfaz y la estructura original del proyecto, incorporando las validaciones y automatizaciones solicitadas para el proceso electoral.

## Funcionalidades implementadas

| Historia de usuario | Cumplimiento en el sistema |
|---|---|
| Registro de estudiantes | Registra cédula, nombre completo, curso, género, contraseña y correo opcional. Guarda el padrón y la cuenta en MongoDB. |
| Inicio de sesión estudiantil | El estudiante ingresa con cédula y contraseña. Solo acceden cédulas registradas y activas. |
| Registro de candidatos | Registra número de lista, nombre, carrera, género, propuestas y fotografía almacenada en MongoDB. |
| Consulta de candidatos | Muestra listado, fotografía, carrera y propuesta completa. |
| Emisión del voto | Permite seleccionar candidato, solicitar confirmación y registrar el voto en MongoDB. |
| Voto único | Verifica el historial y utiliza un índice único por elección y estudiante para bloquear duplicados. |
| Contador regresivo | Se actualiza cada segundo, cierra automáticamente la votación y bloquea nuevos votos al finalizar. |
| Resultados en tiempo real | Muestra barras, total de votos y porcentaje por candidato; se actualiza automáticamente. |
| Estadísticas por curso | Muestra votantes y porcentaje de participación respecto al padrón de cada curso. |
| Estadísticas por género | Muestra votantes, porcentajes y barras gráficas por género. |
| Reporte final | Genera archivos TXT con resultados, estadísticas generales, fecha y hora de cierre. |
| Cierre oficial | Bloquea votos, identifica ganador o empate y genera reporte final y acta de cierre. |

## Requisitos

- JDK 21.
- Apache NetBeans con soporte para proyectos Maven.
- MongoDB Community Server en ejecución.
- MongoDB Compass, opcional, para revisar las colecciones.
- Conexión a Internet durante la primera compilación para descargar la dependencia Maven.

## Abrir y ejecutar en NetBeans

1. Extrae el archivo ZIP.
2. Abre **Apache NetBeans**.
3. Selecciona **File > Open Project**.
4. Elige la carpeta `ElectaVoxMongo`, que contiene `pom.xml`.
5. Espera a que Maven descargue las librerías.
6. Verifica que MongoDB esté iniciado.
7. Haz clic derecho en el proyecto y selecciona **Run**.

## Conexión a MongoDB

La configuración local se encuentra en:

```text
src/main/resources/application.properties
```

Configuración predeterminada:

```properties
mongodb.uri=mongodb://localhost:27017
mongodb.db=electavox
```

La aplicación crea o adapta automáticamente las colecciones, índices y datos de demostración al iniciar sesión. También admite `MONGODB_URI` y `MONGODB_DB` como variables de entorno.

## Accesos iniciales

| Rol | Identificador | Contraseña |
|---|---|---|
| Administrador | `admin@espe.edu.ec` | `Admin123*` |
| Estudiante | `1723456789` | `Estudiante123*` |

Los administradores ingresan con correo. Los estudiantes ingresan con su cédula registrada.

## Colecciones principales

- `users`: credenciales, cédula de estudiantes, nombre, rol y estado.
- `students`: padrón electoral, cédula, nombre completo, curso y género.
- `candidates`: candidaturas, lista, carrera, propuestas y fotografía binaria.
- `elections`: elección activa, periodo, estado y fecha de cierre.
- `votes`: voto emitido, estudiante, candidato, curso y género para estadísticas.

## Reportes generados

Los archivos se crean automáticamente dentro de la carpeta:

```text
reports/
```

Al cerrar oficialmente la elección se generan:

- `reporte_final_electavox_*.txt`
- `acta_cierre_electavox_*.txt`

## Formularios editables

Los formularios de NetBeans se encuentran en:

- `src/main/java/vista/`
- `src/main/java/panels/`

Los archivos `.form` se conservaron para continuar editando las ventanas desde la pestaña **Design**.
