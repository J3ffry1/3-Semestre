package util;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

public final class UtilFecha {
    private static final SimpleDateFormat FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    private UtilFecha() {
    }

    public static String format(Date date) {
        return date == null ? "-" : FORMAT.format(date);
    }

    public static String countdown(Date endAt) {
        if (endAt == null) {
            return "Sin fecha";
        }
        Duration duration = Duration.between(new Date().toInstant(), endAt.toInstant());
        if (duration.isNegative() || duration.isZero()) {
            return "Finalizado";
        }
        long secondsTotal = duration.getSeconds();
        long days = secondsTotal / 86_400;
        long hours = (secondsTotal % 86_400) / 3_600;
        long minutes = (secondsTotal % 3_600) / 60;
        long seconds = secondsTotal % 60;
        return String.format("%02d días %02d:%02d:%02d", days, hours, minutes, seconds);
    }
}
