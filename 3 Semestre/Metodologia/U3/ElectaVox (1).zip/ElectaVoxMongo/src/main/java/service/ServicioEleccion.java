package service;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.lte;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;
import static com.mongodb.client.model.Updates.unset;

import com.mongodb.client.MongoDatabase;
import config.ConfiguracionMongo;
import java.util.Date;
import org.bson.Document;

public class ServicioEleccion {
    private final MongoDatabase db = ConfiguracionMongo.getDatabase();

    public Document getActiveElection() {
        return db.getCollection("elections").find(eq("active", true)).first();
    }

    public boolean isOpen(Document election) {
        if (election == null || Boolean.TRUE.equals(election.getBoolean("closed"))) {
            return false;
        }
        Date now = new Date();
        Date startAt = election.getDate("startAt");
        Date endAt = election.getDate("endAt");
        return startAt != null && endAt != null && !now.before(startAt) && now.before(endAt);
    }

    public void actualizarFechaFin(String electionId, Date nuevaFechaFin) {
        db.getCollection("elections").updateOne(
                eq("electionId", electionId),
                combine(set("endAt", nuevaFechaFin), set("closed", false), unset("closedAt")));
    }

    public void closeElection(String electionId) {
        db.getCollection("elections").updateOne(eq("electionId", electionId),
                combine(set("closed", true), set("closedAt", new Date())));
    }

    /** Cierra una elección vencida una sola vez, incluso con varios clientes abiertos. */
    public boolean closeIfExpired(Document election) {
        if (election == null || election.getDate("endAt") == null) {
            return false;
        }
        Date now = new Date();
        long modified = db.getCollection("elections").updateOne(
                and(eq("electionId", election.getString("electionId")),
                        eq("closed", false), lte("endAt", now)),
                combine(set("closed", true), set("closedAt", now))).getModifiedCount();
        if (modified > 0) {
            election.put("closed", true);
            election.put("closedAt", now);
            return true;
        }
        return false;
    }

    public void reopenElection(String electionId) {
        db.getCollection("elections").updateOne(eq("electionId", electionId),
                combine(set("closed", false), unset("closedAt")));
    }
}
