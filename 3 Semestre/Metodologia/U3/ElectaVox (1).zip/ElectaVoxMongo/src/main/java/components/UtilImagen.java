package components;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

public final class UtilImagen {
    private UtilImagen() {
    }

    public static ImageIcon load(String resource, int width, int height) {
        URL url = UtilImagen.class.getResource("/images/" + resource);
        if (url == null) {
            return new ImageIcon();
        }
        return scale(new ImageIcon(url), width, height);
    }

    public static ImageIcon load(byte[] data, int width, int height) {
        if (data == null || data.length == 0) {
            return load("candidate_default.png", width, height);
        }
        ImageIcon icon = new ImageIcon(data);
        if (icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0) {
            return load("candidate_default.png", width, height);
        }
        return scale(icon, width, height);
    }

    private static ImageIcon scale(ImageIcon icon, int width, int height) {
        Image image = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }
}
