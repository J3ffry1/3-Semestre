package electavox;

import vista.FrmInicioSesion;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Punto de entrada de ElectaVox. */
public final class Principal {
    private Principal() {
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Se mantiene el Look and Feel por defecto si el sistema no lo permite.
        }
        SwingUtilities.invokeLater(() -> new FrmInicioSesion().setVisible(true));
    }
}
