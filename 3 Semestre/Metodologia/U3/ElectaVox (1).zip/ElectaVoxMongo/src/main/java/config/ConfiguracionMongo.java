package config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/** Configuración central de MongoDB. Las variables de entorno tienen prioridad sobre application.properties. */
public final class ConfiguracionMongo {
    private static final String DEFAULT_URI = "mongodb://localhost:27017";
    private static final String DEFAULT_DB = "electavox";
    private static MongoClient client;
    private static MongoDatabase database;

    private ConfiguracionMongo() {
    }

    public static synchronized MongoDatabase getDatabase() {
        if (database == null) {
            String uri = setting("MONGODB_URI", "mongodb.uri", DEFAULT_URI);
            String databaseName = setting("MONGODB_DB", "mongodb.db", DEFAULT_DB);
            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(uri))
                    .applyToClusterSettings(builder -> builder.serverSelectionTimeout(4, TimeUnit.SECONDS))
                    .build();
            client = MongoClients.create(settings);
            database = client.getDatabase(databaseName);
        }
        return database;
    }

    public static String getDatabaseName() {
        return setting("MONGODB_DB", "mongodb.db", DEFAULT_DB);
    }

    private static String setting(String environment, String property, String fallback) {
        String environmentValue = System.getenv(environment);
        if (environmentValue != null && !environmentValue.isBlank()) {
            return environmentValue.trim();
        }
        Properties properties = new Properties();
        try (InputStream input = ConfiguracionMongo.class.getResourceAsStream("/application.properties")) {
            if (input != null) {
                properties.load(input);
            }
        } catch (IOException ignored) {
            // Se utiliza la configuración por defecto si el archivo no puede leerse.
        }
        return properties.getProperty(property, fallback).trim();
    }

    public static synchronized void close() {
        if (client != null) {
            client.close();
            client = null;
            database = null;
        }
    }
}
