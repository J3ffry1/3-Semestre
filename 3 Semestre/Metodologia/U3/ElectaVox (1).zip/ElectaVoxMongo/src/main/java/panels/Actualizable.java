package panels;

public interface Actualizable {
    void refreshData();
}
