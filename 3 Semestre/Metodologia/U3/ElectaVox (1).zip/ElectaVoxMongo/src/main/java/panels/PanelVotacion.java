package panels;

import components.PanelRedondeado;
import components.UtilImagen;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.Timer;
import model.SesionUsuario;
import org.bson.Document;
import service.ServicioCandidatos;
import service.ServicioEleccion;
import service.ServicioVotacion;
import service.ServicioReportes;
import util.UtilFecha;
import vista.TemaInterfaz;

/** Pantalla de votación convertida a JPanel Form editable en NetBeans. */
public class PanelVotacion extends javax.swing.JPanel implements Actualizable {

    private final SesionUsuario session;
    private final ServicioCandidatos candidateService = new ServicioCandidatos();
    private final ServicioEleccion electionService = new ServicioEleccion();
    private final ServicioVotacion votingService = new ServicioVotacion();
    private final ServicioReportes reportService = new ServicioReportes();
    private final ButtonGroup group = new ButtonGroup();
    private final Map<JRadioButton, String> options = new LinkedHashMap<>();
    private Document currentElection;
    private boolean finishedNotified;

    /** Constructor auxiliar para abrir el panel directamente en Design. */
    public PanelVotacion() {
        this(new SesionUsuario("estudiante@espe.edu.ec", "Estudiante de prueba", "STUDENT", "0000000000"));
    }

    public PanelVotacion(SesionUsuario session) {
        this.session = session;
        initComponents();
        configurarInterfaz();
        if (!java.beans.Beans.isDesignTime()) {
            new Timer(1_000, event -> updateCountdown()).start();
        }
    }

    private void configurarInterfaz() {
        lblTitle.setFont(TemaInterfaz.font(24, Font.BOLD));
        lblTitle.setForeground(TemaInterfaz.NAVY_DARK);
        lblSubtitle.setFont(TemaInterfaz.font(13, Font.PLAIN));
        lblSubtitle.setForeground(TemaInterfaz.MUTED);
        lblElection.setFont(TemaInterfaz.font(17, Font.BOLD));
        lblElection.setForeground(TemaInterfaz.NAVY_DARK);
        lblState.setFont(TemaInterfaz.font(13, Font.BOLD));
        lblTimer.setFont(TemaInterfaz.font(12, Font.PLAIN));
        lblTimer.setForeground(TemaInterfaz.MUTED);
        lblMessage.setFont(TemaInterfaz.font(13, Font.PLAIN));
        TemaInterfaz.styleSecondaryButton(btnRefresh);
        btnRefresh.addActionListener(event -> refreshData());
        btnVote.setColors(TemaInterfaz.GREEN, TemaInterfaz.NAVY);
        btnVote.setRadius(14);
        btnVote.addActionListener(event -> vote());
    }

    private void vote() {
        JRadioButton selected = options.keySet().stream().filter(JRadioButton::isSelected).findFirst().orElse(null);
        if (selected == null) {
            showMessage("Selecciona un candidato antes de confirmar.", TemaInterfaz.RED);
            return;
        }
        if (!session.isAdmin()) {
            int answer = JOptionPane.showConfirmDialog(this,
                    "Tu voto es definitivo y no podrá modificarse.\n¿Deseas continuar?",
                    "Confirmar voto", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (answer != JOptionPane.YES_OPTION) {
                return;
            }
        }
        String message = votingService.castVote(session, options.get(selected));
        boolean successful = message.startsWith("Voto registrado");
        showMessage(message, successful ? TemaInterfaz.GREEN : TemaInterfaz.RED);
        refreshData();
    }

    private void showMessage(String text, Color color) {
        lblMessage.setText(text);
        lblMessage.setForeground(color);
    }

    @Override
    public void refreshData() {
        candidatesGrid.removeAll();
        options.clear();
        group.clearSelection();
        Document election = electionService.getActiveElection();
        currentElection = election;
        if (election == null) {
            lblElection.setText("No existe una elección activa");
            lblState.setText("● Sin configuración");
            lblState.setForeground(TemaInterfaz.RED);
            btnVote.setEnabled(false);
            candidatesGrid.revalidate();
            candidatesGrid.repaint();
            return;
        }
        boolean open = electionService.isOpen(election);
        String electionId = election.getString("electionId");
        boolean alreadyVoted = !session.isAdmin() && session.studentId() != null
                && votingService.hasVoted(electionId, session.studentId());
        lblElection.setText(election.getString("name"));
        lblState.setText(open ? "● Votación abierta" : "● Votación cerrada");
        lblState.setForeground(open ? TemaInterfaz.GREEN : TemaInterfaz.RED);
        lblTimer.setText("Tiempo disponible: " + UtilFecha.countdown(election.getDate("endAt")));
        finishedNotified = false;
        btnVote.setEnabled(open && !alreadyVoted && !session.isAdmin());
        if (session.isAdmin()) {
            showMessage("Vista administrativa: los administradores no pueden emitir votos.", TemaInterfaz.MUTED);
        } else if (alreadyVoted) {
            showMessage("Tu voto ya fue registrado. Gracias por participar.", TemaInterfaz.GREEN);
        } else if (!open) {
            showMessage("La votación no está disponible en este momento.", TemaInterfaz.RED);
        } else {
            showMessage("Selecciona una candidatura para votar.", TemaInterfaz.MUTED);
        }
        List<Document> candidates = candidateService.listByElection(electionId);
        for (Document candidate : candidates) {
            candidatesGrid.add(createVoteCard(candidate, open && !alreadyVoted && !session.isAdmin()));
        }
        candidatesGrid.revalidate();
        candidatesGrid.repaint();
    }

    private void updateCountdown() {
        if (currentElection == null) {
            return;
        }
        String remaining = UtilFecha.countdown(currentElection.getDate("endAt"));
        lblTimer.setText("Tiempo disponible: " + remaining);
        if (!"Finalizado".equals(remaining)) {
            return;
        }

        boolean closedNow = electionService.closeIfExpired(currentElection);
        if (closedNow) {
            try {
                reportService.generateClosureDocuments();
            } catch (Exception ignored) {
                // El cierre y el bloqueo del voto no dependen de la escritura local del reporte.
            }
        }
        lblState.setText("● Votación cerrada");
        lblState.setForeground(TemaInterfaz.RED);
        btnVote.setEnabled(false);
        for (JRadioButton option : options.keySet()) {
            option.setEnabled(false);
        }
        if (!finishedNotified) {
            showMessage("La votación ha finalizado. Ya no se reciben nuevos votos.", TemaInterfaz.RED);
            finishedNotified = true;
        }
    }

    private JPanel createVoteCard(Document candidate, boolean enabled) {
        PanelRedondeado card = new PanelRedondeado(18, Color.WHITE);
        card.setLayout(new BorderLayout(0, 9));
        card.setBorder(javax.swing.BorderFactory.createEmptyBorder(16, 16, 16, 16));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        top.setOpaque(false);
        top.add(new javax.swing.JLabel(UtilImagen.load(candidateService.getPhoto(candidate), 58, 58)));
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new javax.swing.BoxLayout(info, javax.swing.BoxLayout.Y_AXIS));
        javax.swing.JLabel list = new javax.swing.JLabel("LISTA " + candidate.getInteger("listNumber"));
        list.setFont(TemaInterfaz.font(11, Font.BOLD));
        list.setForeground(TemaInterfaz.BLUE);
        javax.swing.JLabel name = new javax.swing.JLabel(candidate.getString("fullName"));
        name.setFont(TemaInterfaz.font(15, Font.BOLD));
        name.setForeground(TemaInterfaz.NAVY_DARK);
        javax.swing.JLabel course = new javax.swing.JLabel(candidateService.getCareer(candidate));
        course.setFont(TemaInterfaz.font(11, Font.PLAIN));
        course.setForeground(TemaInterfaz.MUTED);
        info.add(list);
        info.add(name);
        info.add(course);
        top.add(info);
        card.add(top, BorderLayout.NORTH);

        javax.swing.JLabel proposal = new javax.swing.JLabel("<html><div style='width:180px;'>"
                + escape(candidate.getString("proposal")) + "</div></html>");
        proposal.setFont(TemaInterfaz.font(12, Font.PLAIN));
        proposal.setForeground(TemaInterfaz.TEXT);
        card.add(proposal, BorderLayout.CENTER);

        JRadioButton option = new JRadioButton("Seleccionar candidatura");
        option.setOpaque(false);
        option.setFont(TemaInterfaz.font(12, Font.BOLD));
        option.setForeground(TemaInterfaz.BLUE);
        option.setEnabled(enabled);
        group.add(option);
        options.put(option, candidate.getString("candidateId"));
        card.add(option, BorderLayout.SOUTH);
        return card;
    }

    private String escape(String text) {
        return text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        headerPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblSubtitle = new javax.swing.JLabel();
        btnRefresh = new javax.swing.JButton();
        bodyPanel = new javax.swing.JPanel();
        electionCard = new components.PanelRedondeado();
        lblVoteIcon = new javax.swing.JLabel();
        electionTextPanel = new javax.swing.JPanel();
        lblElection = new javax.swing.JLabel();
        lblState = new javax.swing.JLabel();
        lblTimer = new javax.swing.JLabel();
        candidatesScroll = new javax.swing.JScrollPane();
        candidatesGrid = new javax.swing.JPanel();
        lblCandidatesPreview = new javax.swing.JLabel();
        footerPanel = new javax.swing.JPanel();
        lblMessage = new javax.swing.JLabel();
        btnVote = new components.BotonRedondeado();

        setBackground(new java.awt.Color(245, 248, 252));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(25, 30, 25, 30));
        setPreferredSize(new java.awt.Dimension(1050, 650));
        setLayout(new java.awt.BorderLayout(0, 16));

        headerPanel.setOpaque(false);
        headerPanel.setLayout(new java.awt.BorderLayout());

        titlePanel.setOpaque(false);
        titlePanel.setLayout(new java.awt.GridBagLayout());

        lblTitle.setText("Emitir voto");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblTitle, gridBagConstraints);

        lblSubtitle.setText("Selecciona una candidatura y confirma tu decisión una sola vez.");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblSubtitle, gridBagConstraints);

        headerPanel.add(titlePanel, java.awt.BorderLayout.WEST);

        btnRefresh.setText("↻ Actualizar");
        headerPanel.add(btnRefresh, java.awt.BorderLayout.EAST);

        add(headerPanel, java.awt.BorderLayout.NORTH);

        bodyPanel.setOpaque(false);
        bodyPanel.setLayout(new java.awt.BorderLayout(0, 16));

        electionCard.setBorder(javax.swing.BorderFactory.createEmptyBorder(14, 18, 14, 18));
        electionCard.setLayout(new java.awt.BorderLayout(16, 0));

        lblVoteIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/gui/vote_mark_panel.png"))); // NOI18N
        electionCard.add(lblVoteIcon, java.awt.BorderLayout.WEST);

        electionTextPanel.setOpaque(false);
        electionTextPanel.setLayout(new java.awt.GridBagLayout());

        lblElection.setText("Cargando...");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        electionTextPanel.add(lblElection, gridBagConstraints);

        lblState.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        electionTextPanel.add(lblState, gridBagConstraints);

        lblTimer.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        electionTextPanel.add(lblTimer, gridBagConstraints);

        electionCard.add(electionTextPanel, java.awt.BorderLayout.CENTER);

        bodyPanel.add(electionCard, java.awt.BorderLayout.NORTH);

        candidatesGrid.setBackground(new java.awt.Color(245, 248, 252));
        candidatesGrid.setLayout(new java.awt.GridLayout(0, 3, 16, 16));

        lblCandidatesPreview.setText("Las candidaturas se cargarán desde MongoDB");
        candidatesGrid.add(lblCandidatesPreview);

        candidatesScroll.setViewportView(candidatesGrid);

        bodyPanel.add(candidatesScroll, java.awt.BorderLayout.CENTER);

        add(bodyPanel, java.awt.BorderLayout.CENTER);

        footerPanel.setOpaque(false);
        footerPanel.setLayout(new java.awt.BorderLayout());

        lblMessage.setText(" ");
        footerPanel.add(lblMessage, java.awt.BorderLayout.WEST);

        btnVote.setText("Confirmar voto");
        footerPanel.add(btnVote, java.awt.BorderLayout.EAST);

        add(footerPanel, java.awt.BorderLayout.SOUTH);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bodyPanel;
    private javax.swing.JButton btnRefresh;
    private components.BotonRedondeado btnVote;
    private javax.swing.JPanel candidatesGrid;
    private javax.swing.JScrollPane candidatesScroll;
    private components.PanelRedondeado electionCard;
    private javax.swing.JPanel electionTextPanel;
    private javax.swing.JPanel footerPanel;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel lblCandidatesPreview;
    private javax.swing.JLabel lblElection;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblState;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblTimer;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblVoteIcon;
    private javax.swing.JPanel titlePanel;
    // End of variables declaration//GEN-END:variables
}
