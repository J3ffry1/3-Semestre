package vista;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

/** Colores y estilos reutilizables para la interfaz Swing. */
public final class TemaInterfaz {
    public static final Color NAVY = new Color(13, 44, 84);
    public static final Color NAVY_DARK = new Color(8, 28, 56);
    public static final Color BLUE = new Color(37, 99, 235);
    public static final Color CYAN = new Color(14, 165, 233);
    public static final Color GREEN = new Color(16, 185, 129);
    public static final Color ORANGE = new Color(245, 158, 11);
    public static final Color RED = new Color(239, 68, 68);
    public static final Color BG = new Color(245, 248, 252);
    public static final Color CARD = Color.WHITE;
    public static final Color TEXT = new Color(30, 41, 59);
    public static final Color MUTED = new Color(100, 116, 139);
    public static final Color LINE = new Color(226, 232, 240);

    private TemaInterfaz() {
    }

    public static Font font(int size, int style) {
        return new Font("Segoe UI", style, size);
    }

    public static void styleField(JTextField field) {
        field.setFont(font(14, Font.PLAIN));
        field.setForeground(TEXT);
        field.setBackground(Color.WHITE);
        field.setCaretColor(BLUE);
        field.setBorder(new CompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(9, 12, 9, 12)));
    }

    public static void styleField(JPasswordField field) {
        field.setFont(font(14, Font.PLAIN));
        field.setForeground(TEXT);
        field.setBackground(Color.WHITE);
        field.setCaretColor(BLUE);
        field.setBorder(new CompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(9, 12, 9, 12)));
    }

    public static void styleTextArea(JTextArea area) {
        area.setFont(font(14, Font.PLAIN));
        area.setForeground(TEXT);
        area.setBackground(Color.WHITE);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(new CompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(8, 10, 8, 10)));
    }

    public static void styleCombo(JComboBox<?> combo) {
        combo.setFont(font(14, Font.PLAIN));
        combo.setBackground(Color.WHITE);
        combo.setForeground(TEXT);
        combo.setBorder(new LineBorder(LINE, 1, true));
    }

    public static void styleSecondaryButton(JButton button) {
        button.setFont(font(13, Font.BOLD));
        button.setForeground(BLUE);
        button.setBackground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(new LineBorder(new Color(191, 219, 254), 1, true),
                new EmptyBorder(9, 13, 9, 13)));
    }

    public static JLabel title(String text) {
        JLabel label = new JLabel(text);
        label.setFont(font(24, Font.BOLD));
        label.setForeground(NAVY_DARK);
        return label;
    }

    public static JLabel subtitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(font(13, Font.PLAIN));
        label.setForeground(MUTED);
        return label;
    }

    public static void setPadding(JComponent component, int all) {
        component.setBorder(new EmptyBorder(all, all, all, all));
    }
}
