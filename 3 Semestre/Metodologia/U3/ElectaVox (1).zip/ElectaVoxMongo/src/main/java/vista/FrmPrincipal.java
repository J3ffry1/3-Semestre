package vista;

import components.BotonRedondeado;
import components.PanelDegradado;
import components.UtilImagen;
import config.ConfiguracionMongo;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import model.SesionUsuario;
import panels.Actualizable;
import panels.PanelCandidatos;
import panels.PanelEleccion;
import panels.PanelEstudiantes;
import panels.PanelReportes;
import panels.PanelResultados;
import panels.PanelResumen;
import panels.PanelVotacion;

/**
 * JFrame Form principal de ElectaVox. El menú lateral, la barra superior y el
 * contenedor central son editables desde la pestaña Design de NetBeans.
 */
public class FrmPrincipal extends javax.swing.JFrame {

    private final SesionUsuario session;
    private final CardLayout cardLayout = new CardLayout();
    private final Map<String, Actualizable> pages = new LinkedHashMap<>();
    private final Map<String, BotonRedondeado> menuButtons = new LinkedHashMap<>();

    /** Constructor auxiliar para que el formulario pueda previsualizarse. */
    public FrmPrincipal() {
        this(new SesionUsuario("admin@espe.edu.ec", "Administrador ElectaVox", "ADMIN", null));
    }

    public FrmPrincipal(SesionUsuario session) {
        this.session = session;
        initComponents();
        configurarInterfaz();
        cargarPaginas();
        setLocationRelativeTo(null);
        SwingUtilities.invokeLater(() -> showPage("INICIO"));
    }

    private void configurarInterfaz() {
        sidebar.setFirstColor(TemaInterfaz.NAVY_DARK);
        sidebar.setSecondColor(TemaInterfaz.NAVY);
        lblLogo.setIcon(UtilImagen.load("logo_electavox.png", 180, 55));

        lblSistema.setFont(TemaInterfaz.font(10, Font.BOLD));
        lblUsuario.setFont(TemaInterfaz.font(13, Font.BOLD));
        lblRol.setFont(TemaInterfaz.font(12, Font.PLAIN));
        lblPageTitle.setFont(TemaInterfaz.font(19, Font.BOLD));
        lblPageSubtitle.setFont(TemaInterfaz.font(12, Font.PLAIN));
        lblMongo.setFont(TemaInterfaz.font(12, Font.BOLD));

        lblUsuario.setText(session.fullName());
        lblRol.setText(session.isAdmin() ? "Administrador" : "Estudiante");

        configurarBotonMenu(btnInicio, "INICIO");
        configurarBotonMenu(btnEstudiantes, "ESTUDIANTES");
        configurarBotonMenu(btnCandidatos, "CANDIDATOS");
        configurarBotonMenu(btnVotar, "VOTAR");
        configurarBotonMenu(btnResultados, "RESULTADOS");
        configurarBotonMenu(btnReportes, "REPORTES");
        configurarBotonMenu(btnEleccion, "ELECCION");

        btnEstudiantes.setVisible(session.isAdmin());
        btnReportes.setVisible(session.isAdmin());
        btnEleccion.setVisible(session.isAdmin());
        btnCandidatos.setVisible(session.isAdmin());

        btnCerrarSesion.setColors(new Color(30, 64, 115), new Color(185, 28, 28));
        btnCerrarSesion.setRadius(12);
        btnCerrarSesion.addActionListener(event -> cerrarSesion());

        cardPanel.setLayout(cardLayout);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent event) {
                ConfiguracionMongo.close();
            }
        });
    }

    private void configurarBotonMenu(BotonRedondeado button, String id) {
        button.setHorizontalAlignment(BotonRedondeado.LEFT);
        button.setFont(TemaInterfaz.font(13, Font.BOLD));
        button.setColors(new Color(20, 54, 98), new Color(30, 94, 167));
        button.setRadius(12);
        button.addActionListener(event -> showPage(id));
        menuButtons.put(id, button);
    }

    private void cargarPaginas() {
    addPage("INICIO", new PanelResumen(session));

    if (session.isAdmin()) {
        addPage("ESTUDIANTES", new PanelEstudiantes());
        addPage("CANDIDATOS", new PanelCandidatos(session));
        addPage("REPORTES", new PanelReportes());
        addPage("ELECCION", new PanelEleccion());
    }

    addPage("VOTAR", new PanelVotacion(session));
    addPage("RESULTADOS", new PanelResultados());
}

    private void addPage(String name, Actualizable page) {
        pages.put(name, page);
        cardPanel.add((JPanel) page, name);
    }

    private void cerrarSesion() {
        dispose();
        new FrmInicioSesion().setVisible(true);
    }

    private void showPage(String id) {
        if (!pages.containsKey(id)) {
            return;
        }
        cardLayout.show(cardPanel, id);
        Actualizable page = pages.get(id);
        if (page != null) {
            page.refreshData();
        }
        switch (id) {
            case "INICIO" -> setHeader("Panel principal", "Resumen operativo de ElectaVox");
            case "ESTUDIANTES" -> setHeader("Registro de estudiantes", "Gestión del padrón electoral y credenciales");
            case "CANDIDATOS" -> setHeader("Gestión de candidatos", "Registro y consulta de candidaturas");
            case "VOTAR" -> setHeader("Proceso de votación", "Emisión de voto con validación de voto único");
            case "RESULTADOS" -> setHeader("Resultados y estadísticas", "Conteo en tiempo real, curso y género");
            case "REPORTES" -> setHeader("Reportes", "Generación del consolidado final TXT");
            case "ELECCION" -> setHeader("Temporizador electoral", "Control de apertura y cierre de la elección");
            default -> setHeader("ElectaVox", "Sistema de votación estudiantil");
        }
        for (Map.Entry<String, BotonRedondeado> entry : menuButtons.entrySet()) {
            boolean selected = entry.getKey().equals(id);
            entry.getValue().setColors(
                    selected ? TemaInterfaz.BLUE : new Color(20, 54, 98),
                    selected ? new Color(29, 78, 216) : new Color(30, 94, 167));
        }
    }

    private void setHeader(String title, String subtitle) {
        lblPageTitle.setText(title);
        lblPageSubtitle.setText(subtitle);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        root = new javax.swing.JPanel();
        sidebar = new components.PanelDegradado();
        sidebarTop = new javax.swing.JPanel();
        logoPanel = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        lblSistema = new javax.swing.JLabel();
        menuPanel = new javax.swing.JPanel();
        btnInicio = new components.BotonRedondeado();
        btnEstudiantes = new components.BotonRedondeado();
        btnCandidatos = new components.BotonRedondeado();
        btnVotar = new components.BotonRedondeado();
        btnResultados = new components.BotonRedondeado();
        btnReportes = new components.BotonRedondeado();
        btnEleccion = new components.BotonRedondeado();
        userPanel = new javax.swing.JPanel();
        lblSeparador = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        lblRol = new javax.swing.JLabel();
        btnCerrarSesion = new components.BotonRedondeado();
        workspace = new javax.swing.JPanel();
        topbar = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        lblPageTitle = new javax.swing.JLabel();
        lblPageSubtitle = new javax.swing.JLabel();
        mongoPanel = new javax.swing.JPanel();
        lblMongo = new javax.swing.JLabel();
        cardPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ElectaVox | Sistema de votación estudiantil");
        setMinimumSize(new java.awt.Dimension(1220, 750));
        setPreferredSize(new java.awt.Dimension(1320, 820));

        root.setBackground(new java.awt.Color(245, 248, 252));
        root.setLayout(new java.awt.BorderLayout());

        sidebar.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 16, 18, 16));
        sidebar.setPreferredSize(new java.awt.Dimension(245, 0));
        sidebar.setLayout(new java.awt.BorderLayout());

        sidebarTop.setOpaque(false);
        sidebarTop.setLayout(new java.awt.BorderLayout(0, 8));

        logoPanel.setOpaque(false);
        logoPanel.setLayout(new java.awt.GridBagLayout());

        lblLogo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/gui/logo_principal.png"))); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        logoPanel.add(lblLogo, gridBagConstraints);

        lblSistema.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        lblSistema.setForeground(new java.awt.Color(186, 230, 253));
        lblSistema.setText("ELECCIONES ESTUDIANTILES");
        lblSistema.setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 16, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        logoPanel.add(lblSistema, gridBagConstraints);

        sidebarTop.add(logoPanel, java.awt.BorderLayout.NORTH);

        menuPanel.setOpaque(false);
        menuPanel.setLayout(new java.awt.GridLayout(0, 1, 0, 7));

        btnInicio.setText("  Panel principal");
        btnInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioActionPerformed(evt);
            }
        });
        menuPanel.add(btnInicio);

        btnEstudiantes.setText("Estudiantes");
        menuPanel.add(btnEstudiantes);

        btnCandidatos.setText("Candidatos");
        btnCandidatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCandidatosActionPerformed(evt);
            }
        });
        menuPanel.add(btnCandidatos);

        btnVotar.setText("Emitir voto");
        menuPanel.add(btnVotar);

        btnResultados.setText("Resultados");
        menuPanel.add(btnResultados);

        btnReportes.setText("Reportes");
        menuPanel.add(btnReportes);

        btnEleccion.setText("Temporizador");
        menuPanel.add(btnEleccion);

        sidebarTop.add(menuPanel, java.awt.BorderLayout.CENTER);

        sidebar.add(sidebarTop, java.awt.BorderLayout.NORTH);

        userPanel.setOpaque(false);
        userPanel.setLayout(new java.awt.GridBagLayout());

        lblSeparador.setForeground(new java.awt.Color(96, 165, 250));
        lblSeparador.setText("────────────────────────");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        userPanel.add(lblSeparador, gridBagConstraints);

        lblUsuario.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblUsuario.setText("Administrador ElectaVox");
        lblUsuario.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 3, 2, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        userPanel.add(lblUsuario, gridBagConstraints);

        lblRol.setForeground(new java.awt.Color(191, 219, 254));
        lblRol.setText("Administrador");
        lblRol.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 3, 12, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        userPanel.add(lblRol, gridBagConstraints);

        btnCerrarSesion.setText("Cerrar sesión");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        userPanel.add(btnCerrarSesion, gridBagConstraints);

        sidebar.add(userPanel, java.awt.BorderLayout.SOUTH);

        root.add(sidebar, java.awt.BorderLayout.WEST);

        workspace.setBackground(new java.awt.Color(245, 248, 252));
        workspace.setLayout(new java.awt.BorderLayout());

        topbar.setBackground(new java.awt.Color(255, 255, 255));
        topbar.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createEmptyBorder(16, 28, 16, 28)));
        topbar.setLayout(new java.awt.BorderLayout());

        titlePanel.setOpaque(false);
        titlePanel.setLayout(new java.awt.GridBagLayout());

        lblPageTitle.setFont(new java.awt.Font("Segoe UI", 1, 19)); // NOI18N
        lblPageTitle.setForeground(new java.awt.Color(8, 28, 56));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblPageTitle, gridBagConstraints);

        lblPageSubtitle.setForeground(new java.awt.Color(100, 116, 139));
        lblPageSubtitle.setText("Resumen operativo de ElectaVox");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblPageSubtitle, gridBagConstraints);

        topbar.add(titlePanel, java.awt.BorderLayout.WEST);

        mongoPanel.setOpaque(false);
        mongoPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));

        lblMongo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblMongo.setForeground(new java.awt.Color(16, 185, 129));
        mongoPanel.add(lblMongo);

        topbar.add(mongoPanel, java.awt.BorderLayout.EAST);

        workspace.add(topbar, java.awt.BorderLayout.NORTH);

        cardPanel.setBackground(new java.awt.Color(245, 248, 252));
        cardPanel.setLayout(new java.awt.CardLayout());
        workspace.add(cardPanel, java.awt.BorderLayout.CENTER);

        root.add(workspace, java.awt.BorderLayout.CENTER);

        getContentPane().add(root, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnInicioActionPerformed

    private void btnCandidatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCandidatosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCandidatosActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private components.BotonRedondeado btnCandidatos;
    private components.BotonRedondeado btnCerrarSesion;
    private components.BotonRedondeado btnEleccion;
    private components.BotonRedondeado btnEstudiantes;
    private components.BotonRedondeado btnInicio;
    private components.BotonRedondeado btnReportes;
    private components.BotonRedondeado btnResultados;
    private components.BotonRedondeado btnVotar;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblMongo;
    private javax.swing.JLabel lblPageSubtitle;
    private javax.swing.JLabel lblPageTitle;
    private javax.swing.JLabel lblRol;
    private javax.swing.JLabel lblSeparador;
    private javax.swing.JLabel lblSistema;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel logoPanel;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JPanel mongoPanel;
    private javax.swing.JPanel root;
    private components.PanelDegradado sidebar;
    private javax.swing.JPanel sidebarTop;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topbar;
    private javax.swing.JPanel userPanel;
    private javax.swing.JPanel workspace;
    // End of variables declaration//GEN-END:variables
}
