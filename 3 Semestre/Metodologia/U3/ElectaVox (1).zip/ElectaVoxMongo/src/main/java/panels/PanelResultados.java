package panels;

import components.PanelRedondeado;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.JProgressBar;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import model.ElementoResultado;
import org.bson.Document;
import service.ServicioEleccion;
import service.ServicioResultados;
import vista.TemaInterfaz;

/** Resultados y estadísticas convertidos a JPanel Form editable en NetBeans. */
public class PanelResultados extends javax.swing.JPanel implements Actualizable {

    private final ServicioEleccion electionService = new ServicioEleccion();
    private final ServicioResultados resultService = new ServicioResultados();
    private final DefaultTableModel courseModel = model("Curso");
    private final DefaultTableModel genderModel = model("Género");

    public PanelResultados() {
        initComponents();
        configurarInterfaz();
        if (!java.beans.Beans.isDesignTime()) {
            new Timer(2_000, event -> refreshData()).start();
        }
    }

    private void configurarInterfaz() {
        lblTitle.setFont(TemaInterfaz.font(24, Font.BOLD));
        lblTitle.setForeground(TemaInterfaz.NAVY_DARK);
        lblSubtitle.setFont(TemaInterfaz.font(13, Font.PLAIN));
        lblSubtitle.setForeground(TemaInterfaz.MUTED);
        lblElection.setFont(TemaInterfaz.font(16, Font.BOLD));
        lblElection.setForeground(TemaInterfaz.NAVY_DARK);
        lblTotal.setFont(TemaInterfaz.font(13, Font.BOLD));
        lblTotal.setForeground(TemaInterfaz.GREEN);
        tabs.setFont(TemaInterfaz.font(13, Font.BOLD));
        TemaInterfaz.styleSecondaryButton(btnRefresh);
        btnRefresh.addActionListener(event -> refreshData());

        courseTable.setModel(courseModel);
        genderTable.setModel(genderModel);
        configurarTabla(courseTable);
        configurarTabla(genderTable);
    }

    private void configurarTabla(javax.swing.JTable table) {
        table.setRowHeight(31);
        table.setFont(TemaInterfaz.font(13, Font.PLAIN));
        table.getTableHeader().setFont(TemaInterfaz.font(13, Font.BOLD));
        table.getColumnModel().getColumn(2).setCellRenderer(new PercentageRenderer());
    }

    private DefaultTableModel model(String firstColumn) {
        return new DefaultTableModel(new Object[]{firstColumn, "Votantes", "Participación"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    @Override
    public void refreshData() {
        Document election = electionService.getActiveElection();
        if (election == null) {
            lblElection.setText("Sin elección activa");
            lblTotal.setText("0 votos registrados");
            liveResults.removeAll();
            courseModel.setRowCount(0);
            genderModel.setRowCount(0);
            return;
        }
        String electionId = election.getString("electionId");
        long total = resultService.totalVotes(electionId);
        lblElection.setText(election.getString("name"));
        lblTotal.setText(total + (total == 1 ? " voto registrado" : " votos registrados"));
        renderLiveResults(resultService.candidateResults(electionId));
        fillTable(courseModel, resultService.statisticsByCourse(electionId));
        fillTable(genderModel, resultService.statisticsByGender(electionId));
    }

    private void renderLiveResults(List<ElementoResultado> rows) {
        liveResults.removeAll();
        if (rows.isEmpty()) {
            javax.swing.JLabel empty = new javax.swing.JLabel("No existen candidaturas registradas.");
            empty.setFont(TemaInterfaz.font(14, Font.PLAIN));
            empty.setForeground(TemaInterfaz.MUTED);
            liveResults.add(empty);
        }
        for (ElementoResultado item : rows) {
            PanelRedondeado row = new PanelRedondeado(18, Color.WHITE);
            row.setLayout(new BorderLayout(12, 6));
            row.setBorder(javax.swing.BorderFactory.createEmptyBorder(13, 16, 13, 16));
            javax.swing.JPanel text = new javax.swing.JPanel();
            text.setOpaque(false);
            text.setLayout(new javax.swing.BoxLayout(text, javax.swing.BoxLayout.Y_AXIS));
            javax.swing.JLabel name = new javax.swing.JLabel(item.label());
            name.setFont(TemaInterfaz.font(14, Font.BOLD));
            name.setForeground(TemaInterfaz.NAVY_DARK);
            javax.swing.JLabel values = new javax.swing.JLabel(item.votes() + " votos · "
                    + String.format("%.2f%%", item.percentage()));
            values.setFont(TemaInterfaz.font(12, Font.PLAIN));
            values.setForeground(TemaInterfaz.MUTED);
            text.add(name);
            text.add(values);
            row.add(text, BorderLayout.WEST);
            JProgressBar progress = new JProgressBar(0, 100);
            progress.setValue((int) Math.round(item.percentage()));
            progress.setStringPainted(true);
            progress.setString(String.format("%.1f%%", item.percentage()));
            progress.setForeground(TemaInterfaz.BLUE);
            progress.setBackground(new Color(226, 232, 240));
            row.add(progress, BorderLayout.CENTER);
            liveResults.add(row);
        }
        liveResults.revalidate();
        liveResults.repaint();
    }

    private void fillTable(DefaultTableModel model, List<ElementoResultado> items) {
        model.setRowCount(0);
        for (ElementoResultado item : items) {
            model.addRow(new Object[]{item.label(), item.votes(), item.percentage()});
        }
    }

    private static final class PercentageRenderer extends JProgressBar implements TableCellRenderer {
        private PercentageRenderer() {
            super(0, 100);
            setStringPainted(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            double percentage = value instanceof Number number ? number.doubleValue() : 0;
            setValue((int) Math.round(percentage));
            setString(String.format("%.2f%%", percentage));
            setToolTipText("Porcentaje de participación respecto al padrón del grupo");
            return this;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        headerPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblSubtitle = new javax.swing.JLabel();
        btnRefresh = new javax.swing.JButton();
        bodyPanel = new javax.swing.JPanel();
        infoCard = new components.PanelRedondeado();
        lblElection = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        tabs = new javax.swing.JTabbedPane();
        liveTab = new javax.swing.JPanel();
        liveScroll = new javax.swing.JScrollPane();
        liveResults = new javax.swing.JPanel();
        lblLivePreview = new javax.swing.JLabel();
        courseTab = new javax.swing.JPanel();
        courseScroll = new javax.swing.JScrollPane();
        courseTable = new javax.swing.JTable();
        genderTab = new javax.swing.JPanel();
        genderScroll = new javax.swing.JScrollPane();
        genderTable = new javax.swing.JTable();

        setBackground(new java.awt.Color(245, 248, 252));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(25, 30, 25, 30));
        setPreferredSize(new java.awt.Dimension(1050, 650));
        setLayout(new java.awt.BorderLayout(0, 16));

        headerPanel.setOpaque(false);
        headerPanel.setLayout(new java.awt.BorderLayout());

        titlePanel.setOpaque(false);
        titlePanel.setLayout(new java.awt.GridBagLayout());

        lblTitle.setText("Resultados y estadísticas");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblTitle, gridBagConstraints);

        lblSubtitle.setText("Conteo actualizado directamente desde la colección votes de MongoDB.");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblSubtitle, gridBagConstraints);

        headerPanel.add(titlePanel, java.awt.BorderLayout.WEST);

        btnRefresh.setText("↻ Actualizar resultados");
        headerPanel.add(btnRefresh, java.awt.BorderLayout.EAST);

        add(headerPanel, java.awt.BorderLayout.NORTH);

        bodyPanel.setOpaque(false);
        bodyPanel.setLayout(new java.awt.BorderLayout(0, 14));

        infoCard.setBorder(javax.swing.BorderFactory.createEmptyBorder(14, 18, 14, 18));
        infoCard.setLayout(new java.awt.BorderLayout());

        lblElection.setText("Cargando...");
        infoCard.add(lblElection, java.awt.BorderLayout.WEST);

        lblTotal.setText("0 votos registrados");
        infoCard.add(lblTotal, java.awt.BorderLayout.EAST);

        bodyPanel.add(infoCard, java.awt.BorderLayout.NORTH);

        liveTab.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 4, 4, 4));
        liveTab.setBackground(new java.awt.Color(245, 248, 252));
        liveTab.setLayout(new java.awt.BorderLayout());

        liveResults.setBackground(new java.awt.Color(245, 248, 252));
        liveResults.setLayout(new java.awt.GridLayout(0, 1, 0, 10));

        lblLivePreview.setText("Los resultados en vivo se cargarán desde MongoDB");
        liveResults.add(lblLivePreview);

        liveScroll.setViewportView(liveResults);

        liveTab.add(liveScroll, java.awt.BorderLayout.CENTER);

        tabs.addTab("Resultados en tiempo real", liveTab);

        courseTab.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 4, 4, 4));
        courseTab.setBackground(new java.awt.Color(245, 248, 252));
        courseTab.setLayout(new java.awt.BorderLayout());

        courseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Curso", "Votantes", "Participación"
            }
        ));
        courseScroll.setViewportView(courseTable);

        courseTab.add(courseScroll, java.awt.BorderLayout.CENTER);

        tabs.addTab("Estadísticas por curso", courseTab);

        genderTab.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 4, 4, 4));
        genderTab.setBackground(new java.awt.Color(245, 248, 252));
        genderTab.setLayout(new java.awt.BorderLayout());

        genderTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Género", "Votantes", "Participación"
            }
        ));
        genderScroll.setViewportView(genderTable);

        genderTab.add(genderScroll, java.awt.BorderLayout.CENTER);

        tabs.addTab("Estadísticas por género", genderTab);

        bodyPanel.add(tabs, java.awt.BorderLayout.CENTER);

        add(bodyPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bodyPanel;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JScrollPane courseScroll;
    private javax.swing.JPanel courseTab;
    private javax.swing.JTable courseTable;
    private javax.swing.JScrollPane genderScroll;
    private javax.swing.JPanel genderTab;
    private javax.swing.JTable genderTable;
    private javax.swing.JPanel headerPanel;
    private components.PanelRedondeado infoCard;
    private javax.swing.JLabel lblElection;
    private javax.swing.JLabel lblLivePreview;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel liveResults;
    private javax.swing.JScrollPane liveScroll;
    private javax.swing.JPanel liveTab;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JPanel titlePanel;
    // End of variables declaration//GEN-END:variables
}
