package service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import model.ElementoResultado;
import org.bson.Document;
import util.UtilFecha;

public class ServicioReportes {
    private final ServicioEleccion electionService = new ServicioEleccion();
    private final ServicioResultados resultService = new ServicioResultados();
    private final ServicioEstudiantes studentService = new ServicioEstudiantes();

    public Path generateTxt() throws IOException {
        Document election = electionService.getActiveElection();
        if (election == null) {
            throw new IllegalStateException("No existe una elección activa.");
        }
        return writeFinalReport(election);
    }

    /** Genera automáticamente el reporte final y el acta de cierre. */
    public List<Path> generateClosureDocuments() throws IOException {
        Document election = electionService.getActiveElection();
        if (election == null) {
            throw new IllegalStateException("No existe una elección activa.");
        }
        List<Path> files = new ArrayList<>();
        files.add(writeFinalReport(election));
        files.add(writeClosingAct(election));
        return files;
    }

    public String winnerSummary(Document election) {
        if (election == null) {
            return "No existe una elección activa.";
        }
        return resultService.winnerSummary(election.getString("electionId"));
    }

    private Path writeFinalReport(Document election) throws IOException {
        String electionId = election.getString("electionId");
        long totalStudents = studentService.count();
        long totalVotes = resultService.totalVotes(electionId);
        double participation = totalStudents == 0 ? 0 : totalVotes * 100.0 / totalStudents;
        Date closedAt = election.getDate("closedAt");
        Date generatedAt = new Date();

        StringBuilder content = new StringBuilder();
        content.append("REPORTE FINAL ELECTAVOX\n");
        content.append("========================================\n");
        content.append("Elección: ").append(election.getString("name")).append('\n');
        content.append("Periodo: ").append(UtilFecha.format(election.getDate("startAt")))
                .append(" - ").append(UtilFecha.format(election.getDate("endAt"))).append('\n');
        content.append("Fecha y hora de cierre: ")
                .append(UtilFecha.format(closedAt == null ? generatedAt : closedAt)).append('\n');
        content.append("Fecha de generación: ").append(UtilFecha.format(generatedAt)).append('\n');
        content.append("Estado: ").append(Boolean.TRUE.equals(election.getBoolean("closed")) ? "CERRADA" : "EN CURSO").append("\n\n");

        content.append("ESTADÍSTICAS GENERALES\n");
        content.append("Estudiantes habilitados: ").append(totalStudents).append('\n');
        content.append("Total de votos emitidos: ").append(totalVotes).append('\n');
        content.append("Participación general: ").append(formatPercentage(participation)).append("\n\n");

        content.append("RESULTADOS FINALES\n");
        appendRows(content, resultService.candidateResults(electionId));
        content.append('\n').append(resultService.winnerSummary(electionId)).append("\n\n");

        content.append("PARTICIPACIÓN POR CURSO\n");
        appendRows(content, resultService.statisticsByCourse(electionId));
        content.append("\nPARTICIPACIÓN POR GÉNERO\n");
        appendRows(content, resultService.statisticsByGender(electionId));

        return writeFile("reporte_final_electavox_", content.toString());
    }

    private Path writeClosingAct(Document election) throws IOException {
        String electionId = election.getString("electionId");
        Date closedAt = election.getDate("closedAt");
        if (closedAt == null) {
            closedAt = new Date();
        }
        StringBuilder content = new StringBuilder();
        content.append("ACTA DE CIERRE OFICIAL - ELECTAVOX\n");
        content.append("========================================\n");
        content.append("Elección: ").append(election.getString("name")).append('\n');
        content.append("Código: ").append(electionId).append('\n');
        content.append("Fecha y hora del cierre: ").append(UtilFecha.format(closedAt)).append('\n');
        content.append("Total de votos emitidos: ").append(resultService.totalVotes(electionId)).append("\n\n");
        content.append("DECLARACIÓN DE RESULTADOS\n");
        content.append(resultService.winnerSummary(electionId)).append("\n\n");
        appendRows(content, resultService.candidateResults(electionId));
        content.append("\nCon el cierre oficial se bloquea la recepción de nuevos votos.\n\n");
        content.append("Firma del administrador: ______________________________\n");
        return writeFile("acta_cierre_electavox_", content.toString());
    }

    private Path writeFile(String prefix, String content) throws IOException {
        Path reports = Path.of(System.getProperty("user.dir"), "reports");
        Files.createDirectories(reports);
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
        Path file = reports.resolve(prefix + stamp + ".txt");
        Files.writeString(file, content, StandardCharsets.UTF_8);
        return file;
    }

    private void appendRows(StringBuilder content, List<ElementoResultado> rows) {
        if (rows.isEmpty()) {
            content.append("Sin información registrada.\n");
            return;
        }
        for (ElementoResultado row : rows) {
            content.append("- ").append(row.label())
                    .append(" | Votantes/Votos: ").append(row.votes())
                    .append(" | Porcentaje: ").append(formatPercentage(row.percentage()))
                    .append('\n');
        }
    }

    private String formatPercentage(double value) {
        return String.format(Locale.US, "%.2f%%", value);
    }
}
