package components;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

/**
 * Panel con degradado editable desde el diseñador visual de NetBeans.
 */
public class PanelDegradado extends JPanel {
    private Color firstColor = new Color(8, 28, 56);
    private Color secondColor = new Color(37, 99, 235);

    /** Constructor requerido por el GUI Builder. */
    public PanelDegradado() {
        setOpaque(false);
    }

    public PanelDegradado(Color firstColor, Color secondColor) {
        this();
        this.firstColor = firstColor;
        this.secondColor = secondColor;
    }

    public Color getFirstColor() {
        return firstColor;
    }

    public void setFirstColor(Color firstColor) {
        this.firstColor = firstColor == null ? new Color(8, 28, 56) : firstColor;
        repaint();
    }

    public Color getSecondColor() {
        return secondColor;
    }

    public void setSecondColor(Color secondColor) {
        this.secondColor = secondColor == null ? new Color(37, 99, 235) : secondColor;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        Graphics2D g2 = (Graphics2D) graphics.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setPaint(new GradientPaint(0, 0, firstColor, getWidth(), getHeight(), secondColor));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
        super.paintComponent(graphics);
    }
}
