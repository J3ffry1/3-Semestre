package components;

import vista.TemaInterfaz;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** Tarjeta de métrica compatible con la paleta y el diseñador de NetBeans. */
public class TarjetaMetrica extends PanelRedondeado {
    private final JLabel value = new JLabel("0");
    private final JLabel caption = new JLabel("Métrica");
    private final JLabel emoji = new JLabel("●", JLabel.CENTER);
    private Color accentColor = TemaInterfaz.BLUE;

    /** Constructor requerido por el GUI Builder. */
    public TarjetaMetrica() {
        this("●", "Métrica", TemaInterfaz.BLUE);
    }

    public TarjetaMetrica(String icon, String text, Color accent) {
        super(20, Color.WHITE);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 0, 0, TemaInterfaz.LINE),
                BorderFactory.createEmptyBorder(16, 18, 16, 18)));

        emoji.setFont(TemaInterfaz.font(24, Font.PLAIN));
        emoji.setOpaque(true);
        emoji.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        add(emoji, BorderLayout.WEST);

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new javax.swing.BoxLayout(body, javax.swing.BoxLayout.Y_AXIS));
        value.setFont(TemaInterfaz.font(25, Font.BOLD));
        value.setForeground(TemaInterfaz.TEXT);
        caption.setFont(TemaInterfaz.font(12, Font.PLAIN));
        caption.setForeground(TemaInterfaz.MUTED);
        body.add(value);
        body.add(caption);
        add(body, BorderLayout.CENTER);

        setIconText(icon);
        setCaption(text);
        setAccentColor(accent);
    }

    public void setValue(String text) {
        value.setText(text);
    }

    public String getValue() {
        return value.getText();
    }

    public String getCaption() {
        return caption.getText();
    }

    public void setCaption(String text) {
        caption.setText(text == null ? "" : text);
    }

    public String getIconText() {
        return emoji.getText();
    }

    public void setIconText(String text) {
        emoji.setText(text == null ? "" : text);
    }

    public Color getAccentColor() {
        return accentColor;
    }

    public void setAccentColor(Color accent) {
        accentColor = accent == null ? TemaInterfaz.BLUE : accent;
        emoji.setBackground(new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 28));
        emoji.setForeground(accentColor);
    }
}
