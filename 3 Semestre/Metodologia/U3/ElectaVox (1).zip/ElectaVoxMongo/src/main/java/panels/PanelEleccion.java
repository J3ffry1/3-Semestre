package panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.time.Duration;
import java.time.Instant;
import java.nio.file.Path;
import java.util.List;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.Timer;
import org.bson.Document;
import service.ServicioEleccion;
import service.ServicioReportes;
import util.UtilFecha;
import vista.TemaInterfaz;

/** Temporizador electoral convertido a JPanel Form editable en NetBeans. */
public class PanelEleccion extends javax.swing.JPanel implements Actualizable {

    private final ServicioEleccion servicioEleccion = new ServicioEleccion();
    private final ServicioReportes servicioReportes = new ServicioReportes();
    private Document eleccion;
    private boolean cierreAutomaticoNotificado;

    public PanelEleccion() {
        initComponents();
        configurarInterfaz();
        if (!java.beans.Beans.isDesignTime()) {
            new Timer(1_000, evento -> actualizarTemporizador()).start();
            new Timer(60_000, evento -> refreshData()).start();
        }
    }

    private void configurarInterfaz() {
        lblTitle.setFont(TemaInterfaz.font(24, Font.BOLD));
        lblTitle.setForeground(TemaInterfaz.NAVY_DARK);
        lblSubtitle.setFont(TemaInterfaz.font(13, Font.PLAIN));
        lblSubtitle.setForeground(TemaInterfaz.MUTED);
        lblNombre.setFont(TemaInterfaz.font(22, Font.BOLD));
        lblNombre.setForeground(TemaInterfaz.NAVY_DARK);
        lblEstado.setFont(TemaInterfaz.font(14, Font.BOLD));
        lblPeriodo.setFont(TemaInterfaz.font(13, Font.PLAIN));
        lblPeriodo.setForeground(TemaInterfaz.MUTED);
        lblTemporizador.setFont(TemaInterfaz.font(20, Font.BOLD));
        lblTemporizador.setForeground(TemaInterfaz.BLUE);
        lblModificar.setFont(TemaInterfaz.font(14, Font.BOLD));
        lblModificar.setForeground(TemaInterfaz.NAVY_DARK);

        configurarSpinner(spnDias);
        configurarSpinner(spnHoras);
        configurarSpinner(spnMinutos);
        configurarSpinner(spnSegundos);
        TemaInterfaz.styleSecondaryButton(btnActualizar);
        btnActualizar.addActionListener(evento -> refreshData());
        btnAplicarTiempo.setColors(TemaInterfaz.BLUE, TemaInterfaz.NAVY);
        btnAplicarTiempo.setRadius(14);
        btnAplicarTiempo.addActionListener(evento -> aplicarTiempoRestante());
        btnCerrar.setColors(TemaInterfaz.RED, new Color(185, 28, 28));
        btnCerrar.setRadius(14);
        btnCerrar.addActionListener(evento -> alternarEleccion());
    }

    private void configurarSpinner(JSpinner spinner) {
        spinner.setPreferredSize(new Dimension(58, 30));
        spinner.setFont(TemaInterfaz.font(13, Font.PLAIN));
    }

    private void aplicarTiempoRestante() {
        if (eleccion == null) {
            return;
        }

        long dias = ((Number) spnDias.getValue()).longValue();
        long horas = ((Number) spnHoras.getValue()).longValue();
        long minutos = ((Number) spnMinutos.getValue()).longValue();
        long segundos = ((Number) spnSegundos.getValue()).longValue();

        long segundosTotales = dias * 86_400L + horas * 3_600L + minutos * 60L + segundos;
        if (segundosTotales <= 0) {
            JOptionPane.showMessageDialog(this, "Ingresa un tiempo mayor que cero.",
                    "Tiempo no válido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Date nuevaFechaFin = Date.from(Instant.now().plusSeconds(segundosTotales));
        String idEleccion = eleccion.getString("electionId");

        try {
            servicioEleccion.actualizarFechaFin(idEleccion, nuevaFechaFin);
            eleccion.put("endAt", nuevaFechaFin);
            lblPeriodo.setText("Periodo: " + UtilFecha.format(eleccion.getDate("startAt")) + "  —  "
                    + UtilFecha.format(nuevaFechaFin));
            actualizarTemporizador();
            cargarTiempoEnControles();
            JOptionPane.showMessageDialog(this, "El tiempo restante se actualizó correctamente.",
                    "Temporizador actualizado", JOptionPane.INFORMATION_MESSAGE);
        } catch (RuntimeException excepcion) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo actualizar el tiempo restante: " + excepcion.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void alternarEleccion() {
        if (eleccion == null) {
            return;
        }
        boolean cerrada = Boolean.TRUE.equals(eleccion.getBoolean("closed"));
        if (cerrada) {
            int respuesta = JOptionPane.showConfirmDialog(this,
                    "La elección fue cerrada oficialmente. ¿Deseas reabrirla?",
                    "Reabrir elección", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }
            servicioEleccion.reopenElection(eleccion.getString("electionId"));
            cierreAutomaticoNotificado = false;
        } else {
            int respuesta = JOptionPane.showConfirmDialog(this,
                    "Se bloquearán nuevos votos, se declarará el ganador y se generarán los archivos TXT.\n"
                    + "¿Confirmas el cierre oficial?",
                    "Cerrar elección", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }
            servicioEleccion.closeElection(eleccion.getString("electionId"));
            eleccion.put("closed", true);
            eleccion.put("closedAt", new Date());
            mostrarDocumentosDeCierre("Elección cerrada oficialmente.");
        }
        refreshData();
    }

    private void mostrarDocumentosDeCierre(String encabezado) {
        try {
            List<Path> archivos = servicioReportes.generateClosureDocuments();
            String ganador = servicioReportes.winnerSummary(eleccion);
            String rutas = archivos.stream().map(path -> path.toAbsolutePath().toString())
                    .reduce((a, b) -> a + "\n" + b).orElse("-");
            JOptionPane.showMessageDialog(this,
                    encabezado + "\n\n" + ganador + "\n\nArchivos generados:\n" + rutas,
                    "Cierre electoral", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    encabezado + "\nLa votación quedó bloqueada, pero no se pudieron generar los archivos TXT: "
                    + ex.getMessage(),
                    "Cierre electoral", JOptionPane.WARNING_MESSAGE);
        }
    }

    @Override
    public void refreshData() {
        eleccion = servicioEleccion.getActiveElection();
        if (eleccion == null) {
            lblNombre.setText("No hay una elección activa");
            lblEstado.setText("● Sin configuración");
            lblEstado.setForeground(TemaInterfaz.RED);
            lblPeriodo.setText("-");
            lblTemporizador.setText("-");
            habilitarControles(false);
            return;
        }

        boolean abierta = servicioEleccion.isOpen(eleccion);
        lblNombre.setText(eleccion.getString("name"));
        lblEstado.setText(abierta ? "● Votación abierta" : "● Votación cerrada");
        lblEstado.setForeground(abierta ? TemaInterfaz.GREEN : TemaInterfaz.RED);
        lblPeriodo.setText("Periodo: " + UtilFecha.format(eleccion.getDate("startAt")) + "  —  "
                + UtilFecha.format(eleccion.getDate("endAt")));

        actualizarTemporizador();
        cargarTiempoEnControles();

        boolean cerrada = Boolean.TRUE.equals(eleccion.getBoolean("closed"));
        btnCerrar.setText(cerrada ? "Reabrir elección" : "Cerrar elección");
        btnCerrar.setColors(cerrada ? TemaInterfaz.GREEN : TemaInterfaz.RED,
                cerrada ? TemaInterfaz.NAVY : new Color(185, 28, 28));
        habilitarControles(true);
    }

    private void habilitarControles(boolean habilitado) {
        spnDias.setEnabled(habilitado);
        spnHoras.setEnabled(habilitado);
        spnMinutos.setEnabled(habilitado);
        spnSegundos.setEnabled(habilitado);
        btnAplicarTiempo.setEnabled(habilitado);
        btnCerrar.setEnabled(habilitado);
    }

    private void cargarTiempoEnControles() {
        if (eleccion == null || eleccion.getDate("endAt") == null) {
            return;
        }

        Duration duracion = Duration.between(new Date().toInstant(), eleccion.getDate("endAt").toInstant());
        long segundosTotales = Math.max(0, duracion.getSeconds());
        int dias = (int) Math.min(3650L, segundosTotales / 86_400L);
        int horas = (int) ((segundosTotales % 86_400L) / 3_600L);
        int minutos = (int) ((segundosTotales % 3_600L) / 60L);
        int segundos = (int) (segundosTotales % 60L);
        spnDias.setValue(dias);
        spnHoras.setValue(horas);
        spnMinutos.setValue(minutos);
        spnSegundos.setValue(segundos);
    }

    private void actualizarTemporizador() {
        if (eleccion == null) {
            return;
        }

        Date fechaFin = eleccion.getDate("endAt");
        if (fechaFin == null) {
            lblTemporizador.setText("Tiempo restante: Sin fecha");
            return;
        }

        Duration duracion = Duration.between(new Date().toInstant(), fechaFin.toInstant());
        if (duracion.isNegative() || duracion.isZero()) {
            boolean cerradoAhora = servicioEleccion.closeIfExpired(eleccion);
            eleccion.put("closed", true);
            lblTemporizador.setText("Tiempo restante: Finalizado");
            lblEstado.setText("● Votación cerrada");
            lblEstado.setForeground(TemaInterfaz.RED);
            btnCerrar.setText("Reabrir elección");
            btnCerrar.setColors(TemaInterfaz.GREEN, TemaInterfaz.NAVY);
            if (cerradoAhora && !cierreAutomaticoNotificado) {
                cierreAutomaticoNotificado = true;
                mostrarDocumentosDeCierre("El tiempo terminó y la elección se cerró automáticamente.");
            }
            return;
        }

        long segundosTotales = duracion.getSeconds();
        long dias = segundosTotales / 86_400;
        long horas = (segundosTotales % 86_400) / 3_600;
        long minutos = (segundosTotales % 3_600) / 60;
        long segundos = segundosTotales % 60;
        lblTemporizador.setText(String.format("Tiempo restante: %02d días %02d:%02d:%02d",
                dias, horas, minutos, segundos));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        headerPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblSubtitle = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        centerPanel = new javax.swing.JPanel();
        electionCard = new components.PanelRedondeado();
        lblIllustration = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblEstado = new javax.swing.JLabel();
        lblPeriodo = new javax.swing.JLabel();
        lblTemporizador = new javax.swing.JLabel();
        lblModificar = new javax.swing.JLabel();
        timePanel = new javax.swing.JPanel();
        lblDias = new javax.swing.JLabel();
        spnDias = new javax.swing.JSpinner();
        lblHoras = new javax.swing.JLabel();
        spnHoras = new javax.swing.JSpinner();
        lblMinutos = new javax.swing.JLabel();
        spnMinutos = new javax.swing.JSpinner();
        lblSegundos = new javax.swing.JLabel();
        spnSegundos = new javax.swing.JSpinner();
        btnAplicarTiempo = new components.BotonRedondeado();
        btnCerrar = new components.BotonRedondeado();

        setBackground(new java.awt.Color(245, 248, 252));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(25, 30, 25, 30));
        setPreferredSize(new java.awt.Dimension(1050, 650));
        setLayout(new java.awt.BorderLayout(0, 16));

        headerPanel.setOpaque(false);
        headerPanel.setLayout(new java.awt.BorderLayout());

        titlePanel.setOpaque(false);
        titlePanel.setLayout(new java.awt.GridBagLayout());

        lblTitle.setText("Temporizador y cierre electoral");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblTitle, gridBagConstraints);

        lblSubtitle.setText("Modifica el tiempo restante y controla el cierre de la votación.");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        titlePanel.add(lblSubtitle, gridBagConstraints);

        headerPanel.add(titlePanel, java.awt.BorderLayout.WEST);

        btnActualizar.setText("Actualizar");
        headerPanel.add(btnActualizar, java.awt.BorderLayout.EAST);

        add(headerPanel, java.awt.BorderLayout.NORTH);

        centerPanel.setOpaque(false);
        centerPanel.setLayout(new java.awt.GridBagLayout());

        electionCard.setBorder(javax.swing.BorderFactory.createEmptyBorder(25, 35, 25, 35));
        electionCard.setRadius(24);
        electionCard.setLayout(new java.awt.GridBagLayout());

        lblIllustration.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/gui/timer_illustration_panel.png"))); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 0);
        electionCard.add(lblIllustration, gridBagConstraints);

        lblNombre.setText("Cargando...");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 0);
        electionCard.add(lblNombre, gridBagConstraints);

        lblEstado.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(5, 0, 4, 0);
        electionCard.add(lblEstado, gridBagConstraints);

        lblPeriodo.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        electionCard.add(lblPeriodo, gridBagConstraints);

        lblTemporizador.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(14, 0, 10, 0);
        electionCard.add(lblTemporizador, gridBagConstraints);

        lblModificar.setText("Modificar tiempo restante");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(2, 0, 8, 0);
        electionCard.add(lblModificar, gridBagConstraints);

        timePanel.setOpaque(false);
        timePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 8, 0));

        lblDias.setText("Días:");
        timePanel.add(lblDias);

        spnDias.setModel(new javax.swing.SpinnerNumberModel(0, 0, 3650, 1));
        timePanel.add(spnDias);

        lblHoras.setText("Horas:");
        timePanel.add(lblHoras);

        spnHoras.setModel(new javax.swing.SpinnerNumberModel(0, 0, 23, 1));
        timePanel.add(spnHoras);

        lblMinutos.setText("Min:");
        timePanel.add(lblMinutos);

        spnMinutos.setModel(new javax.swing.SpinnerNumberModel(0, 0, 59, 1));
        timePanel.add(spnMinutos);

        lblSegundos.setText("Seg:");
        timePanel.add(lblSegundos);

        spnSegundos.setModel(new javax.swing.SpinnerNumberModel(0, 0, 59, 1));
        timePanel.add(spnSegundos);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 0);
        electionCard.add(timePanel, gridBagConstraints);

        btnAplicarTiempo.setText("Aplicar tiempo restante");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 0);
        electionCard.add(btnAplicarTiempo, gridBagConstraints);

        btnCerrar.setText("Cerrar elección");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        electionCard.add(btnCerrar, gridBagConstraints);

        centerPanel.add(electionCard, new java.awt.GridBagConstraints());

        add(centerPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private components.BotonRedondeado btnAplicarTiempo;
    private components.BotonRedondeado btnCerrar;
    private javax.swing.JPanel centerPanel;
    private components.PanelRedondeado electionCard;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel lblDias;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblHoras;
    private javax.swing.JLabel lblIllustration;
    private javax.swing.JLabel lblMinutos;
    private javax.swing.JLabel lblModificar;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPeriodo;
    private javax.swing.JLabel lblSegundos;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblTemporizador;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JSpinner spnDias;
    private javax.swing.JSpinner spnHoras;
    private javax.swing.JSpinner spnMinutos;
    private javax.swing.JSpinner spnSegundos;
    private javax.swing.JPanel timePanel;
    private javax.swing.JPanel titlePanel;
    // End of variables declaration//GEN-END:variables
}
