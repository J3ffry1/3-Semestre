package service;

import static com.mongodb.client.model.Filters.eq;

import com.mongodb.client.MongoDatabase;
import config.ConfiguracionMongo;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import model.ElementoResultado;
import org.bson.Document;

public class ServicioResultados {
    private final MongoDatabase db = ConfiguracionMongo.getDatabase();
    private final ServicioCandidatos candidateService = new ServicioCandidatos();

    public long totalVotes(String electionId) {
        return db.getCollection("votes").countDocuments(eq("electionId", electionId));
    }

    public List<ElementoResultado> candidateResults(String electionId) {
        long total = totalVotes(electionId);
        List<ElementoResultado> items = new ArrayList<>();
        for (Document candidate : candidateService.listByElection(electionId)) {
            long votes = db.getCollection("votes").countDocuments(new Document("electionId", electionId)
                    .append("candidateId", candidate.getString("candidateId")));
            double percentage = total == 0 ? 0 : (votes * 100.0 / total);
            String label = "Lista " + candidate.getInteger("listNumber") + " - " + candidate.getString("fullName");
            items.add(new ElementoResultado(label, votes, percentage));
        }
        return items;
    }

    public List<ElementoResultado> statisticsByCourse(String electionId) {
        return participationByGroup(electionId, "course", "studentCourse");
    }

    public List<ElementoResultado> statisticsByGender(String electionId) {
        return participationByGroup(electionId, "gender", "studentGender");
    }

    /** Porcentaje de participación = estudiantes que votaron / estudiantes habilitados del grupo. */
    private List<ElementoResultado> participationByGroup(String electionId,
            String studentField, String voteField) {
        Map<String, Long> registered = aggregateCounts("students",
                new Document("active", true), studentField);
        Map<String, Long> voters = aggregateCounts("votes",
                new Document("electionId", electionId), voteField);

        Map<String, ElementoResultado> result = new LinkedHashMap<>();
        for (Map.Entry<String, Long> entry : registered.entrySet()) {
            String group = normalized(entry.getKey());
            long enabled = entry.getValue();
            long voted = voters.getOrDefault(group, 0L);
            double percentage = enabled == 0 ? 0 : voted * 100.0 / enabled;
            result.put(group, new ElementoResultado(group + " (" + enabled + " registrados)", voted, percentage));
        }
        for (Map.Entry<String, Long> entry : voters.entrySet()) {
            String group = normalized(entry.getKey());
            if (!result.containsKey(group)) {
                long voted = entry.getValue();
                result.put(group, new ElementoResultado(group + " (sin padrón asociado)", voted, 0));
            }
        }

        List<ElementoResultado> ordered = new ArrayList<>(result.values());
        ordered.sort(Comparator.comparingLong(ElementoResultado::votes).reversed()
                .thenComparing(ElementoResultado::label));
        return ordered;
    }

    private Map<String, Long> aggregateCounts(String collection, Document match, String field) {
        List<Document> rows = db.getCollection(collection).aggregate(List.of(
                new Document("$match", match),
                new Document("$group", new Document("_id", "$" + field)
                        .append("total", new Document("$sum", 1)))
        )).into(new ArrayList<>());
        Map<String, Long> result = new LinkedHashMap<>();
        for (Document row : rows) {
            String label = normalized(row.getString("_id"));
            long total = ((Number) row.get("total")).longValue();
            result.merge(label, total, Long::sum);
        }
        return result;
    }

    private String normalized(String value) {
        return value == null || value.isBlank() ? "No especificado" : value.trim();
    }

    public String winnerSummary(String electionId) {
        List<ElementoResultado> results = candidateResults(electionId);
        long total = totalVotes(electionId);
        if (results.isEmpty()) {
            return "No existen candidatos registrados.";
        }
        if (total == 0) {
            return "No se puede declarar ganador porque no existen votos emitidos.";
        }
        long maximum = results.stream().mapToLong(ElementoResultado::votes).max().orElse(0);
        List<String> winners = results.stream()
                .filter(item -> item.votes() == maximum)
                .map(ElementoResultado::label)
                .toList();
        if (winners.size() > 1) {
            return "Empate entre: " + String.join("; ", winners) + " con " + maximum + " votos cada uno.";
        }
        return "Ganador: " + winners.getFirst() + " con " + maximum + " votos ("
                + String.format(java.util.Locale.US, "%.2f%%", maximum * 100.0 / total) + ").";
    }
}
