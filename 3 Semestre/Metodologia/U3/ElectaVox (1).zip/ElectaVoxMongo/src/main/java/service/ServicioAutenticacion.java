package service;

import static com.mongodb.client.model.Filters.eq;

import com.mongodb.client.MongoDatabase;
import config.ConfiguracionMongo;
import model.SesionUsuario;
import org.bson.Document;
import util.UtilClave;
import util.UtilValidacion;

/** Autenticación por cédula para estudiantes y por correo para administradores. */
public class ServicioAutenticacion {

    public SesionUsuario login(String identifier, String password) {
        MongoDatabase db = ConfiguracionMongo.getDatabase();
        String normalized = identifier == null ? "" : identifier.trim().toLowerCase();
        if (normalized.isBlank()) {
            return null;
        }

        Document user;
        Document student = null;
        if (UtilValidacion.isCedula(normalized)) {
            user = db.getCollection("users").find(eq("cedula", normalized)).first();
            student = db.getCollection("students").find(eq("cedula", normalized)).first();

            // Compatibilidad con registros creados por versiones anteriores.
            if (user == null && student != null) {
                user = db.getCollection("users").find(eq("email", student.getString("email"))).first();
            }
        } else {
            user = db.getCollection("users").find(eq("email", normalized)).first();
            if (user != null && "STUDENT".equalsIgnoreCase(user.getString("role"))) {
                student = db.getCollection("students").find(eq("email", normalized)).first();
            }
        }

        if (user == null || !Boolean.TRUE.equals(user.getBoolean("active"))) {
            return null;
        }
        if (!UtilClave.matches(password, user.getString("passwordHash"))) {
            return null;
        }

        String role = user.getString("role");
        if ("STUDENT".equalsIgnoreCase(role)) {
            if (student == null) {
                String cedula = user.getString("cedula");
                student = cedula == null ? null
                        : db.getCollection("students").find(eq("cedula", cedula)).first();
            }
            if (student == null || !Boolean.TRUE.equals(student.getBoolean("active"))) {
                return null;
            }
        }

        String studentId = student == null ? null : student.getString("studentId");
        String email = user.getString("email");
        return new SesionUsuario(email == null ? normalized : email,
                user.getString("fullName"), role, studentId);
    }

    public boolean studentCedulaExists(String cedula) {
        if (!UtilValidacion.isCedula(cedula)) {
            return false;
        }
        Document student = ConfiguracionMongo.getDatabase().getCollection("students")
                .find(eq("cedula", cedula.trim())).first();
        return student != null && Boolean.TRUE.equals(student.getBoolean("active"));
    }
}
