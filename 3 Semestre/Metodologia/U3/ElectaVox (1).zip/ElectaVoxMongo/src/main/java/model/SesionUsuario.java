package model;

/** Datos mínimos del usuario autenticado dentro de la aplicación. */
public record SesionUsuario(String email, String fullName, String role, String studentId) {
    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(role);
    }
}
