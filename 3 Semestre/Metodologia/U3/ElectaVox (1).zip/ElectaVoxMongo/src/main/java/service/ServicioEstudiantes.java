package service;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Sorts.ascending;

import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import config.ConfiguracionMongo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.Document;
import util.UtilClave;
import util.UtilId;
import util.UtilValidacion;

public class ServicioEstudiantes {
    private final MongoDatabase db = ConfiguracionMongo.getDatabase();

    public List<Document> list() {
        List<Document> students = new ArrayList<>();
        db.getCollection("students").find().sort(ascending("fullName")).into(students);
        return students;
    }

    public long count() {
        return db.getCollection("students").countDocuments(eq("active", true));
    }

    public void create(String cedula, String fullName, String email, String course,
            String gender, String password) {
        cedula = clean(cedula);
        fullName = clean(fullName);
        email = clean(email).toLowerCase();
        course = clean(course);
        gender = clean(gender);

        if (!UtilValidacion.isCedula(cedula)) {
            throw new IllegalArgumentException("La cédula debe tener exactamente 10 dígitos.");
        }
        if (fullName.isBlank() || course.isBlank() || gender.isBlank()) {
            throw new IllegalArgumentException("Complete nombre, curso y género.");
        }
        if (email.isBlank()) {
            email = cedula + "@electavox.local";
        } else if (!UtilValidacion.isEmail(email)) {
            throw new IllegalArgumentException("Ingrese un correo válido o deje el campo vacío.");
        }
        if (!UtilValidacion.isStrongEnough(password)) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres.");
        }

        MongoCollection<Document> users = db.getCollection("users");
        MongoCollection<Document> students = db.getCollection("students");
        Document user = new Document("email", email)
                .append("cedula", cedula)
                .append("fullName", fullName)
                .append("role", "STUDENT")
                .append("passwordHash", UtilClave.hash(password))
                .append("active", true)
                .append("createdAt", new Date());
        Document student = new Document("studentId", UtilId.newId("EST"))
                .append("cedula", cedula)
                .append("fullName", fullName)
                .append("email", email)
                .append("course", course)
                .append("gender", gender)
                .append("active", true)
                .append("createdAt", new Date());
        try {
            users.insertOne(user);
            try {
                students.insertOne(student);
            } catch (RuntimeException ex) {
                users.deleteOne(eq("email", email));
                throw ex;
            }
        } catch (MongoWriteException ex) {
            if (ex.getError().getCategory() == ErrorCategory.DUPLICATE_KEY) {
                throw new IllegalArgumentException("Ya existe un estudiante o usuario con esa cédula/correo.");
            }
            throw ex;
        }
    }

    public void deleteByStudentId(String studentId) {
        Document student = db.getCollection("students").find(eq("studentId", studentId)).first();
        if (student != null) {
            db.getCollection("students").deleteOne(eq("studentId", studentId));
            db.getCollection("users").deleteOne(eq("cedula", student.getString("cedula")));
            db.getCollection("users").deleteOne(eq("email", student.getString("email")));
        }
    }

    private String clean(String value) {
        return value == null ? "" : value.trim();
    }
}
