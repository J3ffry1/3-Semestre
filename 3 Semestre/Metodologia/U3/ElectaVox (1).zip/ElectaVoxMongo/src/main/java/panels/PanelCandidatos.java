package panels;

import components.PanelRedondeado;
import components.UtilImagen;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.ListSelectionModel;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.SesionUsuario;
import org.bson.Document;
import service.ServicioCandidatos;
import service.ServicioEleccion;
import vista.TemaInterfaz;

/** Gestión de candidatos convertida a JPanel Form editable en NetBeans. */
public class PanelCandidatos extends javax.swing.JPanel implements Actualizable {

    private final SesionUsuario session;
    private final ServicioCandidatos candidateService = new ServicioCandidatos();
    private final ServicioEleccion electionService = new ServicioEleccion();
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"ID", "Lista", "Candidato", "Carrera", "Género", "Propuesta"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private List<Document> rows = new ArrayList<>();
    private byte[] selectedPhoto;
    private final JButton btnPhoto = new JButton("Seleccionar fotografía");
    private final JLabel lblPhotoSelected = new JLabel("Ninguna fotografía seleccionada");

    /** Constructor auxiliar para abrir el panel directamente en Design. */
    public PanelCandidatos() {
        this(new SesionUsuario("admin@espe.edu.ec", "Administrador ElectaVox", "ADMIN", null));
    }

    public PanelCandidatos(SesionUsuario session) {
        this.session = session;
        initComponents();
        configurarInterfaz();
    }

    private void configurarInterfaz() {
        lblLeftTitle.setFont(TemaInterfaz.font(24, Font.BOLD));
        lblLeftTitle.setForeground(TemaInterfaz.NAVY_DARK);
        lblLeftSubtitle.setFont(TemaInterfaz.font(13, Font.PLAIN));
        lblLeftSubtitle.setForeground(TemaInterfaz.MUTED);
        lblLeftSubtitle.setText(session.isAdmin()
                ? "Agrega postulantes para la elección activa."
                : "Solo lectura para usuarios estudiantes.");
        lblRightTitle.setFont(TemaInterfaz.font(20, Font.BOLD));
        lblRightTitle.setForeground(TemaInterfaz.NAVY_DARK);
        lblRightSubtitle.setFont(TemaInterfaz.font(13, Font.PLAIN));
        lblRightSubtitle.setForeground(TemaInterfaz.MUTED);

        TemaInterfaz.styleField(txtLista);
        TemaInterfaz.styleField(txtNombre);
        TemaInterfaz.styleField(txtCurso);
        TemaInterfaz.styleCombo(cmbGenero);
        TemaInterfaz.styleTextArea(txtPropuesta);
        configurarSelectorFoto();
        lblMessage.setFont(TemaInterfaz.font(12, Font.PLAIN));
        lblMessage.setForeground(TemaInterfaz.RED);

        btnSave.setColors(TemaInterfaz.BLUE, TemaInterfaz.NAVY);
        btnSave.setRadius(14);
        btnSave.setEnabled(session.isAdmin());
        btnSave.addActionListener(event -> createCandidate());
        TemaInterfaz.styleSecondaryButton(btnRefresh);
        TemaInterfaz.styleSecondaryButton(btnDelete);
        btnRefresh.addActionListener(event -> refreshData());
        btnDelete.addActionListener(event -> deleteSelected());
        btnDelete.setVisible(session.isAdmin());

        table.setModel(tableModel);
        table.setRowHeight(29);
        table.setFont(TemaInterfaz.font(13, Font.PLAIN));
        table.getTableHeader().setFont(TemaInterfaz.font(13, Font.BOLD));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void createCandidate() {
        try {
            Document election = electionService.getActiveElection();
            if (election == null) {
                throw new IllegalArgumentException("No hay una elección activa.");
            }
            int listNumber = Integer.parseInt(txtLista.getText().trim());
            candidateService.create(election.getString("electionId"), listNumber, txtNombre.getText(),
                    txtCurso.getText(), String.valueOf(cmbGenero.getSelectedItem()), txtPropuesta.getText(),
                    selectedPhoto);
            lblMessage.setForeground(TemaInterfaz.GREEN);
            lblMessage.setText("Candidato registrado correctamente.");
            clearForm();
            refreshData();
        } catch (NumberFormatException ex) {
            lblMessage.setForeground(TemaInterfaz.RED);
            lblMessage.setText("El número de lista debe ser un entero válido.");
        } catch (IllegalArgumentException ex) {
            lblMessage.setForeground(TemaInterfaz.RED);
            lblMessage.setText(ex.getMessage());
        } catch (RuntimeException ex) {
            lblMessage.setForeground(TemaInterfaz.RED);
            lblMessage.setText("No se pudo guardar el candidato.");
        }
    }

    private void clearForm() {
        txtLista.setText("");
        txtNombre.setText("");
        txtCurso.setText("");
        cmbGenero.setSelectedIndex(0);
        txtPropuesta.setText("");
        selectedPhoto = null;
        lblPhotoSelected.setIcon(null);
        lblPhotoSelected.setText("Ninguna fotografía seleccionada");
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            lblMessage.setForeground(TemaInterfaz.RED);
            lblMessage.setText("Seleccione un candidato de la tabla.");
            return;
        }
        candidateService.delete(rows.get(row).getString("candidateId"));
        lblMessage.setForeground(TemaInterfaz.GREEN);
        lblMessage.setText("Candidato eliminado.");
        refreshData();
    }

    @Override
    public void refreshData() {
        Document election = electionService.getActiveElection();
        rows = election == null ? List.of() : candidateService.listByElection(election.getString("electionId"));
        tableModel.setRowCount(0);
        candidateGallery.removeAll();
        for (Document candidate : rows) {
            tableModel.addRow(new Object[]{candidate.getString("candidateId"), candidate.getInteger("listNumber"),
                candidate.getString("fullName"), candidateService.getCareer(candidate), candidate.getString("gender"),
                candidate.getString("proposal")});
            candidateGallery.add(createCandidateCard(candidate));
        }
        candidateGallery.revalidate();
        candidateGallery.repaint();
    }

    private JPanel createCandidateCard(Document candidate) {
        PanelRedondeado card = new PanelRedondeado(18, Color.WHITE);
        card.setLayout(new BorderLayout(8, 8));
        card.setBorder(javax.swing.BorderFactory.createEmptyBorder(14, 14, 14, 14));
        JLabel image = new JLabel(UtilImagen.load(candidateService.getPhoto(candidate), 72, 72));
        card.add(image, BorderLayout.WEST);

        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new javax.swing.BoxLayout(text, javax.swing.BoxLayout.Y_AXIS));
        JLabel list = new JLabel("LISTA " + candidate.getInteger("listNumber"));
        list.setFont(TemaInterfaz.font(11, Font.BOLD));
        list.setForeground(TemaInterfaz.BLUE);
        JLabel name = new JLabel(candidate.getString("fullName"));
        name.setFont(TemaInterfaz.font(14, Font.BOLD));
        name.setForeground(TemaInterfaz.NAVY_DARK);
        JLabel career = new JLabel(candidateService.getCareer(candidate));
        career.setFont(TemaInterfaz.font(11, Font.PLAIN));
        career.setForeground(TemaInterfaz.MUTED);
        JLabel proposal = new JLabel("<html><div style='width:145px;'>"
                + escape(candidate.getString("proposal")) + "</div></html>");
        proposal.setFont(TemaInterfaz.font(11, Font.PLAIN));
        proposal.setForeground(TemaInterfaz.TEXT);
        text.add(list);
        text.add(name);
        text.add(career);
        text.add(javax.swing.Box.createVerticalStrut(5));
        text.add(proposal);
        card.add(text, BorderLayout.CENTER);
        return card;
    }

    private void configurarSelectorFoto() {
        TemaInterfaz.styleSecondaryButton(btnPhoto);
        btnPhoto.setEnabled(session.isAdmin());
        btnPhoto.addActionListener(event -> selectPhoto());
        lblPhotoSelected.setFont(TemaInterfaz.font(11, Font.PLAIN));
        lblPhotoSelected.setForeground(TemaInterfaz.MUTED);

        GridBagLayout layout = (GridBagLayout) formCard.getLayout();
        GridBagConstraints messageConstraints = layout.getConstraints(lblMessage);
        messageConstraints.gridy = 12;
        messageConstraints.insets = new Insets(4, 0, 0, 0);
        layout.setConstraints(lblMessage, messageConstraints);

        GridBagConstraints saveConstraints = layout.getConstraints(btnSave);
        saveConstraints.gridy = 13;
        layout.setConstraints(btnSave, saveConstraints);

        GridBagConstraints photoButtonConstraints = new GridBagConstraints();
        photoButtonConstraints.gridx = 0;
        photoButtonConstraints.gridy = 10;
        photoButtonConstraints.fill = GridBagConstraints.HORIZONTAL;
        photoButtonConstraints.weightx = 1.0;
        photoButtonConstraints.insets = new Insets(5, 0, 5, 0);
        formCard.add(btnPhoto, photoButtonConstraints);

        GridBagConstraints photoLabelConstraints = new GridBagConstraints();
        photoLabelConstraints.gridx = 0;
        photoLabelConstraints.gridy = 11;
        photoLabelConstraints.fill = GridBagConstraints.HORIZONTAL;
        photoLabelConstraints.weightx = 1.0;
        photoLabelConstraints.insets = new Insets(0, 0, 3, 0);
        formCard.add(lblPhotoSelected, photoLabelConstraints);
    }

    private void selectPhoto() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Seleccionar fotografía del candidato");
        chooser.setFileFilter(new FileNameExtensionFilter("Imágenes JPG, JPEG o PNG", "jpg", "jpeg", "png"));
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        Path file = chooser.getSelectedFile().toPath();
        try {
            if (Files.size(file) > 3_000_000) {
                throw new IllegalArgumentException("La fotografía no debe superar 3 MB.");
            }
            byte[] bytes = Files.readAllBytes(file);
            ImageIcon icon = new ImageIcon(bytes);
            if (icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0) {
                throw new IllegalArgumentException("El archivo seleccionado no es una imagen válida.");
            }
            selectedPhoto = bytes;
            lblPhotoSelected.setIcon(UtilImagen.load(bytes, 42, 42));
            lblPhotoSelected.setText(" " + file.getFileName());
            lblMessage.setText(" ");
        } catch (IOException | IllegalArgumentException ex) {
            selectedPhoto = null;
            lblPhotoSelected.setIcon(null);
            lblPhotoSelected.setText("Ninguna fotografía seleccionada");
            lblMessage.setForeground(TemaInterfaz.RED);
            lblMessage.setText(ex.getMessage());
        }
    }

    private String escape(String text) {
        return text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        leftPanel = new javax.swing.JPanel();
        leftTitlePanel = new javax.swing.JPanel();
        lblLeftTitle = new javax.swing.JLabel();
        lblLeftSubtitle = new javax.swing.JLabel();
        formCard = new components.PanelRedondeado();
        lblLista = new javax.swing.JLabel();
        txtLista = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblCurso = new javax.swing.JLabel();
        txtCurso = new javax.swing.JTextField();
        lblGenero = new javax.swing.JLabel();
        cmbGenero = new javax.swing.JComboBox<>();
        lblPropuesta = new javax.swing.JLabel();
        proposalScroll = new javax.swing.JScrollPane();
        txtPropuesta = new javax.swing.JTextArea();
        lblMessage = new javax.swing.JLabel();
        btnSave = new components.BotonRedondeado();
        rightPanel = new javax.swing.JPanel();
        rightHeader = new javax.swing.JPanel();
        rightTitlePanel = new javax.swing.JPanel();
        lblRightTitle = new javax.swing.JLabel();
        lblRightSubtitle = new javax.swing.JLabel();
        actionsPanel = new javax.swing.JPanel();
        btnRefresh = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        rightBody = new javax.swing.JPanel();
        tableScroll = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        galleryScroll = new javax.swing.JScrollPane();
        candidateGallery = new javax.swing.JPanel();
        lblGalleryPreview = new javax.swing.JLabel();

        setBackground(new java.awt.Color(245, 248, 252));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(25, 30, 25, 30));
        setPreferredSize(new java.awt.Dimension(1050, 650));
        setLayout(new java.awt.BorderLayout(18, 0));

        leftPanel.setOpaque(false);
        leftPanel.setPreferredSize(new java.awt.Dimension(325, 0));
        leftPanel.setLayout(new java.awt.BorderLayout(0, 14));

        leftTitlePanel.setOpaque(false);
        leftTitlePanel.setLayout(new java.awt.GridBagLayout());

        lblLeftTitle.setText("Registro de candidatos");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        leftTitlePanel.add(lblLeftTitle, gridBagConstraints);

        lblLeftSubtitle.setText("Agrega postulantes para la elección activa.");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        leftTitlePanel.add(lblLeftSubtitle, gridBagConstraints);

        leftPanel.add(leftTitlePanel, java.awt.BorderLayout.NORTH);

        formCard.setBorder(javax.swing.BorderFactory.createEmptyBorder(18, 20, 18, 20));
        formCard.setLayout(new java.awt.GridBagLayout());

        lblLista.setText("Número de lista");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 5, 0);
        formCard.add(lblLista, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 0);
        formCard.add(txtLista, gridBagConstraints);

        lblNombre.setText("Nombres completos");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 5, 0);
        formCard.add(lblNombre, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 0);
        formCard.add(txtNombre, gridBagConstraints);

        lblCurso.setText("Carrera");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 5, 0);
        formCard.add(lblCurso, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 0);
        formCard.add(txtCurso, gridBagConstraints);

        lblGenero.setText("Género");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 5, 0);
        formCard.add(lblGenero, gridBagConstraints);

        cmbGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Femenino", "Masculino", "No especifica" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 0);
        formCard.add(cmbGenero, gridBagConstraints);

        lblPropuesta.setText("Propuesta / eslogan");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 5, 0);
        formCard.add(lblPropuesta, gridBagConstraints);

        txtPropuesta.setColumns(20);
        txtPropuesta.setRows(4);
        proposalScroll.setViewportView(txtPropuesta);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 6, 0);
        formCard.add(proposalScroll, gridBagConstraints);

        lblMessage.setText(" ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        formCard.add(lblMessage, gridBagConstraints);

        btnSave.setText("Registrar candidato");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 0, 0, 0);
        formCard.add(btnSave, gridBagConstraints);

        leftPanel.add(formCard, java.awt.BorderLayout.CENTER);

        add(leftPanel, java.awt.BorderLayout.WEST);

        rightPanel.setOpaque(false);
        rightPanel.setLayout(new java.awt.BorderLayout(0, 14));

        rightHeader.setOpaque(false);
        rightHeader.setLayout(new java.awt.BorderLayout());

        rightTitlePanel.setOpaque(false);
        rightTitlePanel.setLayout(new java.awt.GridBagLayout());

        lblRightTitle.setText("Consulta de candidatos");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        rightTitlePanel.add(lblRightTitle, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        rightTitlePanel.add(lblRightSubtitle, gridBagConstraints);

        rightHeader.add(rightTitlePanel, java.awt.BorderLayout.WEST);

        actionsPanel.setOpaque(false);
        actionsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 7, 0));

        btnRefresh.setText("Actualizar");
        actionsPanel.add(btnRefresh);

        btnDelete.setText("Eliminar seleccionado");
        actionsPanel.add(btnDelete);

        rightHeader.add(actionsPanel, java.awt.BorderLayout.EAST);

        rightPanel.add(rightHeader, java.awt.BorderLayout.NORTH);

        rightBody.setOpaque(false);
        rightBody.setLayout(new java.awt.BorderLayout(0, 18));

        tableScroll.setPreferredSize(new java.awt.Dimension(620, 200));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Lista", "Candidato", "Curso", "Género", "Propuesta"
            }
        ));
        tableScroll.setViewportView(table);

        rightBody.add(tableScroll, java.awt.BorderLayout.NORTH);

        candidateGallery.setBackground(new java.awt.Color(245, 248, 252));
        candidateGallery.setLayout(new java.awt.GridLayout(0, 3, 14, 14));

        lblGalleryPreview.setText("Las tarjetas se cargan desde MongoDB");
        candidateGallery.add(lblGalleryPreview);

        galleryScroll.setViewportView(candidateGallery);

        rightBody.add(galleryScroll, java.awt.BorderLayout.CENTER);

        rightPanel.add(rightBody, java.awt.BorderLayout.CENTER);

        add(rightPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel actionsPanel;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnRefresh;
    private components.BotonRedondeado btnSave;
    private javax.swing.JPanel candidateGallery;
    private javax.swing.JComboBox<String> cmbGenero;
    private components.PanelRedondeado formCard;
    private javax.swing.JScrollPane galleryScroll;
    private javax.swing.JLabel lblCurso;
    private javax.swing.JLabel lblGalleryPreview;
    private javax.swing.JLabel lblGenero;
    private javax.swing.JLabel lblLeftSubtitle;
    private javax.swing.JLabel lblLeftTitle;
    private javax.swing.JLabel lblLista;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPropuesta;
    private javax.swing.JLabel lblRightSubtitle;
    private javax.swing.JLabel lblRightTitle;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel leftTitlePanel;
    private javax.swing.JScrollPane proposalScroll;
    private javax.swing.JPanel rightBody;
    private javax.swing.JPanel rightHeader;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JPanel rightTitlePanel;
    private javax.swing.JTable table;
    private javax.swing.JScrollPane tableScroll;
    private javax.swing.JTextField txtCurso;
    private javax.swing.JTextField txtLista;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextArea txtPropuesta;
    // End of variables declaration//GEN-END:variables
}
