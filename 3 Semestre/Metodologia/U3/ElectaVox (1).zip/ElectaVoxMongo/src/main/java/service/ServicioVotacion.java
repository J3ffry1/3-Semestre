package service;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoDatabase;
import config.ConfiguracionMongo;
import model.SesionUsuario;
import java.util.Date;
import org.bson.Document;

public class ServicioVotacion {
    private final MongoDatabase db = ConfiguracionMongo.getDatabase();
    private final ServicioEleccion electionService = new ServicioEleccion();
    private final ServicioCandidatos candidateService = new ServicioCandidatos();

    public String castVote(SesionUsuario session, String candidateId) {
        if (session == null || session.isAdmin() || session.studentId() == null) {
            return "Solo un estudiante registrado puede emitir su voto.";
        }
        Document election = electionService.getActiveElection();
        if (!electionService.isOpen(election)) {
            return "La elección se encuentra cerrada o fuera del periodo de votación.";
        }
        Document candidate = candidateService.find(candidateId);
        if (candidate == null || !Boolean.TRUE.equals(candidate.getBoolean("active"))) {
            return "El candidato seleccionado no está disponible.";
        }
        Document student = db.getCollection("students").find(eq("studentId", session.studentId())).first();
        if (student == null || !Boolean.TRUE.equals(student.getBoolean("active"))) {
            return "Tu registro estudiantil no está activo.";
        }
        Document vote = new Document("electionId", election.getString("electionId"))
                .append("studentId", session.studentId())
                .append("candidateId", candidateId)
                .append("studentCourse", student.getString("course"))
                .append("studentGender", student.getString("gender"))
                .append("createdAt", new Date());
        try {
            db.getCollection("votes").insertOne(vote);
            return "Voto registrado correctamente. Gracias por participar.";
        } catch (MongoWriteException ex) {
            if (ex.getError().getCategory() == ErrorCategory.DUPLICATE_KEY) {
                return "No se registró el voto: ya emitiste tu voto en esta elección.";
            }
            throw ex;
        }
    }

    public boolean hasVoted(String electionId, String studentId) {
        return db.getCollection("votes").countDocuments(and(eq("electionId", electionId), eq("studentId", studentId))) > 0;
    }
}
