package service;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Sorts.ascending;

import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoDatabase;
import config.ConfiguracionMongo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bson.Document;
import org.bson.types.Binary;
import util.UtilId;

public class ServicioCandidatos {
    private final MongoDatabase db = ConfiguracionMongo.getDatabase();

    public List<Document> listByElection(String electionId) {
        List<Document> candidates = new ArrayList<>();
        db.getCollection("candidates").find(and(eq("electionId", electionId), eq("active", true)))
                .sort(ascending("listNumber")).into(candidates);
        return candidates;
    }

    public long countForElection(String electionId) {
        return db.getCollection("candidates").countDocuments(and(eq("electionId", electionId), eq("active", true)));
    }

    public void create(String electionId, int listNumber, String fullName, String career,
            String gender, String proposal, byte[] photoData) {
        if (listNumber <= 0) {
            throw new IllegalArgumentException("El número de lista debe ser mayor que cero.");
        }
        if (isBlank(fullName) || isBlank(career) || isBlank(gender) || isBlank(proposal)) {
            throw new IllegalArgumentException("Complete todos los datos del candidato.");
        }
        if (photoData == null || photoData.length == 0) {
            throw new IllegalArgumentException("Seleccione una fotografía del candidato.");
        }
        Document candidate = new Document("candidateId", UtilId.newId("CAN"))
                .append("electionId", electionId)
                .append("listNumber", listNumber)
                .append("fullName", fullName.trim())
                .append("career", career.trim())
                .append("gender", gender.trim())
                .append("proposal", proposal.trim())
                .append("photoData", new Binary(photoData))
                .append("active", true)
                .append("createdAt", new Date());
        try {
            db.getCollection("candidates").insertOne(candidate);
        } catch (MongoWriteException ex) {
            if (ex.getError().getCategory() == ErrorCategory.DUPLICATE_KEY) {
                throw new IllegalArgumentException("Ya existe un candidato con ese número de lista.");
            }
            throw ex;
        }
    }

    public void delete(String candidateId) {
        db.getCollection("candidates").deleteOne(eq("candidateId", candidateId));
    }

    public Document find(String candidateId) {
        return db.getCollection("candidates").find(eq("candidateId", candidateId)).first();
    }

    public String getCareer(Document candidate) {
        String career = candidate == null ? null : candidate.getString("career");
        if (career == null || career.isBlank()) {
            career = candidate == null ? null : candidate.getString("course");
        }
        return career == null ? "No especificada" : career;
    }

    public byte[] getPhoto(Document candidate) {
        if (candidate == null) {
            return null;
        }
        Object value = candidate.get("photoData");
        if (value instanceof Binary binary) {
            return binary.getData();
        }
        if (value instanceof byte[] bytes) {
            return bytes;
        }
        return null;
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
