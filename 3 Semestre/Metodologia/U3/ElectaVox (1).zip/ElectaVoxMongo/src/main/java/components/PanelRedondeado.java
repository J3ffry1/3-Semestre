package components;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

/**
 * Panel redondeado compatible con la paleta y el diseñador de NetBeans.
 */
public class PanelRedondeado extends JPanel {
    private int radius = 20;
    private Color fillColor = Color.WHITE;

    /** Constructor requerido por el GUI Builder. */
    public PanelRedondeado() {
        setOpaque(false);
    }

    public PanelRedondeado(int radius, Color fillColor) {
        this();
        this.radius = radius;
        this.fillColor = fillColor;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = Math.max(0, radius);
        repaint();
    }

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor == null ? Color.WHITE : fillColor;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        Graphics2D g2 = (Graphics2D) graphics.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(fillColor);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
        g2.dispose();
        super.paintComponent(graphics);
    }
}
