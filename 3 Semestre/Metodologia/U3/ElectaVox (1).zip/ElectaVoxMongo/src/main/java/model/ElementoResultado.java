package model;

/** Fila utilizada en resultados y estadísticas. */
public record ElementoResultado(String label, long votes, double percentage) {
}
