package util;

public final class UtilValidacion {
    private UtilValidacion() {
    }

    public static boolean isEmail(String value) {
        return value != null && value.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    }

    public static boolean isCedula(String value) {
        return value != null && value.matches("\\d{10}");
    }

    public static boolean isStrongEnough(String value) {
        return value != null && value.length() >= 8;
    }
}
