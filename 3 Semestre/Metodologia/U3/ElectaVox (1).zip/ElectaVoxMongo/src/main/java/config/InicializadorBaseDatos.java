package config;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import org.bson.Document;
import util.UtilClave;

/** Crea índices, datos iniciales y adapta registros de versiones anteriores. */
public final class InicializadorBaseDatos {
    private InicializadorBaseDatos() {
    }

    public static void bootstrap() {
        MongoDatabase db = ConfiguracionMongo.getDatabase();
        db.runCommand(new Document("ping", 1));
        createIndexes(db);
        seedInitialData(db);
        migrateLegacyData(db);
    }

    private static void createIndexes(MongoDatabase db) {
        db.getCollection("users").createIndex(Indexes.ascending("email"), new IndexOptions().unique(true));
        db.getCollection("users").createIndex(Indexes.ascending("cedula"),
                new IndexOptions().unique(true).sparse(true));
        db.getCollection("students").createIndex(Indexes.ascending("cedula"), new IndexOptions().unique(true));
        db.getCollection("students").createIndex(Indexes.ascending("email"), new IndexOptions().unique(true));
        db.getCollection("candidates").createIndex(Indexes.compoundIndex(
                Indexes.ascending("electionId"), Indexes.ascending("listNumber")), new IndexOptions().unique(true));
        db.getCollection("votes").createIndex(Indexes.compoundIndex(
                Indexes.ascending("electionId"), Indexes.ascending("studentId")), new IndexOptions().unique(true));
        db.getCollection("votes").createIndex(Indexes.ascending("candidateId"));
    }

    private static void seedInitialData(MongoDatabase db) {
        MongoCollection<Document> users = db.getCollection("users");
        if (users.countDocuments() == 0) {
            users.insertOne(new Document("email", "admin@espe.edu.ec")
                    .append("fullName", "Administrador ElectaVox")
                    .append("role", "ADMIN")
                    .append("passwordHash", UtilClave.hash("Admin123*"))
                    .append("active", true)
                    .append("createdAt", new Date()));
            users.insertOne(new Document("email", "estudiante@espe.edu.ec")
                    .append("cedula", "1723456789")
                    .append("fullName", "Estudiante de Demostración")
                    .append("role", "STUDENT")
                    .append("passwordHash", UtilClave.hash("Estudiante123*"))
                    .append("active", true)
                    .append("createdAt", new Date()));

            db.getCollection("students").insertOne(new Document("studentId", "EST-001")
                    .append("cedula", "1723456789")
                    .append("fullName", "Estudiante de Demostración")
                    .append("email", "estudiante@espe.edu.ec")
                    .append("course", "ITIN 3A")
                    .append("gender", "No especifica")
                    .append("active", true)
                    .append("createdAt", new Date()));
        }

        MongoCollection<Document> elections = db.getCollection("elections");
        if (elections.countDocuments() == 0) {
            Instant now = Instant.now();
            elections.insertOne(new Document("electionId", "ELEC-2026")
                    .append("name", "Elecciones Estudiantiles ElectaVox")
                    .append("active", true)
                    .append("closed", false)
                    .append("startAt", Date.from(now.minus(1, ChronoUnit.HOURS)))
                    .append("endAt", Date.from(now.plus(10, ChronoUnit.DAYS)))
                    .append("createdAt", new Date()));
        }

        MongoCollection<Document> candidates = db.getCollection("candidates");
        if (candidates.countDocuments() == 0) {
            candidates.insertOne(candidate("ELEC-2026", "CAN-001", 1, "Ana Lucía Mena", "Tecnologías de la Información", "Femenino", "Innovación, transparencia y participación."));
            candidates.insertOne(candidate("ELEC-2026", "CAN-002", 2, "Carlos Pérez", "Software", "Masculino", "Tu voz, nuestras decisiones."));
            candidates.insertOne(candidate("ELEC-2026", "CAN-003", 3, "Sofía Andrade", "Tecnologías de la Información", "Femenino", "Una comunidad universitaria más conectada."));
        }
    }

    private static void migrateLegacyData(MongoDatabase db) {
        for (Document student : db.getCollection("students").find()) {
            String email = student.getString("email");
            String cedula = student.getString("cedula");
            if (email != null && cedula != null) {
                db.getCollection("users").updateOne(eq("email", email), set("cedula", cedula));
            }
        }
        for (Document candidate : db.getCollection("candidates").find()) {
            String career = candidate.getString("career");
            String legacyCourse = candidate.getString("course");
            if ((career == null || career.isBlank()) && legacyCourse != null && !legacyCourse.isBlank()) {
                db.getCollection("candidates").updateOne(eq("candidateId", candidate.getString("candidateId")),
                        set("career", legacyCourse));
            }
        }
    }

    private static Document candidate(String electionId, String candidateId, int listNumber,
            String name, String career, String gender, String proposal) {
        return new Document("electionId", electionId)
                .append("candidateId", candidateId)
                .append("listNumber", listNumber)
                .append("fullName", name)
                .append("career", career)
                .append("gender", gender)
                .append("proposal", proposal)
                .append("active", true)
                .append("image", "candidate_default.png")
                .append("createdAt", new Date());
    }
}
