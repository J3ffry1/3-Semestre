package components;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 * Botón redondeado que también puede arrastrarse desde la paleta de NetBeans.
 */
public class BotonRedondeado extends JButton {
    private int radius = 14;
    private Color normalColor = new Color(37, 99, 235);
    private Color hoverColor = new Color(13, 44, 84);
    private boolean hover;

    /** Constructor requerido por el GUI Builder. */
    public BotonRedondeado() {
        this("Botón", new Color(37, 99, 235), new Color(13, 44, 84), 14);
    }

    public BotonRedondeado(String text, Color normalColor, Color hoverColor) {
        this(text, normalColor, hoverColor, 14);
    }

    public BotonRedondeado(String text, Color normalColor, Color hoverColor, int radius) {
        super(text);
        this.normalColor = normalColor;
        this.hoverColor = hoverColor;
        this.radius = radius;
        initializeAppearance();
    }

    private void initializeAppearance() {
        setFont(new Font("Segoe UI", Font.BOLD, 14));
        setForeground(Color.WHITE);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorder(new EmptyBorder(10, 16, 10, 16));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent event) {
                hover = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent event) {
                hover = false;
                repaint();
            }
        });
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = Math.max(0, radius);
        repaint();
    }

    public Color getNormalColor() {
        return normalColor;
    }

    public void setNormalColor(Color normalColor) {
        this.normalColor = normalColor == null ? new Color(37, 99, 235) : normalColor;
        repaint();
    }

    public Color getHoverColor() {
        return hoverColor;
    }

    public void setHoverColor(Color hoverColor) {
        this.hoverColor = hoverColor == null ? new Color(13, 44, 84) : hoverColor;
        repaint();
    }

    public void setColors(Color normalColor, Color hoverColor) {
        setNormalColor(normalColor);
        setHoverColor(hoverColor);
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        Graphics2D g2 = (Graphics2D) graphics.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(hover ? hoverColor : normalColor);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
        g2.dispose();
        super.paintComponent(graphics);
    }
}
