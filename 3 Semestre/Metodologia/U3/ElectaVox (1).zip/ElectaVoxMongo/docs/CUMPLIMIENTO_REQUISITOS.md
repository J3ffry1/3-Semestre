# Cumplimiento de historias de usuario

## Administrador: registro de estudiantes

- Cédula de 10 dígitos, nombre completo, curso y género.
- Contraseña obligatoria; correo institucional opcional.
- Persistencia en `students` y credenciales en `users`.
- Índices únicos para cédula y correo.

## Estudiante: inicio de sesión

- Acceso mediante cédula y contraseña.
- Validación contra el padrón activo.
- Mensaje específico cuando la cédula no existe.

## Administrador: candidatos

- Número de lista, nombre, carrera, propuestas, género y fotografía.
- Fotografía almacenada como dato binario en MongoDB.
- Compatibilidad con candidatos de versiones anteriores que usaban el campo `course`.

## Estudiante: consulta y voto

- Tarjetas con fotografía, carrera y propuesta completa.
- Selección única y confirmación previa.
- Voto guardado en `votes`.
- Bloqueo de duplicados mediante consulta previa e índice único compuesto.

## Temporizador y cierre

- Cuenta regresiva visible con segundos.
- Actualización cada segundo.
- Cierre automático al llegar a cero.
- Bloqueo inmediato de controles de votación.

## Resultados y estadísticas

- Barras de porcentaje por candidato.
- Actualización automática cada dos segundos.
- Total de votos emitidos.
- Participación por curso y género calculada contra estudiantes habilitados.
- Presentación gráfica de porcentajes en las tablas.

## Reporte final y acta

- Reporte TXT con resultados, estadísticas, fecha y hora.
- Acta TXT de cierre oficial.
- Identificación del ganador o declaración de empate.
- Generación automática durante el cierre y generación manual desde Reportes.
