# MongoDB Compass: conexión y comprobación de ElectaVox

## 1. Iniciar MongoDB

En Windows abre **Servicios**, busca **MongoDB Server** y confirma que su estado sea **En ejecución**. Si no está instalado, instala MongoDB Community Server antes de abrir el proyecto.

## 2. Abrir Compass

1. Ejecuta MongoDB Compass.
2. En la pantalla de conexión escribe:

```text
mongodb://localhost:27017
```

3. Haz clic en **Connect**.

## 3. Configurar el proyecto

Abre el archivo:

```text
src/main/resources/application.properties
```

Debe contener:

```properties
mongodb.uri=mongodb://localhost:27017
mongodb.db=electavox
```

## 4. Ejecutar ElectaVox una vez

Inicia el proyecto desde NetBeans e ingresa con:

```text
Correo: admin@espe.edu.ec
Contraseña: Admin123*
```

En ese instante la aplicación ejecuta `InicializadorBaseDatos` y crea automáticamente la base `electavox`.

## 5. Verificar en Compass

Pulsa el botón de actualizar en Compass. Deben aparecer:

```text
electavox
 ├── users
 ├── students
 ├── candidates
 ├── elections
 └── votes
```

Revisa `users` para observar el administrador y el estudiante de demostración; el estudiante contiene también el campo `cedula`. La contraseña no se guarda como texto: se almacena como `passwordHash`.

## 6. Probar el voto único

1. Ingresa como estudiante con la cédula `1723456789` y la contraseña `Estudiante123*`.
2. Abre **Emitir voto**.
3. Selecciona una candidatura y confirma.
4. En Compass actualiza la colección `votes`.
5. Intenta votar otra vez con el mismo estudiante. La aplicación mostrará que el voto ya fue emitido.

La colección `votes` tiene un índice único compuesto por `electionId` y `studentId`; por ello MongoDB rechaza un segundo voto del mismo estudiante en la misma elección.

## Conexión con MongoDB Atlas

Cambia la propiedad por tu cadena privada de Atlas:

```properties
mongodb.uri=mongodb+srv://USUARIO:CONTRASENA@cluster0.ejemplo.mongodb.net/?retryWrites=true&w=majority
mongodb.db=electavox
```

No subas credenciales reales a GitHub. Para una entrega real, usa las variables de entorno `MONGODB_URI` y `MONGODB_DB` en lugar de dejar la cadena privada en el archivo.
