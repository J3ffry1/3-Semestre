# Guía de GUI Builder para ElectaVox

Este proyecto está construido con Swing y usa `JFrame` y `JPanel`. Las pantallas están separadas para que puedas modificarlas por módulos.

## Formularios principales

- `FrmInicioSesion`: pantalla de inicio de sesión.
- `FrmPrincipal`: ventana principal, menú lateral y área de tarjetas.

## Paneles por funcionalidad

- `PanelResumen`
- `PanelEstudiantes`
- `PanelCandidatos`
- `PanelVotacion`
- `PanelResultados`
- `PanelReportes`
- `PanelEleccion`

## Cómo recrear o modificar una pantalla arrastrando componentes

1. En NetBeans crea un nuevo **JFrame Form** o **JPanel Form** dentro del paquete `vista` o `panels`.
2. En la pestaña **Design**, arrastra los componentes desde **Palette > Swing Controls**.
3. Usa estos componentes recomendados:

| Objetivo | Componente para arrastrar |
|---|---|
| Contenedor principal | `JPanel` |
| Botón de acción | `JButton` |
| Campo de cédula, correo, nombre o curso | `JTextField` |
| Contraseña | `JPasswordField` |
| Género | `JComboBox` |
| Propuesta | `JTextArea` dentro de `JScrollPane` |
| Lista de registros | `JTable` dentro de `JScrollPane` |
| Secciones de resultados | `JTabbedPane` |
| Mensajes e imágenes | `JLabel` |
| Selección de fotografía | `JFileChooser` invocado desde un botón |

4. Para la pantalla principal usa `BorderLayout`: menú lateral en `WEST`, barra superior en `NORTH` y panel de contenido en `CENTER`.
5. Para alternar vistas usa `CardLayout` en el área central.
6. Para formularios de registro usa `GroupLayout` o `GridBagLayout`.
7. Conserva los nombres de variables claros, por ejemplo: `txtCorreo`, `btnGuardar`, `tblEstudiantes`, `lblMensaje`.

## Recursos de imagen

Desde el GUI Builder selecciona un `JLabel`, abre su propiedad **icon** y usa **Import to Project**. Las imágenes ya incluidas están en:

```text
src/main/resources/images
```

Al cargar por código se utiliza la ruta:

```java
UtilImagen.load("election_hero.png", 380, 275);
```

## Recomendación para la exposición

Muestra `FrmInicioSesion`, luego `FrmPrincipal`, y explica que cada botón del menú abre un `JPanel` distinto. Así demuestras una interfaz modular, mantenible y hecha con componentes gráficos de Java Swing.
